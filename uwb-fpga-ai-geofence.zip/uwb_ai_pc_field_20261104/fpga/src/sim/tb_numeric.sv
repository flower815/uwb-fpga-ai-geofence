`timescale 1ns/1ps
module tb_numeric;
    reg clk=0,rst_n=0,start=0;
    always #5 clk=~clk;
    reg signed [63:0] n,d,wanted;
    wire signed [63:0] quotient;
    wire div_done,div_busy,div_zero;
    signed_div64 divider(.clk(clk),.rst_n(rst_n),.start(start),.numerator(n),.denominator(d),
        .busy(div_busy),.done(div_done),.divide_by_zero(div_zero),.quotient(quotient));
    reg sol_start=0;
    reg [31:0] d0,d1,d2;
    wire sol_valid,sol_busy,bad_valid;
    wire [223:0] result,bad_result;
    reg saw_bad_geometry=0;
    // Negative determinant, translated/rotated axes, unequal anchor heights.
    trilateration_2d #(.X0(500),.Y0(-1000),.Z0(1700),
        .X1(-2500),.Y1(6500),.Z1(1400),.X2(5500),.Y2(1000),.Z2(2400),.TAG_Z(900)) solver(
        .clk(clk),.rst_n(rst_n),.start(sol_start),.mask_in(8'h07),.seq_in(8'h5a),.tag_in(8'd2),
        .d0_in(d0),.d1_in(d1),.d2_in(d2),.busy(sol_busy),.valid(sol_valid),.record_out(result));
    trilateration_2d #(.X0(0),.Y0(0),.X1(1000),.Y1(1000),.X2(2000),.Y2(2000)) singular(
        .clk(clk),.rst_n(rst_n),.start(sol_start),.mask_in(8'h07),.seq_in(8'h00),.tag_in(8'd2),
        .d0_in(d0),.d1_in(d1),.d2_in(d2),.busy(),.valid(bad_valid),.record_out(bad_result));
    always @(posedge clk) if(rst_n && bad_valid) begin
        if(bad_result[7:0]!==8'h04) $fatal(1,"Collinear geometry accepted");
        saw_bad_geometry<=1;
    end
    integer fd,rc,cases=0,sol_cases=0,wx,wy;
    initial begin
        n=0;d=0;d0=0;d1=0;d2=0;
        #30; @(negedge clk);rst_n=1;
        fd=$fopen("sim/division_vectors.txt","r");
        if(!fd) $fatal(1,"Run scripts/verify.py to generate test vectors");
        while(!$feof(fd)) begin
            rc=$fscanf(fd,"%d %d %d\n",n,d,wanted);
            if(rc==3) begin
                @(negedge clk);start=1;
                @(negedge clk);start=0;
                wait(div_done); #1;
                if(quotient!==wanted || div_zero!==(d==0))
                    $fatal(1,"Division failed %0d / %0d = %0d wanted %0d",n,d,quotient,wanted);
                cases=cases+1;
            end
        end
        $fclose(fd);
        fd=$fopen("sim/solver_vectors.txt","r");
        if(!fd) $fatal(1,"Missing solver vectors");
        while(!$feof(fd)) begin
            rc=$fscanf(fd,"%d %d %d %d %d\n",d0,d1,d2,wx,wy);
            if(rc==5) begin
                @(negedge clk);sol_start=1;
                @(negedge clk);sol_start=0;
                wait(sol_valid); #1;
                if(result[7:0]!==0 || $signed(result[159:128])!==wx ||
                   $signed(result[191:160])!==wy || $signed(result[223:192])!==900 ||
                   result[31:8]!==24'h025a07)
                    $fatal(1,"Solver failed d=%0d,%0d,%0d XY=%0d,%0d expected=%0d,%0d status=%h",
                        d0,d1,d2,$signed(result[159:128]),$signed(result[191:160]),wx,wy,result[7:0]);
                sol_cases=sol_cases+1;
            end
        end
        $fclose(fd);
        if(!saw_bad_geometry) $fatal(1,"Singular geometry not checked");
        $display("PASS tb_numeric: %0d signed divisions; %0d arbitrary-geometry solutions; collinear rejection",cases,sol_cases);
        $finish;
    end
    initial begin #2000000; $fatal(1,"Numeric test timeout"); end
endmodule
