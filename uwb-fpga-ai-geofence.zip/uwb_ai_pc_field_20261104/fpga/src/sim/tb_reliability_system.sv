`timescale 1ns/1ps
// Real UART test of the complete new USB top; no forced internal state.
module tb_reliability_system;
    reg clk=0,rst_n=0,rx=1,pc_rx=1;
    always #250 clk=~clk;
    wire tx,beep;
    uwb_ai_top #(.CLK_HZ(2000000),.UWB_BAUD(100000),.PC_BAUD(100000),
        .FAULT_TIMEOUT_MS(80),.FAULT_STARTUP_MS(100))dut(
        .sys_clk(clk),.sys_rst_n(rst_n),.uwb_rx(rx),.pc_rx(pc_rx),.pc_tx(tx),.beep(beep));
    // Same physical measurements into the default Wi-Fi top, kept offline.
    // Geofence and fault monitoring must work locally without an ESP reply.
    wire wifi_beep;
    uwb_ai_wifi_top #(.CLK_HZ(2000000),.UWB_BAUD(100000),.PC_BAUD(100000),
        .FAULT_TIMEOUT_MS(80),.FAULT_STARTUP_MS(100),.BOOT_MS(5000))wifi_dut(
        .sys_clk(clk),.sys_rst_n(rst_n),.uwb_rx(rx),.esp_rx(1'b1),
        .esp_tx(),.esp_rst_n(),.beep(wifi_beep));
    always @(negedge clk)if(rst_n && dut.rst_n && wifi_dut.rst_n)begin
        if(beep && !dut.local_alarm)$fatal(1,"USB fault sounded without confirmed fence alarm");
        if(wifi_beep && !wifi_dut.local_alarm)$fatal(1,"WiFi fault sounded without confirmed fence alarm");
        if(dut.local_alarm!==wifi_dut.local_alarm || beep!==wifi_beep ||
           dut.position_fault!==wifi_dut.position_fault)$fatal(1,"USB/WiFi local policies differ");
    end
    function automatic [15:0] crc_next(input[15:0]prev,input[7:0]v);
        reg[15:0]c;
        begin c=prev^{v,8'h00};for(integer i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crc_next=c;end
    endfunction
    reg[7:0]packet[0:41],b,flags[0:255],status[0:255];
    reg[15:0]crc;
    integer index=0,target=42,telemetry=0,acks=0,capture=0,heartbeats=0,held_faults=0;
    integer real_seen[0:255];string path;
    integer mm_detail=0;
    reg [95:0] core_xyz[0:255];
    always @(posedge clk)if(dut.record_valid && dut.record_ready && dut.record_data[15:8]==7)
        core_xyz[dut.record_data[23:16]]<=dut.record_data[223:128];
    always @(posedge clk)if(dut.record_valid && dut.record_ready && dut.record_data[6:0]==0)
        if($signed(dut.record_data[159:128])%100!=0 || $signed(dut.record_data[191:160])%100!=0)mm_detail=mm_detail+1;
    initial begin
        for(integer i=0;i<256;i=i+1)begin flags[i]=0;status[i]=0;real_seen[i]=0;end
        if($value$plusargs("CAPTURE=%s",path))capture=$fopen(path,"w");
    end
    initial forever begin
        @(negedge tx);#15000;
        for(integer i=0;i<8;i=i+1)begin b[i]=tx;#10000;end
        if(tx!==1)$fatal(1,"Reliability UART stop bit");
        packet[index]=b;index=index+1;
        if(index==3)begin
            if(packet[2]!=3 && packet[2]!=8'h11)$fatal(1,"Reliability version");
            target=(packet[2]==3)?42:18;
        end
        if(index==target)begin
            if(packet[0]!==8'h55 || packet[1]!==8'haa)$fatal(1,"Reliability header");
            crc=16'hffff;for(integer i=0;i<target-2;i=i+1)crc=crc_next(crc,packet[i]);
            if({packet[target-1],packet[target-2]}!==crc)$fatal(1,"Reliability CRC");
            if(packet[2]==3)begin
                if(packet[4]==7)
                    for(integer c=20;c<=28;c=c+4)
                        if({packet[c+3],packet[c+2],packet[c+1],packet[c]}!==core_xyz[packet[5]][(c-20)*8+:32])
                            $fatal(1,"Actual USB XYZ differs from internal millimeters");
                telemetry=telemetry+1;
                if(packet[4]==7 && packet[6]==2)begin
                    flags[packet[5]]=packet[33];status[packet[5]]=packet[3];real_seen[packet[5]]=real_seen[packet[5]]+1;
                end
                if(packet[4]==0 && packet[33]==32)heartbeats=heartbeats+1;
                if(packet[4]==0 && packet[33]==36)held_faults=held_faults+1;
                if(packet[3][4] && (packet[32]!==0 || {packet[39],packet[38],packet[37],packet[36],packet[35],packet[34]}!==48'hffffffffffff))
                    $fatal(1,"Untrusted frame retained valid bearings");
            end else begin
                acks=acks+1;
                if(packet[3]!==3 || packet[7]!==0 || {packet[15],packet[14],packet[13],packet[12]}!==32'h55574235)
                    $fatal(1,"Public profile query failed");
            end
            if(capture)begin for(integer i=0;i<target;i=i+1)$fwrite(capture,"%02x",packet[i]);$fwrite(capture,"\n");end
            index=0;
        end
    end
    task automatic query_magic;
        reg[127:0]payload;reg[15:0]c;reg[7:0]v;
        begin
            payload={32'b0,32'hbeef0001,8'h00,8'h00,16'h7001,8'h03,8'h10,16'haa55};c=16'hffff;
            for(integer i=0;i<18;i=i+1)begin
                if(i<16)begin v=payload[i*8+:8];c=crc_next(c,v);end
                else v=(i==16)?c[7:0]:c[15:8];
                pc_rx=0;#10000;for(integer j=0;j<8;j=j+1)begin pc_rx=v[j];#10000;end pc_rx=1;#10000;
            end
            #2500000;
            if(dut.armed || dut.watchdog_fault)$fatal(1,"Read-only query altered AI watchdog");
        end
    endtask
    task automatic line(input integer s,a,c,d);
        string text;reg[7:0]sb,v;reg[15:0]sw;integer previous;
        begin
            sb=s;sw=s;previous=real_seen[s];
            text=$sformatf("mc 07 %08x %08x %08x 00000000 %04x %02x 00000000 a2:0\015\012",a,c,d,sw,sb);
            for(integer i=0;i<text.len();i=i+1)begin
                v=text[i];rx=0;#10000;for(integer j=0;j<8;j=j+1)begin rx=v[j];#10000;end rx=1;#10000;
            end
            for(integer wait_cycles=0;wait_cycles<40000 && real_seen[s]==previous;wait_cycles=wait_cycles+1)@(posedge clk);
            #100000;
            if(real_seen[s]!=previous+1)$fatal(1,"Missing real UART record seq=%0d",s);
        end
    endtask
    initial begin
        #2000;rst_n=1;#10000;query_magic();
        #270000000;
        if(!dut.position_fault || heartbeats<1 || dut.local_alarm)$fatal(1,"Missing independent startup fault / heartbeat");
        line(1,2000,2000,2000);line(2,2000,2000,2000);
        if(!dut.position_fault)$fatal(1,"Fault recovered before three trustworthy samples");
        line(3,2000,2000,2000);
        if(dut.position_fault || flags[3]!=1)$fatal(1,"Trustworthy recovery failed");
        line(4,5000,2000,2000);
        if(!status[4][4] || dut.local_alarm || dut.position_fault)$fatal(1,"Bad raw geometry accepted or immediate false alarm");
        line(5,2000,2000,2000);
        line(6,3271,1049,2973);line(7,3271,1049,2973);
        if(dut.local_alarm || flags[6]!=8 || flags[7]!=16)$fatal(1,"Premature confirmed alarm");
        line(8,3271,1049,2973);
        if(!dut.local_alarm || flags[8]!=3)$fatal(1,"Third trustworthy outside frame did not alarm");
        line(9,1803,1803,2737);
        if(!dut.local_alarm)$fatal(1,"Raw-only safe return bypassed filtered outside result");
        line(10,1803,1803,2737);
        if(dut.local_alarm || beep || flags[10]!=1)$fatal(1,"First paired shallow inside sample did not clear");
        // Return point is about 50mm inside, below the old 150mm inset.
        line(11,1803,1803,2737);line(12,1803,1803,2737);
        line(13,2000,2000,2000);line(14,2000,2000,2000);line(15,2000,2000,2000);
        line(16,2000,2000,2000);
        if(dut.local_alarm || dut.position_fault || flags[16]!=1)$fatal(1,"Deep confirmed return failed");
        line(17,3271,1049,2973);line(18,3271,1049,2973);line(19,3271,1049,2973);
        #270000000;
        if(!dut.position_fault || !dut.local_alarm || held_faults<1)$fatal(1,"Fault hid confirmed fence alarm");
        for(integer s=20;s<=25;s=s+1)line(s,2000,2000,2000);
        if(dut.position_fault || dut.local_alarm)$fatal(1,"Fault+fence return did not settle");
        for(integer i=0;i<9;i=i+1)line(25,2000,2000,2000);
        if(!dut.position_fault || dut.local_alarm)$fatal(1,"Duplicate sequence fed position watchdog");
        line(26,2000,2000,2000);line(27,2000,2000,2000);line(28,2000,2000,2000);
        if(dut.position_fault || dut.local_alarm || acks!=1)$fatal(1,"Final recovery/profile failed");
        // Real UART gap-two traffic, including fence candidates, remains healthy.
        for(integer i=0;i<4;i=i+1)begin
            line(30+i*6,3271,1049,2973);
            line(32+i*6,2000,2000,2000);
            line(34+i*6,2000,2000,2000);
            if(dut.position_fault || dut.local_alarm)$fatal(1,"Gap-two candidates caused false health/alarm");
        end
        line(54,3271,1049,2973);line(56,3271,1049,2973);
        if(dut.local_alarm)$fatal(1,"Gap-two alarm before third receipt");
        line(58,3271,1049,2973);
        if(!dut.local_alarm || flags[58]!=3 || dut.position_fault)$fatal(1,"Gap-two third receipt failed");
        line(58,2000,2000,2000);line(57,2000,2000,2000);
        if(!dut.local_alarm)$fatal(1,"Duplicate/backwards inside cleared alarm");
        line(60,2000,2000,2000);line(62,2000,2000,2000);
        if(dut.local_alarm || dut.position_fault)$fatal(1,"Gap-two safe return failed");
        // Both positions round onto y=0, but raw y<0 must still cause outside3.
        line(64,1803,1803,2791);line(66,1803,1803,2791);line(68,1803,1803,2791);
        if(!dut.local_alarm || mm_detail==0)$fatal(1,"Wire rounding changed core/fence precision");
        if(capture)$fclose(capture);
        $display("PASS tb_reliability_system: USB/WiFi fault silence, actual UART profile, quality gating, fault heartbeat, duplicate rejection, first paired inside clears at 50mm, three-hit outside");$finish;
    end
    initial begin #2000000000;$fatal(1,"Reliability system timeout");end
endmodule
