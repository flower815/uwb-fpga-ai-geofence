`timescale 1ns/1ps
module tb_fence_system;
    parameter integer CLK_HZ=2_000_000,BAUD=100000;
    localparam integer BIT_NS=1_000_000_000/BAUD;
    reg clk=0,rst_n=0,rx=1;
    wire tx,beep;
    always #(500_000_000/CLK_HZ) clk=~clk;
    uwb_top #(.CLK_HZ(CLK_HZ),.UWB_BAUD(BAUD),.PC_BAUD(BAUD),.ENABLE_ANGLES(1),.ENABLE_FENCE(1),.ENABLE_BUZZER(1),
        .Z0(1000),.Z1(1000),.Z2(1000),.X1(3000),.X2(1500),.Y2(2600),.TAG_Z(0)) dut(
        .sys_clk(clk),.sys_rst_n(rst_n),.uwb_rx(rx),.pc_tx(tx),.beep(beep));
    reg [7:0] packet[0:41],b;
    reg [15:0] crc;
    integer count=0,received=0,expected=0;
    integer ranges[0:63][0:2],xs[0:63],ys[0:63],flags[0:63],angles[0:63][0:2];
    integer expected_status[0:63];
    integer capture=0;
    string capture_path,line;
    function automatic [31:0] u32(input integer i);u32={packet[i+3],packet[i+2],packet[i+1],packet[i]};endfunction
    function automatic [15:0] crc_next(input [15:0] prev,input [7:0] value);
        reg [15:0] c;
        begin c=prev^{value,8'h00};for(integer i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crc_next=c;end
    endfunction
    initial forever begin
        @(negedge tx); #(BIT_NS+BIT_NS/2);
        for(integer i=0;i<8;i=i+1)begin b[i]=tx;#(BIT_NS);end
        if(tx!==1)$fatal(1,"Fence UART stop bit");
        packet[count]=b;count=count+1;
        if(count==42)begin
            if(received>=expected || packet[0]!==8'h55 || packet[1]!==8'haa || packet[2]!==3 ||
                packet[3]!==expected_status[received] || packet[6]!==2 || packet[7]!==0)$fatal(1,"V3 header/status");
            crc=16'hffff;for(integer i=0;i<40;i=i+1)crc=crc_next(crc,packet[i]);
            if({packet[41],packet[40]}!==crc)$fatal(1,"V3 CRC");
            for(integer i=0;i<3;i=i+1)begin
                if(u32(8+i*4)!==ranges[received][i])$fatal(1,"Fence input range mismatch");
                if({packet[35+i*2],packet[34+i*2]}!==angles[received][i])$fatal(1,"Fence angle mismatch A%0d",i);
            end
            if($signed(u32(20))!==xs[received] || $signed(u32(24))!==ys[received] || u32(28)!==0 ||
                packet[33]!==flags[received] || packet[32]!==(expected_status[received]==0 ? 8'd7 : 8'd0))
                $fatal(1,"Fence coordinate/flags mismatch gotXY=%0d,%0d flags=%0d expected=%0d",$signed(u32(20)),$signed(u32(24)),packet[33],flags[received]);
            if(capture)begin for(integer i=0;i<42;i=i+1)$fwrite(capture,"%02x",packet[i]);$fwrite(capture,"\n");end
            received=received+1;count=0;
        end
    end
    task automatic send_text(input string s);
        reg[7:0] v;
        begin for(integer i=0;i<s.len();i=i+1)begin
            v=s[i];rx=0;#(BIT_NS);for(integer j=0;j<8;j=j+1)begin rx=v[j];#(BIT_NS);end
            rx=1;#(BIT_NS);
        end end
    endtask
    integer f,n,r0,r1,r2,px,py,flag,a0,a1,a2;
    reg[15:0] nr;
    reg[7:0] sq;
    initial begin
        if($value$plusargs("CAPTURE=%s",capture_path))begin capture=$fopen(capture_path,"w");if(!capture)$fatal(1,"Capture open");end
        #10000;rst_n=1;#10000;
        f=$fopen("sim/fence_system_vectors.txt","r");if(!f)$fatal(1,"Missing fence pipeline vectors");
        while(!$feof(f))begin
            n=$fscanf(f,"%d %d %d %d %d %d %d %d %d\n",r0,r1,r2,px,py,flag,a0,a1,a2);
            if(n==9)begin
                ranges[expected][0]=r0;ranges[expected][1]=r1;ranges[expected][2]=r2;
                xs[expected]=px;ys[expected]=py;flags[expected]=flag;
                angles[expected][0]=a0;angles[expected][1]=a1;angles[expected][2]=a2;expected_status[expected]=0;
                expected=expected+1;nr=expected;sq=expected;
                line=$sformatf("mc 07 %08x %08x %08x 00000000 %04x %02x 00000000 t2:0\015\012",r0,r1,r2,nr,sq);
                send_text(line); wait(received==expected);
                if(beep!==(flag==3))$fatal(1,"Buzzer disagrees with fence flag");
            end
        end
        $fclose(f);
        // Last reference point is outside. Missing ranges must keep its local alarm.
        ranges[expected][0]=328;ranges[expected][1]=0;ranges[expected][2]=0;
        xs[expected]=0;ys[expected]=0;flags[expected]=4;expected_status[expected]=1;
        angles[expected][0]=65535;angles[expected][1]=65535;angles[expected][2]=65535;expected=expected+1;
        send_text("mc 01 00000148 00000000 00000000 00000000 0020 20 00000000 t2:0\015\012");
        wait(received==expected); if(!beep)$fatal(1,"Missing measurement silenced alarm");
        if(capture)$fclose(capture);
        $display("PASS tb_fence_system: %0d V3 records, actual equilateral layout, inside/outside/angles/CRC/buzzer/invalid-hold",received);
        $finish;
    end
    initial begin #400000000;$fatal(1,"Fence pipeline timeout");end
endmodule
