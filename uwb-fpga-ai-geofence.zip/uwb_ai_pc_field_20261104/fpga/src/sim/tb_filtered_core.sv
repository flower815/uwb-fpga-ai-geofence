`timescale 1ns/1ps
module tb_filtered_core;
    parameter integer ANGLES=1;
    reg clk=0,rst_n=0,rx=1;
    always #250 clk=~clk;
    wire [287:0]data;wire valid,alarm;
    uwb_position_core #(.CLK_HZ(2000000),.UWB_BAUD(100000),.X1(3000),.X2(1500),.Y2(2600),
        .Z0(1000),.Z1(1000),.Z2(1000),.TAG_Z(0),.ENABLE_ANGLES(ANGLES),.ENABLE_FENCE(1),.RANGE_FILTER(1)) dut(
        .clk(clk),.rst_n(rst_n),.uwb_rx(rx),.stream_enable(1'b1),.record_out(data),
        .record_valid(valid),.record_ready(1'b1),.fence_alarm(alarm));
    integer count=0,capture=0;string path;
    initial if($value$plusargs("CAPTURE=%s",path))capture=$fopen(path,"w");
    always @(posedge clk) if(valid)begin
        count=count+1;
        if(capture)$fdisplay(capture,"%072h",data);
        if(data[31:24]!==2 || data[23:16]!==count)$fatal(1,"Filter record alignment");
        if(count==4)begin
            if(data[63:32]!==5000 || data[159:128]!==1500 || data[191:160]!==867 || data[239:232]!==4 || !alarm)
                $fatal(1,"Isolated spike not filtered / raw alarm hidden");
        end else if(count==6 || count==7)begin
            if(data[159:128]!==5000 || data[239:232]!==3 || !alarm)$fatal(1,"Sustained real crossing suppressed");
        end else if(count==8)begin
            if(data[7:0]!==1 || data[239:232]!==4 || !alarm)$fatal(1,"Invalid input cleared protection");
        end else if(data[159:128]!==1500 || data[239:232]!==1 || alarm)$fatal(1,"Return / warmup mismatch %0d",count);
    end
    task automatic send_byte(input[7:0]b);
        begin rx=0;#10000;for(integer i=0;i<8;i=i+1)begin rx=b[i];#10000;end rx=1;#10000;end
    endtask
    task automatic line(input integer s,m,a,b,c);
        string text;
        reg [7:0] mask_byte,seq_byte;
        reg [15:0] count_word;
        begin
            mask_byte=m;seq_byte=s;count_word=s;
            text=$sformatf("mc %02x %08x %08x %08x 00000000 %04x %02x 00000000 a2:0\015\012",mask_byte,a,b,c,count_word,seq_byte);
            if(text.len()!=65)$fatal(1,"Test line width %0d [%s]",text.len(),text);
            for(integer i=0;i<text.len();i=i+1)send_byte(text[i]);
            #300000;
        end
    endtask
    initial begin
        #2000;rst_n=1;#2000;
        line(1,7,2000,2000,2000);line(2,7,2000,2000,2000);line(3,7,2000,2000,2000);
        line(4,7,5000,2000,2000);line(5,7,2000,2000,2000);
        line(6,7,5000,2000,2000);line(7,7,5000,2000,2000);
        line(8,1,2000,0,0);line(9,7,2000,2000,2000);
        if(count!=9)$fatal(1,"Missing filtered records: %0d",count);
        if(capture)$fclose(capture);
        $display("PASS tb_filtered_core: raw ranges preserved, filtered XY, immediate raw fence, sustained crossing, unknown hold and recovery");$finish;
    end
    initial begin #200000000;$fatal(1,"Filtered core timeout");end
endmodule
