`timescale 1ns/1ps
// Independent wire-level ESP model. No real Wi-Fi or credentials are used.
module tb_wifi;
    parameter integer CLK_HZ=2_000_000, BAUD=100000, LEGACY_CUR=0, ENABLE_ANGLES=0, ENABLE_FENCE=0;
    localparam integer BIT_NS=1_000_000_000/BAUD;
    localparam integer BODY_BYTES=(ENABLE_ANGLES || ENABLE_FENCE) ? 40 : 32, FRAME_BYTES=BODY_BYTES+2;
    localparam integer JOIN_N=LEGACY_CUR ? 32 : 28;
    localparam [2047:0] JOIN=LEGACY_CUR ?
        "AT+CWJAP_CUR=\"lab\",\"secret123\"\015\012" : "AT+CWJAP=\"lab\",\"secret123\"\015\012";
    localparam [1023:0] TCP="AT+CIPSTART=\"TCP\",\"192.168.1.100\",9000,5\015\012";
    reg clk=0,rst_n=0,uwb_rx=1,esp_rx=1;
    wire esp_tx,beep;
    tri1 esp_rst_n;
    always #(500_000_000/CLK_HZ) clk=~clk;
    uwb_wifi_top #(.CLK_HZ(CLK_HZ),.UWB_BAUD(BAUD),.PC_BAUD(BAUD),.LEGACY_CUR(LEGACY_CUR),.ENABLE_ANGLES(ENABLE_ANGLES),
        .ENABLE_FENCE(ENABLE_FENCE),.ENABLE_BUZZER(ENABLE_FENCE),
        .JOIN_LEN(JOIN_N),.JOIN_COMMAND(JOIN),.TCP_LEN(42),.TCP_COMMAND(TCP),
        .RESET_MS(2),.BOOT_MS(2),.GUARD_MS(2),.FLUSH_MS(2),.RETRY_MS(3),
        .ACK_TIMEOUT_MS(8),.JOIN_TIMEOUT_MS(10),.TCP_TIMEOUT_MS(10),.SEND_TIMEOUT_MS(8),.POLL_MS(15)) dut(
        .sys_clk(clk),.sys_rst_n(rst_n),.uwb_rx(uwb_rx),.esp_rx(esp_rx),
        .esp_tx(esp_tx),.esp_rst_n(esp_rst_n),.beep(beep));
    integer resets=0,commands=0,packets=0,payload_mode=0,payload_count=0;
    integer command_toggle=0,handled_toggle=0;
    integer inject_at_timeout=1,inject_store_error=1,inject_join_fail=1,inject_tcp_half=1;
    integer inject_prompt_timeout=0,inject_send_fail=0,inject_send_timeout=0,inject_status_fail=0;
    integer status_checks=0;
    integer capture=0;
    string capture_path;
    reg [2047:0] command_buffer=0,pending_command=0,current_command=0;
    reg [7:0] bytes_in[0:41];
    reg [7:0] byte_in;
    reg [15:0] check_crc;
    reg [31:0] last_seq=0;
    reg [255:0] error_seen=0;
    always @(posedge clk) if(dut.last_error!=0) error_seen[dut.last_error]<=1'b1;
    always @(negedge esp_rst_n) begin
        resets=resets+1; command_buffer=0; payload_mode=0; payload_count=0;
    end
    function automatic [15:0] crc_next(input [15:0] prev,input [7:0] value);
        reg [15:0] c;
        begin
            c=prev^{value,8'h00};
            for(integer j=0;j<8;j=j+1) c=c[15] ? (c<<1)^16'h1021 : c<<1;
            crc_next=c;
        end
    endfunction
    function automatic [31:0] u32(input integer p);
        u32={bytes_in[p+3],bytes_in[p+2],bytes_in[p+1],bytes_in[p]};
    endfunction
    task automatic esp_byte(input [7:0] b);
        begin
            esp_rx=0; #(BIT_NS);
            for(integer i=0;i<8;i=i+1) begin esp_rx=b[i]; #(BIT_NS); end
            esp_rx=1; #(BIT_NS);
        end
    endtask
    task automatic esp_text(input string s);
        begin for(integer i=0;i<s.len();i=i+1) esp_byte(s[i]); end
    endtask
    task automatic uwb_text(input string s);
        reg [7:0] b;
        begin
            for(integer i=0;i<s.len();i=i+1) begin
                b=s[i];
                uwb_rx=0; #(BIT_NS);
                for(integer j=0;j<8;j=j+1) begin uwb_rx=b[j]; #(BIT_NS); end
                uwb_rx=1; #(BIT_NS);
            end
        end
    endtask
    task automatic measurement(input integer seq);
        string s;
        reg [15:0] nr;
        reg [7:0] sq;
        begin
            nr=seq; sq=seq;
            s=$sformatf("mc 07 00001388 00001388 00001388 00000000 %04x %02x 00000000 t2:0\015\012",nr,sq);
            if($test$plusargs("TRACE")) $display("MC len=%0d [%s]",s.len(),s);
            uwb_text(s);
        end
    endtask
    task automatic wait_online;
        begin wait(dut.online===1'b1); #100000; end
    endtask
    task automatic wait_reconnect(input integer old_retries);
        begin wait(dut.retry_count>old_retries); wait_online(); end
    endtask
    // Independent UART receiver never blocks while the fake ESP sends replies.
    initial forever begin
        @(negedge esp_tx); #(BIT_NS+BIT_NS/2);
        for(integer i=0;i<8;i=i+1) begin byte_in[i]=esp_tx; #(BIT_NS); end
        if(esp_tx!==1'b1) $fatal(1,"Invalid ESP TX stop bit");
        if(payload_mode!=0) begin
            bytes_in[payload_count]=byte_in; payload_count=payload_count+1;
            if(payload_count==FRAME_BYTES) begin
                if(bytes_in[0]!==8'h55 || bytes_in[1]!==8'haa || bytes_in[2]!==(ENABLE_FENCE ? 8'd3 : ENABLE_ANGLES ? 8'd2 : 8'd1) || bytes_in[7]!==0)
                    $fatal(1,"Wi-Fi binary header corrupted / AT command mixed into payload");
                check_crc=16'hffff;
                for(integer i=0;i<BODY_BYTES;i=i+1) check_crc=crc_next(check_crc,bytes_in[i]);
                if({bytes_in[BODY_BYTES+1],bytes_in[BODY_BYTES]}!==check_crc) $fatal(1,"Wi-Fi CRC mismatch");
                if(bytes_in[3]!==0 || bytes_in[4]!==7 || bytes_in[6]!==2 ||
                    u32(8)!==5000 || u32(12)!==5000 || u32(16)!==5000 ||
                    $signed(u32(20))!==3000 || $signed(u32(24))!==4000 || u32(28)!==0)
                    $fatal(1,"Wi-Fi coordinates/metadata mismatch");
                if((ENABLE_ANGLES || ENABLE_FENCE) && bytes_in[33]!==(ENABLE_FENCE ? 8'd1 : 8'd0))$fatal(1,"Wi-Fi fence flag mismatch");
                if(ENABLE_ANGLES && (bytes_in[32]!==7 ||
                    {bytes_in[35],bytes_in[34]}!==16'd5313 ||
                    {bytes_in[37],bytes_in[36]}!==16'd12687 ||
                    {bytes_in[39],bytes_in[38]}!==16'd30687))$fatal(1,"Wi-Fi angle mismatch");
                if(bytes_in[5]<=last_seq) $fatal(1,"Old record replayed after reconnect");
                last_seq=bytes_in[5];
                if(capture) begin
                    for(integer i=0;i<FRAME_BYTES;i=i+1) $fwrite(capture,"%02x",bytes_in[i]);
                    $fwrite(capture,"\n");
                end
                packets=packets+1; payload_mode=0; payload_count=0;
                if($test$plusargs("TRACE")) $display("PAYLOAD seq=%0d total=%0d",last_seq,packets);
            end
        end else if(byte_in==10) begin
            pending_command=command_buffer; command_buffer=0; command_toggle=command_toggle+1;
        end else if(byte_in!=13) command_buffer={command_buffer[2039:0],byte_in};
    end
    initial forever begin
        wait(command_toggle!=handled_toggle);
        handled_toggle=command_toggle; current_command=pending_command; commands=commands+1;
        if($test$plusargs("TRACE")) $display("AT %0t retry=%0d [%0s]",$time,dut.retry_count,current_command);
        // Give the DUT transmitter time to finish the stop bit.
        #(BIT_NS*2);
        case(current_command)
            "+++": esp_text("\015\012ERROR\015\012"); // AT mode, not already in passthrough.
            "AT": begin
                if(inject_at_timeout!=0) begin inject_at_timeout=0; esp_text("\015\012NOT OK\015\012"); end
                else esp_text("\015\012OK\015\012");
            end
            "ATE0": esp_text("\015\012OK\015\012");
            "AT+GMR": esp_text("\015\012AT version:mock\015\012OK\015\012");
            "AT+SYSSTORE=0": begin
                if(LEGACY_CUR) $fatal(1,"Legacy profile received SYSSTORE");
                if(inject_store_error!=0) begin inject_store_error=0; esp_text("\015\012ERROR\015\012"); end
                else esp_text("\015\012OK\015\012");
            end
            "AT+CIPCLOSE": esp_text("\015\012ERROR\015\012"); // No pre-existing socket, allowed.
            "AT+CIPMODE=0","AT+CIPMUX=0","AT+SLEEP=0": esp_text("\015\012OK\015\012");
            "AT+CWMODE=1","AT+CWMODE_CUR=1": begin
                if((current_command=="AT+CWMODE_CUR=1")!=LEGACY_CUR) $fatal(1,"Wrong AT profile");
                esp_text("\015\012OK\015\012");
            end
            "AT+CWDHCP=1,1","AT+CWDHCP_CUR=1,1": begin
                if((current_command=="AT+CWDHCP_CUR=1,1")!=LEGACY_CUR) $fatal(1,"Wrong DHCP profile");
                esp_text("\015\012OK\015\012");
            end
            "AT+CWJAP=\"lab\",\"secret123\"","AT+CWJAP_CUR=\"lab\",\"secret123\"": begin
                if((current_command=="AT+CWJAP_CUR=\"lab\",\"secret123\"")!=LEGACY_CUR) $fatal(1,"Wrong join profile");
                if(inject_join_fail!=0) begin inject_join_fail=0; esp_text("\015\012FAIL\015\012"); end
                else esp_text("\015\012WIFI CONNECTED\015\012WIFI GOT IP\015\012OK\015\012");
            end
            "AT+CIPSTART=\"TCP\",\"192.168.1.100\",9000,5": begin
                if(inject_tcp_half!=0) begin inject_tcp_half=0; esp_text("\015\012OK\015\012"); end
                else esp_text("\015\012CONNECT\015\012OK\015\012");
            end
            "AT+CIPSEND=34","AT+CIPSEND=42": begin
                if((current_command=="AT+CIPSEND=42")!=(ENABLE_ANGLES || ENABLE_FENCE))$fatal(1,"Wrong AT payload length");
                if(inject_prompt_timeout!=0) begin inject_prompt_timeout=0; esp_text("\015\012OK\015\012"); end
                else begin
                    payload_mode=1;
                    esp_text("\015\012OK\015\012> ");
                    wait(payload_mode==0);
                    #(BIT_NS*2);
                    if(inject_send_fail!=0) begin inject_send_fail=0; esp_text("\015\012SEND FAIL\015\012"); end
                    else if(inject_send_timeout!=0) inject_send_timeout=0;
                    // XSim 2020.2 cannot reliably pass a string-valued ternary
                    // into an automatic task; keep these literal calls separate.
                    else if(ENABLE_ANGLES || ENABLE_FENCE) esp_text("\015\012Recv 42 bytes\015\012SEND OK\015\012");
                    else esp_text("\015\012Recv 34 bytes\015\012SEND OK\015\012");
                end
            end
            "AT+CIPSTATUS": begin
                status_checks=status_checks+1;
                if(inject_status_fail!=0) begin inject_status_fail=0; esp_text("\015\012STATUS:2\015\012OK\015\012"); end
                else esp_text("\015\012STATUS:3\015\012OK\015\012");
            end
            default: $fatal(1,"Unexpected / corrupted AT command: [%s]",current_command);
        endcase
    end
    integer before_retry,before_packets;
    initial begin
        if($value$plusargs("CAPTURE=%s",capture_path)) begin
            capture=$fopen(capture_path,"w");
            if(!capture) $fatal(1,"Cannot create Wi-Fi capture");
        end
        #10000; rst_n=1;
        if(ENABLE_FENCE)begin
            // Outside record while Wi-Fi is still down: local alarm must work.
            uwb_text("mc 07 00001388 00002679 00001388 00000000 0001 01 00000000 t2:0\015\012");
            #100000;
            if(!beep)$fatal(1,"Offline network disabled local geofence alarm");
        end else measurement(1);
        wait_online();
        if(packets!=0) $fatal(1,"Offline measurement replayed");
        if(!error_seen[8'h40] || !error_seen[8'h29] || !error_seen[8'h4a] ||
            (!LEGACY_CUR && !error_seen[8'h23])) $fatal(1,"Startup failures were not detected");
        if(ENABLE_FENCE && !beep)$fatal(1,"Reconnect cleared local alarm without a safe measurement");
        measurement(10); wait(packets==1); wait(dut.wifi.state_debug==9);
        if(ENABLE_FENCE && beep)$fatal(1,"Safe return failed to clear local alarm");
        // OK alone is not the CIPSEND prompt; must time out and reconnect.
        inject_prompt_timeout=1; before_retry=dut.retry_count;
        measurement(11); wait_reconnect(before_retry);
        if(packets!=1 || !error_seen[8'h4b]) $fatal(1,"Payload sent without > prompt");
        measurement(12); wait(packets==2); wait(dut.wifi.state_debug==9);
        inject_send_fail=1; before_retry=dut.retry_count;
        measurement(13); wait_reconnect(before_retry);
        if(!error_seen[8'he6]) $fatal(1,"SEND FAIL not detected");
        inject_send_timeout=1; before_retry=dut.retry_count;
        measurement(14); wait_reconnect(before_retry);
        if(!error_seen[8'he7]) $fatal(1,"SEND OK timeout not detected");
        measurement(15); wait(packets==5); wait(dut.wifi.state_debug==9);
        before_retry=dut.retry_count; esp_text("\015\012CLOSED\015\012"); wait_reconnect(before_retry);
        before_retry=dut.retry_count; esp_text("\015\012WIFI DISCONNECT\015\012"); wait_reconnect(before_retry);
        before_retry=dut.retry_count; esp_text("\015\012ready\015\012"); wait_reconnect(before_retry);
        before_retry=dut.retry_count;
        esp_rx=0; #(BIT_NS*12); esp_rx=1; #(BIT_NS*2);
        wait_reconnect(before_retry);
        inject_status_fail=1; before_retry=dut.retry_count; wait_reconnect(before_retry);
        if(!error_seen[8'he1] || !error_seen[8'he2] || !error_seen[8'he3] || !error_seen[8'he4] || !error_seen[8'he5])
            $fatal(1,"Disconnect/reset/status recovery missing");
        wait(status_checks>=2); wait(dut.wifi.state_debug==9);
        measurement(16); wait(packets==6); wait(dut.wifi.state_debug==9);
        before_packets=packets; #1000000;
        if(packets!=before_packets) $fatal(1,"Unexpected repeated payload");
        if(capture) $fclose(capture);
        $display("PASS tb_wifi: profile=%0d angles=%0d packets=%0d resets=%0d retries=%0d, AT/prompt/CRC/XY/failure/timeout/reconnect",LEGACY_CUR,ENABLE_ANGLES,packets,resets,dut.retry_count);
        $finish;
    end
    initial begin #1000000000; $fatal(1,"Wi-Fi simulation timeout state=%0d command=%0d packets=%0d retry=%0d pending=[%0s]",dut.state_debug,dut.command_debug,packets,dut.retry_count,pending_command); end
endmodule
