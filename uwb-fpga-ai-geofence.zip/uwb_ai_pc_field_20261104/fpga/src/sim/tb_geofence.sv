`timescale 1ns/1ps
module tb_geofence;
    reg clk=0,rst_n=0,in_valid=0;
    always #5 clk=~clk;
    reg [287:0] record=0;
    wire valid,cw_valid,degenerate_valid;
    wire [287:0] result,cw_result,degenerate_result;
    triangle_geofence dut(.clk(clk),.rst_n(rst_n),.in_valid(in_valid),.record_in(record),.out_valid(valid),.record_out(result));
    triangle_geofence #(.X1(1500),.Y1(2600),.X2(3000),.Y2(0)) clockwise(
        .clk(clk),.rst_n(rst_n),.in_valid(in_valid),.record_in(record),.out_valid(cw_valid),.record_out(cw_result));
    triangle_geofence #(.X2(6000),.Y2(0)) degenerate(
        .clk(clk),.rst_n(rst_n),.in_valid(in_valid),.record_in(record),.out_valid(degenerate_valid),.record_out(degenerate_result));
    reg [287:0] expected_record[0:2047];
    reg [7:0] expected_flags[0:2047];
    integer sent=0,received=0,f,n,x,y,flag;
    always @(posedge clk) begin
        #1;
        if(rst_n && valid) begin
            if(received>=sent || !cw_valid || !degenerate_valid)$fatal(1,"Geofence pipeline alignment");
            if(result[239:232]!==expected_flags[received] || cw_result!==result)
                $fatal(1,"Geofence flags got %0d expected %0d",result[239:232],expected_flags[received]);
            if(degenerate_result[239:232]!==0)$fatal(1,"Degenerate triangle reported safety");
            if(result[287:240]!==expected_record[received][287:240] || result[231:0]!==expected_record[received][231:0])
                $fatal(1,"Geofence changed measurement/angles or mixed records");
            received=received+1;
        end
    end
    task automatic push(input integer px,py,input [7:0] status,distance_mask,input integer expected);
        begin
            @(negedge clk);
            record={16'd30,16'd20,16'd10,8'hcc,8'h07,32'd1000,py[31:0],px[31:0],
                32'd5000,32'd5000,32'd5000,8'd2,sent[7:0],distance_mask,status};
            in_valid=1; expected_record[sent]=record; expected_flags[sent]=expected; sent=sent+1;
        end
    endtask
    reg alarm_valid=0;
    reg [287:0] alarm_record=0;
    wire alarm,beep,disabled_beep;
    wire [8:0] alarm_tags;
    geofence_alarm latch(.clk(clk),.rst_n(rst_n),.record_valid(alarm_valid),.record_in(alarm_record),.alarm(alarm),.alarm_tags(alarm_tags));
    geofence_buzzer #(.CLK_HZ(1000)) buzzer(.clk(clk),.rst_n(rst_n),.alarm(alarm),.beep(beep));
    geofence_buzzer #(.CLK_HZ(1000),.ENABLE_BUZZER(0)) muted(.clk(clk),.rst_n(rst_n),.alarm(alarm),.beep(disabled_beep));
    task automatic update_alarm(input [7:0] tag,flags,status);
        begin
            @(negedge clk); alarm_record=0;
            alarm_record[239:232]=flags; alarm_record[31:24]=tag;
            alarm_record[15:8]=7; alarm_record[7:0]=status; alarm_valid=1;
            @(negedge clk); alarm_valid=0;
        end
    endtask
    initial begin
        #30; rst_n=1;
        f=$fopen("sim/fence_vectors.txt","r");
        if(!f)$fatal(1,"Missing fence reference vectors");
        while(!$feof(f)) begin
            n=$fscanf(f,"%d %d %d\n",x,y,flag);
            if(n==3)push(x,y,0,7,flag);
        end
        $fclose(f);
        push(1500,850,1,7,0); push(1500,850,0,1,0);
        push(1500,850,8'h80,7,1); push(3250,500,8'h80,7,3);
        @(negedge clk); in_valid=0;
        wait(received==sent);
        update_alarm(2,3,0); if(!alarm || !beep || disabled_beep)$fatal(1,"Outside did not activate buzzer");
        repeat(500)@(negedge clk);
        if(beep)$fatal(1,"Buzzer quiet half-period missing");
        repeat(500)@(negedge clk);
        if(!beep)$fatal(1,"Buzzer repeat missing");
        update_alarm(3,1,0); if(!alarm)$fatal(1,"Another safe tag cleared T2 alarm");
        update_alarm(2,0,1); if(!alarm)$fatal(1,"Invalid data cleared alarm");
        update_alarm(3,3,0);
        update_alarm(2,1,0); if(alarm_tags!==9'b000001000)$fatal(1,"Per-tag alarm clear failed");
        update_alarm(255,3,0); if(alarm_tags!==9'b000001000)$fatal(1,"Invalid ID changed latch");
        update_alarm(3,1,0); if(alarm || beep)$fatal(1,"Safe return did not stop alarm");
        rst_n=0; #1;
        if(alarm || beep)$fatal(1,"Reset did not clear latch/output");
        $display("PASS tb_geofence: %0d pipelined records, CCW/CW/boundary/vertices/overflow/invalid/multitag/alarm/buzzer",received);
        $finish;
    end
    initial begin #10000000; $fatal(1,"Geofence unit timeout"); end
endmodule
