`timescale 1ns/1ps
module tb_ai_system;
    parameter integer CLK_HZ=2_000_000,BAUD=100000;
    localparam integer BIT_NS=1_000_000_000/BAUD;
    reg clk=0,rst_n=0,uwb_rx=1,pc_rx=1;
    wire tx,beep;
    always #(500_000_000/CLK_HZ)clk=~clk;
    uwb_ai_top #(.CLK_HZ(CLK_HZ),.UWB_BAUD(BAUD),.PC_BAUD(BAUD),.CLEAR_HITS(1),.CLEAR_MARGIN_MM(0),.QUALITY_ENABLE(0),.FAULT_ENABLE(0),.FENCE_CONFIRM(1),.AI_EARLY_BEEP(1),.WATCHDOG_CYCLES(CLK_HZ/10))dut(
        .sys_clk(clk),.sys_rst_n(rst_n),.uwb_rx(uwb_rx),.pc_rx(pc_rx),.pc_tx(tx),.beep(beep));
    function automatic [15:0] crc_next(input [15:0] previous,input [7:0] value);
        reg[15:0] c;
        begin c=previous^{value,8'h00};for(integer i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crc_next=c;end
    endfunction
    reg[7:0]packet[0:41],byte_value;
    integer count=0,target=0,ack_count=0,telemetry_count=0,capture=0,seq;
    reg[15:0]check_crc;
    integer exp_state[0:20],exp_result[0:20];
    string path;
    reg [7:0]model_commands[0:35];
    string model_path;
    integer use_model_commands=0;
    initial begin
        if($value$plusargs("CAPTURE=%s",path))capture=$fopen(path,"w");
        if($value$plusargs("MODEL_COMMANDS=%s",model_path))begin
            $readmemh(model_path,model_commands);use_model_commands=1;
        end
        for(integer i=0;i<21;i=i+1)begin exp_state[i]=0;exp_result[i]=0;end
        exp_state[2]=17;exp_state[4]=17;exp_result[4]=1;exp_state[5]=16;
        exp_state[6]=18;exp_state[8]=16;exp_result[12]=2;
    end
    initial forever begin
        @(negedge tx);#(BIT_NS+BIT_NS/2);
        for(integer i=0;i<8;i=i+1)begin byte_value[i]=tx;#(BIT_NS);end
        if(tx!==1)$fatal(1,"AI UART stop bit");
        packet[count]=byte_value;count=count+1;
        if(count==3)begin
            if(packet[0]!==8'h55 || packet[1]!==8'haa)$fatal(1,"AI frame alignment");
            if(packet[2]==3)target=42;else if(packet[2]==8'h11)target=18;else $fatal(1,"AI version");
        end
        if(target && count==target)begin
            check_crc=16'hffff;for(integer i=0;i<target-2;i=i+1)check_crc=crc_next(check_crc,packet[i]);
            if({packet[target-1],packet[target-2]}!==check_crc)$fatal(1,"AI frame CRC");
            if(target==18)begin
                seq={packet[5],packet[4]};
                if(seq==3 || seq>12 || (packet[6]&8'h13)!==exp_state[seq] || packet[7]!==exp_result[seq])
                    $fatal(1,"AI ACK state seq=%0d got=%0d want=%0d result=%0d",seq,packet[6],exp_state[seq],packet[7]);
                if({packet[11],packet[10],packet[9],packet[8]}!==(32'h12340000+seq))$fatal(1,"AI echo token");
                if((seq==8 || seq==9) && !packet[6][2])$fatal(1,"PC cleared local geofence");
                ack_count=ack_count+1;
            end else begin
                if({packet[31],packet[30],packet[29],packet[28]}!==32'd0)$fatal(1,"AI site tag height must be zero");
                if(packet[33]!==((telemetry_count==1)?8'd3:8'd1))$fatal(1,"AI V3 fence flags");
                telemetry_count=telemetry_count+1;
            end
            if(capture)begin for(integer i=0;i<target;i=i+1)$fwrite(capture,"%02x",packet[i]);$fwrite(capture,"\n");end
            count=0;target=0;
        end
    end
    task automatic send_pc_byte(input [7:0]value);
        begin pc_rx=0;#(BIT_NS);for(integer i=0;i<8;i=i+1)begin pc_rx=value[i];#(BIT_NS);end pc_rx=1;#(BIT_NS);end
    endtask
    task automatic model_command(input integer offset,sequence_number,alarm);
        begin
            if(use_model_commands)for(integer i=0;i<18;i=i+1)send_pc_byte(model_commands[offset+i]);
            else command(1,sequence_number,alarm,0,0);
        end
    endtask
    task automatic command(input integer opcode,sequence_number,alarm,bad_crc,bad_reserved);
        reg [127:0]payload;reg[15:0]crc;
        begin
            payload={32'b0,(32'h12340000+sequence_number),8'(bad_reserved),8'(alarm),16'(sequence_number),8'(opcode),8'h10,16'haa55};
            crc=16'hffff;
            for(integer i=0;i<16;i=i+1)begin send_pc_byte(payload[i*8+:8]);crc=crc_next(crc,payload[i*8+:8]);end
            send_pc_byte(crc[7:0]^(bad_crc ? 8'h01:8'h00));send_pc_byte(crc[15:8]);
        end
    endtask
    task automatic send_mc(input integer r0,r1,r2,number);
        string line;reg[7:0]value;
        begin
            value=number;
            line=$sformatf("mc 07 %08x %08x %08x 00000000 0001 %02x 00000000 a2:0\015\012",r0,r1,r2,value);
            for(integer i=0;i<line.len();i=i+1)begin
                value=line[i];uwb_rx=0;#(BIT_NS);for(integer j=0;j<8;j=j+1)begin uwb_rx=value[j];#(BIT_NS);end uwb_rx=1;#(BIT_NS);
            end
        end
    endtask
    initial begin
        repeat(20)@(posedge clk);rst_n=1;repeat(20)@(posedge clk);
        fork command(0,1,0,0,0);send_mc(1993,1993,2014,1);join
        wait(ack_count==1 && telemetry_count==1);
        model_command(0,2,1);wait(ack_count==2);if(!beep)$fatal(1,"AI alarm did not drive buzzer");
        command(1,3,0,1,0);#3000000;if(ack_count!=2 || !dut.link.warning_reg)$fatal(1,"Bad CRC executed");
        command(99,4,0,0,0);wait(ack_count==3);
        model_command(18,5,0);wait(ack_count==4);if(beep)$fatal(1,"AI safe SET did not clear host warning");
        #110000000;if(beep || !dut.link.watchdog_fault)$fatal(1,"AI watchdog must remain diagnostic-only");
        command(0,6,0,0,0);wait(ack_count==5);
        command(2,7,0,0,0);wait(ack_count==6);if(beep)$fatal(1,"AI release failed");
        fork send_mc(3082,1871,1790,2);begin #(BIT_NS*720);command(1,8,0,0,0);end join
        wait(telemetry_count==2 && ack_count==7);if(!beep)$fatal(1,"PC suppressed local alarm");
        command(2,9,0,0,0);wait(ack_count==8);if(!beep)$fatal(1,"Release suppressed local alarm");
        send_mc(1993,1993,2014,3);wait(telemetry_count==3);if(beep)$fatal(1,"Local safe return failed");
        send_pc_byte(8'h55);send_pc_byte(8'haa);send_pc_byte(8'h10);#60000000;
        command(0,10,0,0,0);wait(ack_count==9);
        pc_rx=0;#(BIT_NS*12);pc_rx=1;#(BIT_NS*3);
        command(0,11,0,0,0);wait(ack_count==10);
        command(1,12,1,0,1);wait(ack_count==11);if(beep)$fatal(1,"Invalid reserved byte executed");
        #1000000;if(capture)$fclose(capture);
        $display("PASS tb_ai_system: V3/ACK atomic mux, CRC, token, AI warning, watchdog, local safety, invalid/partial/framing recovery");$finish;
    end
    initial begin #1000000000;$fatal(1,"AI test timeout");end
endmodule
