`timescale 1ns/1ps
// Independent ESP wire model. All network settings here are fictitious.
module tb_ai_wifi_system;
    parameter integer CLK_HZ=2_000_000,BAUD=100000,LEGACY_CUR=1;
    localparam integer BIT_NS=1_000_000_000/BAUD,JOIN_N=LEGACY_CUR ? 32 : 28;
    localparam[2047:0]JOIN=LEGACY_CUR ? "AT+CWJAP_CUR=\"lab\",\"secret123\"\015\012" : "AT+CWJAP=\"lab\",\"secret123\"\015\012";
    localparam[1023:0]TCP="AT+CIPSTART=\"TCP\",\"172.20.10.4\",9000,5\015\012";
    reg [95:0] core_xyz[0:255];
    always @(posedge clk)if(dut.record_valid && dut.record_ready && dut.record_data[15:8]==7)
        core_xyz[dut.record_data[23:16]]<=dut.record_data[223:128];
    reg clk=0,rst_n=0,uwb_rx=1,esp_rx=1;
    wire esp_tx,beep;tri1 esp_rst_n;
    always #(500_000_000/CLK_HZ)clk=~clk;
    uwb_ai_wifi_top #(.CLK_HZ(CLK_HZ),.UWB_BAUD(BAUD),.PC_BAUD(BAUD),.CLEAR_HITS(1),.CLEAR_MARGIN_MM(0),.QUALITY_ENABLE(0),.FAULT_ENABLE(0),.LEGACY_CUR(LEGACY_CUR),.FENCE_CONFIRM(1),.AI_EARLY_BEEP(1),
        .JOIN_LEN(JOIN_N),.JOIN_COMMAND(JOIN),.TCP_LEN(40),.TCP_COMMAND(TCP),.WATCHDOG_CYCLES(CLK_HZ/10),
        .RESET_MS(2),.BOOT_MS(2),.GUARD_MS(2),.FLUSH_MS(2),.RETRY_MS(3),
        .ACK_TIMEOUT_MS(12),.JOIN_TIMEOUT_MS(15),.TCP_TIMEOUT_MS(15),.SEND_TIMEOUT_MS(15),.POLL_MS(30))dut(
        .sys_clk(clk),.sys_rst_n(rst_n),.uwb_rx(uwb_rx),.esp_rx(esp_rx),.esp_tx(esp_tx),.esp_rst_n(esp_rst_n),.beep(beep));
    function automatic[15:0]crc_next(input[15:0]previous,input[7:0]value);
        reg[15:0]c;
        begin c=previous^{value,8'h00};for(integer i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crc_next=c;end
    endfunction
    integer esp_locked=0;
    task automatic raw_byte(input[7:0]b);
        begin esp_rx=0;#(BIT_NS);for(integer j=0;j<8;j=j+1)begin esp_rx=b[j];#(BIT_NS);end esp_rx=1;#(BIT_NS);end
    endtask
    task automatic esp_text(input string s);
        begin
            while(esp_locked)@(negedge esp_locked);esp_locked=1;
            for(integer i=0;i<s.len();i=i+1)raw_byte(s[i]);esp_locked=0;
        end
    endtask
    reg[7:0]down[0:255];
    task automatic make_command(input integer offset,opcode,seq,alarm,bad_crc);
        reg[127:0]body;reg[15:0]c;
        begin
            body={32'b0,(32'h12340000+seq),8'b0,8'(alarm),16'(seq),8'(opcode),8'h10,16'haa55};c=16'hffff;
            for(integer i=0;i<16;i=i+1)begin down[offset+i]=body[i*8+:8];c=crc_next(c,down[offset+i]);end
            down[offset+16]=c[7:0]^(bad_crc ? 1:0);down[offset+17]=c[15:8];
        end
    endtask
    task automatic ipd(input integer offset,length);
        string header;
        begin
            while(esp_locked)@(negedge esp_locked);esp_locked=1;
            header=$sformatf("+IPD,%0d:",length);
            for(integer i=0;i<header.len();i=i+1)raw_byte(header[i]);
            for(integer i=0;i<length;i=i+1)raw_byte(down[offset+i]);
            esp_locked=0;
        end
    endtask
    task automatic command(input integer opcode,seq,alarm);
        begin make_command(0,opcode,seq,alarm,0);ipd(0,18);end
    endtask
    task automatic measurement(input integer r0,r1,r2,seq);
        string s;reg[7:0]b,n;
        begin
            n=seq;s=$sformatf("mc 07 %08x %08x %08x 00000000 0001 %02x 00000000 t2:0\015\012",r0,r1,r2,n);
            for(integer i=0;i<s.len();i=i+1)begin
                b=s[i];uwb_rx=0;#(BIT_NS);for(integer j=0;j<8;j=j+1)begin uwb_rx=b[j];#(BIT_NS);end uwb_rx=1;#(BIT_NS);
            end
        end
    endtask
    integer command_toggle=0,handled_toggle=0,payload_mode=0,payload_count=0,send_length=0;
    integer packet_count=0,telemetry_count=0,ack_count=0,ipdinfo_count=0,capture=0;
    integer seen_ack[0:31],ack_state[0:31];
    reg[2047:0]command_buffer=0,pending_command=0,current_command=0;
    reg[7:0]bytes_in[0:41],byte_in;
    reg[15:0]check_crc;
    integer ack_seq,old_retry;
    string capture_path,junk;
    initial begin
        for(integer i=0;i<32;i=i+1)begin seen_ack[i]=0;ack_state[i]=0;end
        if($value$plusargs("CAPTURE=%s",capture_path))capture=$fopen(capture_path,"w");
    end
    always @(negedge esp_rst_n)begin command_buffer=0;payload_mode=0;payload_count=0;end
    initial forever begin
        @(negedge esp_tx);#(BIT_NS+BIT_NS/2);
        for(integer i=0;i<8;i=i+1)begin byte_in[i]=esp_tx;#(BIT_NS);end
        if(esp_tx!==1)$fatal(1,"AI WiFi stop bit");
        if(payload_mode)begin
            bytes_in[payload_count]=byte_in;payload_count=payload_count+1;
            if(payload_count==send_length)begin
                if(bytes_in[0]!==8'h55 || bytes_in[1]!==8'haa ||
                   (send_length==18 && bytes_in[2]!==8'h11) || (send_length==42 && bytes_in[2]!==3))$fatal(1,"AI WiFi frame header");
                check_crc=16'hffff;for(integer i=0;i<send_length-2;i=i+1)check_crc=crc_next(check_crc,bytes_in[i]);
                if({bytes_in[send_length-1],bytes_in[send_length-2]}!==check_crc)$fatal(1,"AI WiFi CRC");
                if(send_length==18)begin
                    ack_seq={bytes_in[5],bytes_in[4]};if(ack_seq>31)$fatal(1,"AI WiFi ACK sequence");
                    if({bytes_in[11],bytes_in[10],bytes_in[9],bytes_in[8]}!==(32'h12340000+ack_seq))$fatal(1,"AI WiFi ACK token");
                    seen_ack[ack_seq]=seen_ack[ack_seq]+1;ack_state[ack_seq]=bytes_in[6];ack_count=ack_count+1;
                end else begin
                    for(integer c=20;c<=28;c=c+4)
                        if({bytes_in[c+3],bytes_in[c+2],bytes_in[c+1],bytes_in[c]}!==core_xyz[bytes_in[5]][(c-20)*8+:32])
                            $fatal(1,"Actual WiFi XYZ differs from internal millimeters");
                    if({bytes_in[31],bytes_in[30],bytes_in[29],bytes_in[28]}!==32'd0)$fatal(1,"AI WiFi site tag height must be zero");
                    if(bytes_in[6]!==2 || bytes_in[33]!==(bytes_in[5]==3 ? 8'd3 : 8'd1))$fatal(1,"AI WiFi telemetry flags");
                    telemetry_count=telemetry_count+1;
                end
                if(capture)begin for(integer i=0;i<send_length;i=i+1)$fwrite(capture,"%02x",bytes_in[i]);$fwrite(capture,"\n");end
                packet_count=packet_count+1;payload_count=0;payload_mode=0;
            end
        end else if(byte_in==10)begin pending_command=command_buffer;command_buffer=0;command_toggle=command_toggle+1;end
        else if(byte_in!=13)command_buffer={command_buffer[2039:0],byte_in};
    end
    initial forever begin
        wait(command_toggle!=handled_toggle);handled_toggle=command_toggle;current_command=pending_command;#(BIT_NS*2);
        if($test$plusargs("TRACE"))$display("AIW AT [%0s]",current_command);
        case(current_command)
            "+++","AT+CIPCLOSE":esp_text("\015\012ERROR\015\012");
            "AT","ATE0","AT+CIPMODE=0","AT+CIPMUX=0","AT+SLEEP=0","AT+SYSSTORE=0",
            "AT+CWMODE_CUR=1","AT+CWMODE=1","AT+CWDHCP_CUR=1,1","AT+CWDHCP=1,1":esp_text("\015\012OK\015\012");
            "AT+GMR":esp_text("\015\012AT version:mock\015\012OK\015\012");
            "AT+CIPDINFO=0":begin ipdinfo_count=ipdinfo_count+1;esp_text("\015\012OK\015\012");end
            "AT+CWJAP_CUR=\"lab\",\"secret123\"","AT+CWJAP=\"lab\",\"secret123\"":esp_text("\015\012WIFI CONNECTED\015\012WIFI GOT IP\015\012OK\015\012");
            "AT+CIPSTART=\"TCP\",\"172.20.10.4\",9000,5":esp_text("\015\012CONNECT\015\012OK\015\012");
            "AT+CIPSTATUS":esp_text("\015\012STATUS:3\015\012OK\015\012");
            "AT+CIPSEND=18","AT+CIPSEND=42":begin
                if(current_command=="AT+CIPSEND=18")send_length=18;else send_length=42;
                payload_mode=1;esp_text("\015\012OK\015\012> ");wait(payload_mode==0);#(BIT_NS*2);esp_text("\015\012SEND OK\015\012");
            end
            default:$fatal(1,"Unexpected AI WiFi AT command [%0s]",current_command);
        endcase
    end
    initial begin
        repeat(20)@(posedge clk);rst_n=1;
        measurement(3082,1871,1790,1);
        #300000;
        if(!beep)$fatal(1,"Local fence unavailable offline");
        wait(dut.online);#(BIT_NS*5);
        if(!beep || ipdinfo_count==0)$fatal(1,"Local alarm lost during connect");
        measurement(1993,1993,2014,2);wait(telemetry_count==1);if(beep)$fatal(1,"Safe return");
        junk="\015\012CLOSED\015\012SEND OK\015\012";
        for(integer i=0;i<junk.len();i=i+1)down[i]=junk[i];ipd(0,junk.len());
        #100000;if(!dut.online)$fatal(1,"Binary IPD reached AT parser");
        make_command(0,0,1,0,0);ipd(0,7);#200000;ipd(7,11);wait(seen_ack[1]);
        make_command(0,0,2,0,0);make_command(18,0,3,0,0);ipd(0,36);wait(seen_ack[2] && seen_ack[3]);
        command(1,4,1);wait(seen_ack[4]);if(!beep || (ack_state[4]&19)!=17)$fatal(1,"AI WiFi warning");
        make_command(0,1,30,0,1);ipd(0,18);#3000000;
        if(seen_ack[30] || !dut.router.warning_reg)$fatal(1,"Bad CRC executed over WiFi");
        command(1,5,0);wait(seen_ack[5]);if(beep)$fatal(1,"AI WiFi clear warning");
        #110000000;if(beep || !dut.router.watchdog_fault)$fatal(1,"WiFi control watchdog must be silent");
        command(0,6,0);wait(seen_ack[6]);if((ack_state[6]&19)!=18)$fatal(1,"WiFi watchdog ACK");
        command(2,7,0);wait(seen_ack[7]);if(beep)$fatal(1,"WiFi release");
        measurement(3082,1871,1790,3);wait(telemetry_count==2);
        command(1,8,0);wait(seen_ack[8]);command(2,9,0);wait(seen_ack[9]);
        if(!beep || !(ack_state[8]&4) || !(ack_state[9]&4))$fatal(1,"WiFi PC suppressed local fence");
        measurement(1993,1993,2014,4);wait(telemetry_count==3);if(beep)$fatal(1,"WiFi local safe return");
        command(1,10,1);wait(seen_ack[10]);old_retry=dut.retry_count;
        esp_text("\015\012WIFI DISCONNECT\015\012");wait(dut.retry_count>old_retry);wait(dut.online);#110000000;
        if(beep || !dut.router.watchdog_fault)$fatal(1,"Network fault must be retained without buzzing");
        command(0,11,0);wait(seen_ack[11]);command(2,12,0);wait(seen_ack[12]);if(beep)$fatal(1,"WiFi recovery release");
        old_retry=dut.retry_count;esp_text("+IPD,x:\015\012");wait(dut.retry_count>old_retry);wait(dut.online);
        command(0,13,0);wait(seen_ack[13]);
        make_command(0,1,14,1,0);ipd(0,9);old_retry=dut.retry_count;
        esp_text("\015\012CLOSED\015\012");wait(dut.retry_count>old_retry);wait(dut.online);
        ipd(9,9);command(0,15,0);wait(seen_ack[15]);
        if(seen_ack[14] || dut.router.armed || beep)$fatal(1,"Replayed partial old control after reconnect");
        #1000000;if(capture)$fclose(capture);
        $display("PASS tb_ai_wifi_system: profile=%0d, V3=%0d ACK=%0d, duplex IPD split/coalesced/binary isolation/CRC/local safety/watchdog/reconnect",LEGACY_CUR,telemetry_count,ack_count);$finish;
    end
    initial begin #2000000000;$fatal(1,"AI WiFi timeout ack=%0d tele=%0d retry=%0d state=%0d",ack_count,telemetry_count,dut.retry_count,dut.wifi.state);end
endmodule
