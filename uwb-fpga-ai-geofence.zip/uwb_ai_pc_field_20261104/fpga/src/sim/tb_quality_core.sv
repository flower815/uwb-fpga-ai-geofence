`timescale 1ns/1ps
module tb_quality_core;
    reg clk=0,rst_n=0,rx=1;always #250 clk=~clk;
    wire[287:0]data;wire valid,alarm,fault;
    uwb_position_core #(.CLK_HZ(2000000),.UWB_BAUD(100000),.X1(3000),.X2(1500),.Y2(2600),
        .Z0(1000),.Z1(1000),.Z2(1000),.TAG_Z(0),.ENABLE_ANGLES(1),.ENABLE_FENCE(1),.RANGE_FILTER(1),
        .FENCE_CONFIRM(3),.CLEAR_HITS(1),.CLEAR_MARGIN_MM(0),.QUALITY_ENABLE(1),.QUALITY_LIMIT_MM(200),
        .FAULT_ENABLE(1),.FAULT_TIMEOUT_MS(40),.FAULT_STARTUP_MS(60)) dut(
        .clk(clk),.rst_n(rst_n),.uwb_rx(rx),.stream_enable(1'b1),.record_out(data),
        .record_valid(valid),.record_ready(1'b1),.fence_alarm(alarm),.position_fault(fault));
    integer heartbeats=0,held=0,measurements=0;
    always @(posedge clk)if(valid)begin
        if(data[6:0]!=0 && (data[231:224]!==0 || data[287:240]!==48'hffffffffffff))
            $fatal(1,"Invalid measurement retained angles");
        if(data[15:8]==0)begin
            heartbeats=heartbeats+1;
            if(data[239:232]==36)held=held+1;
            if(data[7:0]!==16 || (data[239:232]!==32 && data[239:232]!==36))$fatal(1,"Bad heartbeat");
        end else measurements=measurements+1;
    end
    task automatic line(input integer id,s,a,b,c);
        string text;reg[7:0]tag_byte,seq_byte,v;reg[15:0]word_seq;
        begin
            tag_byte=8'd48+id;seq_byte=s;word_seq=s;
            text=$sformatf("mc 07 %08x %08x %08x 00000000 %04x %02x 00000000 a%c:0\015\012",a,b,c,word_seq,seq_byte,tag_byte);
            for(integer i=0;i<text.len();i=i+1)begin v=text[i];rx=0;#10000;for(integer j=0;j<8;j=j+1)begin rx=v[j];#10000;end rx=1;#10000;end
            #300000;
        end
    endtask
    initial begin
        #2000;rst_n=1;#65000000;if(!fault)$fatal(1,"Missing startup fault");
        line(2,1,2000,2000,2000);line(2,3,2000,2000,2000);
        if(!fault)$fatal(1,"Recovery needs three fresh measurements");
        line(2,5,2000,2000,2000);if(fault)$fatal(1,"Forward-gap recovery failed");
        // Many boundary candidates over >timeout must not cause localization failure.
        for(integer i=0;i<4;i=i+1)begin
            line(2,7+i*6,3271,1049,2973);
            line(2,9+i*6,2000,2000,2000);
            line(2,11+i*6,2000,2000,2000);
            if(fault || alarm)$fatal(1,"Fence uncertainty caused health failure / false alarm");
        end
        line(2,31,3271,1049,2973);line(2,33,3271,1049,2973);
        if(alarm)$fatal(1,"Alarm before third fresh sample");
        line(2,35,3271,1049,2973);if(!alarm || fault)$fatal(1,"Gap-tolerant third outside failed");
        #45000000;if(!fault || !alarm)$fatal(1,"Outage lost confirmed alarm");
        line(3,1,2000,2000,2000);if(!fault)$fatal(1,"Wrong tag recovered health");
        line(2,37,3271,1049,2973);line(2,39,3271,1049,2973);line(2,41,3271,1049,2973);
        if(fault || !alarm)$fatal(1,"Outside gap recovery failed");
        line(2,43,2000,2000,2000);line(2,45,2000,2000,2000);if(alarm)$fatal(1,"Valid inside did not clear");
        for(integer i=0;i<8;i=i+1)line(2,45,2000,2000,2000);
        if(!fault)$fatal(1,"Duplicate stream fed health");
        line(2,47,2000,2000,2000);line(2,49,2000,2000,2000);line(2,51,2000,2000,2000);
        if(fault)$fatal(1,"Recovery after duplicates failed");
        for(integer i=0;i<7;i=i+1)line(2,53+i*2,5000,5000,5000);
        if(!fault)$fatal(1,"Bad-quality stream fed health");
        if(heartbeats<2 || measurements<30)$fatal(1,"Coverage totals too small");
        $display("PASS tb_quality_core: health independent of fence, gap2 median/recovery/outside3, invalid/duplicate/outage protection and retained alarm");$finish;
    end
    initial begin #1000000000;$fatal(1,"Quality core timeout");end
endmodule
