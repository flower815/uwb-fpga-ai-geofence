`timescale 1ns/1ps
module tb_ipd_demux;
    reg clk=0,rst_n=0,valid=0,fault=0;
    reg[7:0]data=0;
    wire[7:0]text_data,app_data;wire text_valid,text_clear,app_valid,error;
    always #5 clk=~clk;
    esp_ipd_demux #(.CLK_HZ(1000),.GAP_CYCLES(20))dut(.clk(clk),.rst_n(rst_n),.in_data(data),.in_valid(valid),.in_error(fault),
        .text_data(text_data),.text_valid(text_valid),.text_clear(text_clear),.app_data(app_data),.app_valid(app_valid),.error(error));
    reg[7:0]expected[0:4095];integer pending=0,received=0,errors=0,text_bytes=0;
    always @(posedge clk)begin
        if(app_valid)begin
            if(received>=pending || app_data!==expected[received])$fatal(1,"IPD data mismatch %0d",received);
            received=received+1;
        end
        if(error)errors=errors+1;
        if(text_valid)text_bytes=text_bytes+1;
    end
    task automatic put(input[7:0]value);
        begin @(negedge clk);data=value;valid=1;@(negedge clk);valid=0;end
    endtask
    task automatic text(input string s);
        begin for(integer i=0;i<s.len();i=i+1)put(s[i]);end
    endtask
    initial begin
        repeat(3)@(negedge clk);rst_n=1;
        text("OK\015\012");text("+IPD,0:");
        text("+IPD,256:");
        for(integer i=0;i<256;i=i+1)begin expected[pending]=i;pending=pending+1;put(i);end
        text("+IPD,2048:");
        for(integer i=0;i<2048;i=i+1)begin expected[pending]=(i*73)^8'h5a;pending=pending+1;put(expected[pending-1]);end
        text("+UNKNOWNOK\012");repeat(3)@(negedge clk);
        if(text_bytes!=4 || received!=2304 || errors)$fatal(1,"IPD text/binary isolation");
        text("+IPD,x:\012");text("+IPD,65536:\012");
        text("+IPD,2:");expected[pending]=8'h4f;pending=pending+1;put(8'h4f);
        repeat(25)@(negedge clk);text("\012");
        @(negedge clk);fault=1;@(negedge clk);fault=0;text("\012");
        text("+IPD,1:");expected[pending]=8'h99;pending=pending+1;put(8'h99);
        repeat(5)@(negedge clk);
        if(errors<4 || received!=pending)$fatal(1,"IPD malformed/timeout/framing recovery");
        $display("PASS tb_ipd_demux: 2306 exact binary bytes, all byte values, 2048-byte chunk, zero length, malformed/overflow/timeout/framing isolation");$finish;
    end
    initial begin #1000000;$fatal(1,"IPD unit timeout");end
endmodule
