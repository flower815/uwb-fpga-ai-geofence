`timescale 1ns/1ps
module tb_fence_confirm;
    reg clk=0,rst_n=0,valid=0;
    always #5 clk=~clk;
    reg[287:0]record_in=0;
    wire alarm,next_alarm;wire[8:0]tags;wire[1:0]hits;
    geofence_alarm #(.CONFIRM_HITS(3),.GAP_CYCLES(20)) dut(clk,rst_n,valid,record_in,alarm,tags,next_alarm,hits,1'b1);
    integer checks=0;
    task automatic sample(input integer t,s,f,a,h);
        begin
            @(negedge clk);record_in=0;record_in[31:24]=t;record_in[23:16]=s;
            record_in[15:8]=7;record_in[239:232]=f;valid=1;
            if(f==0)record_in[7:0]=1;
            #1;if(next_alarm!==a || hits!==h)$fatal(1,"Confirmation prediction %0d: %0d %0d",checks,next_alarm,hits);
            @(posedge clk);#1;if(tags[t]!==a)$fatal(1,"Confirmation latch %0d",checks);
            checks=checks+1;@(negedge clk);valid=0;
        end
    endtask
    initial begin
        #20;rst_n=1;
        sample(2,1,3,0,1);sample(2,2,3,0,2);sample(2,3,1,0,0);
        sample(2,4,3,0,1);sample(2,5,3,0,2);sample(2,6,3,1,3);
        sample(2,7,0,1,0);sample(2,8,3,1,1);sample(2,9,1,0,0);
        sample(3,254,3,0,1);sample(4,1,3,0,1);sample(3,255,3,0,2);sample(3,0,3,1,3);
        repeat(22)@(posedge clk);
        sample(2,1,3,0,1);sample(2,1,3,0,1);sample(2,2,3,0,2);
        repeat(22)@(posedge clk);
        sample(2,3,3,0,1);sample(2,4,3,0,2);sample(2,5,0,0,0);
        sample(2,6,3,0,1);sample(2,9,3,0,2);
        sample(2,8,1,0,2); // Backwards inside cannot reset votes.
        sample(2,11,3,1,3);
        sample(2,10,1,1,3); // Nor can it clear an alarm.
        sample(2,13,1,0,0);
        if(tags[4] || !tags[3])$fatal(1,"Tag isolation failed");
        $display("PASS tb_fence_confirm: %0d records, third-only, return reset, invalid hold/reset, duplicate, gap, sequence wrap and tag isolation",checks);$finish;
    end
endmodule
