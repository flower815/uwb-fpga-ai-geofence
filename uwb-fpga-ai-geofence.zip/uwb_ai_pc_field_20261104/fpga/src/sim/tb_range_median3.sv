`timescale 1ns/1ps
module tb_range_median3;
    reg clk=0,rst_n=0,valid=0;
    always #5 clk=~clk;
    reg [7:0]mask=7,seq=0,tag=2;
    reg [31:0]d0=0,d1=0,d2=0;
    wire out_valid;wire[7:0]om,os,ot;wire[31:0]o0,o1,o2,r0,r1,r2;
    range_median3 #(.GAP_CYCLES(40)) dut(clk,rst_n,valid,mask,seq,tag,d0,d1,d2,
        out_valid,om,os,ot,o0,o1,o2,r0,r1,r2);
    integer checks=0;
    task automatic sample(input integer t,s,m,a,b,c,x,y,z);
        begin
            @(negedge clk);tag=t;seq=s;mask=m;d0=a;d1=b;d2=c;valid=1;
            @(posedge clk);#1;
            if(!out_valid || {om,os,ot}!=={mask,seq,tag} || {r0,r1,r2}!=={d0,d1,d2} ||
                o0!==x || o1!==y || o2!==z)$fatal(1,"Median sample %0d failed got %0d %0d %0d",checks,o0,o1,o2);
            checks=checks+1;@(negedge clk);valid=0;
        end
    endtask
    integer a,b,c,lo,mid,hi,tmp;
    initial begin
        #20;rst_n=1;
        sample(2,254,7,100,300,200,100,300,200);
        sample(2,255,7,200,100,300,200,100,300);
        sample(3,1,7,900,900,900,900,900,900);
        sample(2,0,7,300,200,100,200,200,200);
        sample(2,1,1,0,0,0,0,0,0);
        sample(2,2,7,777,888,999,777,888,999);
        sample(2,8,7,1,2,3,1,2,3);
        sample(2,9,7,9,8,7,9,8,7);
        sample(2,10,7,4,5,6,4,5,6);
        repeat(42)@(posedge clk);
        sample(2,11,7,123,456,789,123,456,789);
        sample(2,12,7,32'hffffffff,100,200,32'hffffffff,100,200);
        sample(2,13,7,60001,100,200,60001,100,200);
        for(integer i=0;i<80;i=i+1)begin
            a=$urandom_range(60000,1);b=$urandom_range(60000,1);c=$urandom_range(60000,1);
            lo=a;mid=b;hi=c;
            if(lo>mid)begin tmp=lo;lo=mid;mid=tmp;end
            if(mid>hi)begin tmp=mid;mid=hi;hi=tmp;end
            if(lo>mid)begin tmp=lo;lo=mid;mid=tmp;end
            sample(4,(i*6)&255,7,a,a,a,a,a,a);
            sample(4,(i*6+2)&255,7,b,b,b,b,b,b);
            sample(4,(i*6+4)&255,7,c,c,c,mid,mid,mid);
            repeat(42)@(posedge clk);
        end
        $display("PASS tb_range_median3: %0d samples, independent sorted references, tag isolation, wrap, gap, invalid and discontinuity",checks);$finish;
    end
endmodule
