`timescale 1ns/1ps
module tb_clear_hysteresis;
    reg clk=0,rst_n=0,valid=0,deep=0;always #5 clk=~clk;
    reg[287:0]data=0;wire alarm,pred;wire[8:0]tags;wire[1:0]hits;
    geofence_alarm #(.CONFIRM_HITS(3),.CLEAR_HITS(3),.GAP_CYCLES(40)) dut(
        .clk(clk),.rst_n(rst_n),.record_valid(valid),.record_in(data),.alarm(alarm),
        .alarm_tags(tags),.record_alarm(pred),.record_hits(hits),.clear_ok(deep));
    integer count=0;
    task automatic sample(input integer t,s,f,inset,expected);
        begin
            @(negedge clk);data=0;data[31:24]=t;data[23:16]=s;data[15:8]=7;data[239:232]=f;
            if(f==0)data[7:0]=1;deep=inset;valid=1;
            #1;if(pred!==expected)$fatal(1,"Clear prediction %0d",count);
            @(posedge clk);#1;if(tags[t]!==expected)$fatal(1,"Clear latch %0d",count);
            count=count+1;@(negedge clk);valid=0;
        end
    endtask
    initial begin
        #20;rst_n=1;
        sample(2,1,3,0,0);sample(2,2,3,0,0);sample(2,3,3,0,1);
        sample(2,4,1,0,1);sample(2,5,1,0,1);sample(2,6,1,0,1);
        sample(2,7,1,1,1);sample(2,8,1,1,1);sample(2,8,1,1,1);sample(2,9,1,1,0);
        sample(2,10,3,0,0);sample(2,11,3,0,0);sample(2,12,3,0,1);
        sample(2,13,1,1,1);sample(2,14,0,1,1);sample(2,15,1,1,1);sample(2,16,1,1,1);sample(2,17,1,1,0);
        sample(3,1,3,0,0);sample(3,2,3,0,0);sample(3,3,3,0,1);
        sample(2,18,1,1,0);
        if(!tags[3])$fatal(1,"Cross-tag clear");
        $display("PASS tb_clear_hysteresis: %0d records, shallow no-clear, third-deep clear, duplicate and invalid separation",count);$finish;
    end
endmodule
