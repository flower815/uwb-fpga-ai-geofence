`timescale 1ns/1ps
module tb_fifo;
    reg clk=0,rst_n=0,iv=0,orr=0;
    reg [223:0] id=0;
    wire ir,ov;
    wire [223:0] od;
    integer next_out=0;
    always #5 clk=~clk;
    record_fifo dut(.clk(clk),.rst_n(rst_n),.in_data(id),.in_valid(iv),.in_ready(ir),
        .out_data(od),.out_valid(ov),.out_ready(orr));
    always @(posedge clk) if(rst_n && ov && orr) begin
        if(od!==next_out) $fatal(1,"FIFO out-of-order: %0d expected %0d",od,next_out);
        next_out=next_out+1;
    end
    initial begin
        #30; @(negedge clk);rst_n=1;
        for(integer i=0;i<16;i=i+1) begin
            @(negedge clk);iv=1;id=i;
        end
        @(negedge clk);iv=0;
        if(ir!==0) $fatal(1,"FIFO should be full");
        iv=1;id=999; repeat(3) @(negedge clk); iv=0;
        orr=1; repeat(16) @(negedge clk);orr=0;
        if(ov!==0 || next_out!=16) $fatal(1,"FIFO should be empty");
        for(integer i=16;i<116;i=i+1) begin
            @(negedge clk);iv=1;orr=1;id=i;
        end
        @(negedge clk);iv=0;
        repeat(3) @(negedge clk);
        if(next_out!=116) $fatal(1,"FIFO simultaneous push/pop failed");
        orr=0;
        for(integer i=116;i<132;i=i+1) begin
            @(negedge clk);iv=1;id=i;
        end
        @(negedge clk);iv=0;
        if(ir!==0) $fatal(1,"FIFO should be full before replacement");
        iv=1;orr=1;id=132;
        #1;
        if(ir!==1) $fatal(1,"Full FIFO must accept a simultaneous pop/push");
        @(negedge clk);iv=0;orr=0;
        #1;
        if(ir!==0) $fatal(1,"Replacement must keep FIFO full");
        orr=1;repeat(16) @(negedge clk);orr=0;
        if(next_out!=133 || ov!==0) $fatal(1,"Full replacement lost or reordered data");
        $display("PASS tb_fifo: full/empty, overflow, full replacement, simultaneous push/pop and pointer wrapping");
        $finish;
    end
endmodule
