`timescale 1ns/1ps
module tb_quality_metrics;
    reg clk=0,rst_n=0,valid=0;always #5 clk=~clk;
    reg[223:0]data=0;
    wire checked,good,deep_ccw,deep_cw,deep_degenerate;
    range_consistency #(.Z0(1000),.Z1(1000),.Z2(1000),.LIMIT_MM(200)) quality(
        .clk(clk),.rst_n(rst_n),.in_valid(valid),.record_in(data),.out_valid(checked),.good(good));
    triangle_inset inset(.record_in(data),.deep_inside(deep_ccw));
    triangle_inset #(.X1(1500),.Y1(2600),.X2(3000),.Y2(0)) clockwise(.record_in(data),.deep_inside(deep_cw));
    triangle_inset #(.X2(1500),.Y2(0)) degenerate(.record_in(data),.deep_inside(deep_degenerate));
    integer fd,n,x,y,z,d0,d1,d2,status,mask,expected_quality,expected_deep,count=0;
    initial begin
        #20;rst_n=1;
        fd=$fopen("sim/quality_vectors.txt","r");if(!fd)$fatal(1,"Quality vectors missing");
        while(!$feof(fd))begin
            n=$fscanf(fd,"%d %d %d %d %d %d %d %d %d %d\n",x,y,z,d0,d1,d2,status,mask,expected_quality,expected_deep);
            if(n==10)begin
                @(negedge clk);data={32'(z),32'(y),32'(x),32'(d2),32'(d1),32'(d0),8'd2,8'd1,8'(mask),8'(status)};valid=1;
                #1;if(deep_ccw!==expected_deep || deep_cw!==expected_deep || deep_degenerate)$fatal(1,"Inset vector %0d",count);
                @(negedge clk);valid=0;
                wait(checked);#1;if(good!==expected_quality)$fatal(1,"Quality vector %0d got %0d want %0d",count,good,expected_quality);
                @(negedge clk);count=count+1;
            end
        end
        $fclose(fd);$display("PASS tb_quality_metrics: %0d independent squared residual and signed CW/CCW/inset references",count);$finish;
    end
endmodule
