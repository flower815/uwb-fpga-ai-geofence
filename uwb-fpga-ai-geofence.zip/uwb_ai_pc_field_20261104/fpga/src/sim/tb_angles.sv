`timescale 1ns/1ps
module tb_angles;
    reg clk=0,rst_n=0,start=0,bearing_start=0;
    always #10 clk=~clk;
    reg signed [31:0] x=0,y=0;
    wire busy,valid,defined;
    wire signed [31:0] angle;
    cordic_atan2 dut(.clk(clk),.rst_n(rst_n),.start(start),.x_in(x),.y_in(y),
        .busy(busy),.valid(valid),.direction_valid(defined),.angle_cdeg(angle));
    reg [223:0] record=0;
    wire bearing_busy,bearing_valid;
    wire [287:0] record_out;
    anchor_bearings #(.X0(-500),.Y0(1000),.X1(6000),.Y1(-2000),.X2(-7000),.Y2(-4000)) bearings(
        .clk(clk),.rst_n(rst_n),.start(bearing_start),.record_in(record),
        .busy(bearing_busy),.valid(bearing_valid),.record_out(record_out));
    integer f,n,ix,iy,expected,expected_defined,error,atan_count=0,bearing_count=0;
    integer mask,a0,a1,a2,got;
    function automatic integer circular_error(input integer a,b);
        integer d;
        begin d=a-b; if(d<0)d=-d; if(d>18000)d=36000-d; circular_error=d; end
    endfunction
    task automatic run_bearing(input [7:0] status,input [7:0] distance_mask,input integer px,py);
        begin
            @(negedge clk);
            record={32'd1000,py[31:0],px[31:0],32'd5000,32'd5000,32'd5000,8'd2,8'h55,distance_mask,status};
            bearing_start=1;
            @(negedge clk); bearing_start=0;
            wait(bearing_valid); #1;
            if(record_out[223:0]!==record || record_out[239:232]!==0)
                $fatal(1,"Bearing stage changed base measurement/reserved byte");
        end
    endtask
    initial begin
        #100; rst_n=1;
        f=$fopen("sim/atan_vectors.txt","r");
        if(!f)$fatal(1,"Missing atan reference vectors");
        while(!$feof(f)) begin
            n=$fscanf(f,"%d %d %d %d\n",ix,iy,expected,expected_defined);
            if(n==4) begin
                @(negedge clk); x=ix; y=iy; start=1;
                @(negedge clk); start=0;
                wait(valid); #1;
                error=circular_error(angle,expected);
                if(defined!==expected_defined[0] || (defined && error>1))
                    $fatal(1,"atan2(%0d,%0d) got=%0d expected=%0d error=%0d",iy,ix,angle,expected,error);
                atan_count=atan_count+1;
            end
        end
        $fclose(f);
        f=$fopen("sim/bearing_vectors.txt","r");
        if(!f)$fatal(1,"Missing bearing reference vectors");
        while(!$feof(f)) begin
            n=$fscanf(f,"%d %d %d %d %d %d\n",ix,iy,mask,a0,a1,a2);
            if(n==6) begin
                run_bearing(0,7,ix,iy);
                if(record_out[231:224]!==mask[7:0])$fatal(1,"Bad bearing validity mask");
                for(integer i=0;i<3;i=i+1) begin
                    expected=i==0 ? a0 : i==1 ? a1 : a2;
                    got=record_out[240+i*16 +: 16];
                    if(mask & (1<<i)) begin
                        if(got>=36000 || circular_error(got,expected)>1)$fatal(1,"Bad bearing A%0d: %0d expected %0d",i,got,expected);
                    end else if(got!=65535)$fatal(1,"Zero direction must be invalid, not 0 degrees");
                end
                bearing_count=bearing_count+1;
            end
        end
        $fclose(f);
        run_bearing(1,7,3000,4000);
        if(record_out[287:224]!==64'hffffffffffff0000)$fatal(1,"Invalid position produced angles");
        run_bearing(0,1,3000,4000);
        if(record_out[287:224]!==64'hffffffffffff0000)$fatal(1,"Partial ranges produced angles");
        run_bearing(8'h80,7,3000,4000);
        if(record_out[231:224]!==7)$fatal(1,"Overload flag must not invalidate current angles");
        @(negedge clk); x=12345; y=-6789; start=1;
        @(negedge clk); start=0;
        repeat(3) @(negedge clk);
        rst_n=0; #1;
        if(busy || valid)$fatal(1,"Reset did not abort CORDIC");
        @(negedge clk); rst_n=1;
        $display("PASS tb_angles: %0d atan2 references, %0d three-anchor references, quadrants/axes/limits/zero/invalid/reset",atan_count,bearing_count);
        $finish;
    end
    initial begin #10000000; $fatal(1,"Angle test timeout"); end
endmodule
