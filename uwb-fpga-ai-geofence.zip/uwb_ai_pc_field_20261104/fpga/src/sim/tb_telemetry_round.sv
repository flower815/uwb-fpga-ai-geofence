`timescale 1ns/1ps
module tb_telemetry_round;
    reg [287:0]data;
    wire[287:0]rounded,bypass,bounded;
    telemetry_coordinate_round dut(data,rounded);
    telemetry_coordinate_round #(.STEP_MM(1)) legacy(data,bypass);
    telemetry_coordinate_round #(.COORD_BITS(16)) actual_core_range(data,bounded);
    integer f,n,value,expected,count=0;
    initial begin
        f=$fopen("sim/telemetry_round_vectors.txt","r");
        if(!f)$fatal(1,"Missing independent rounding vectors");
        while(!$feof(f))begin
            n=$fscanf(f,"%d %d\n",value,expected);
            if(n==2)begin
                data={9{$random}};
                data[223:128]={3{value[31:0]}};#1;
                if(rounded[223:128]!=={3{expected[31:0]}} || bypass!==data ||
                   rounded[127:0]!==data[127:0] || rounded[287:224]!==data[287:224])
                    $fatal(1,"TX rounding %0d expected %0d got %0d",value,expected,$signed(rounded[159:128]));
                if(value>=-30000 && value<=30000 && bounded!==rounded)
                    $fatal(1,"Bounded transmit arithmetic changed mm rounding");
                count=count+1;
            end
        end
        $fclose(f);
        $display("PASS tb_telemetry_round: %0d signed independent vectors, half-away ties, int32 edges, XYZ-only and bypass",count);$finish;
    end
endmodule
