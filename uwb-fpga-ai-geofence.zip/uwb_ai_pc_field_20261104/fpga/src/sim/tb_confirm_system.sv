`timescale 1ns/1ps
module tb_confirm_system;
    reg clk=0,rst_n=0,rx=1,pc_rx=1;
    always #250 clk=~clk;
    wire tx,beep;
    uwb_ai_top #(.CLK_HZ(2000000),.UWB_BAUD(100000),.PC_BAUD(100000),.TELEMETRY_STEP_MM(1),.CLEAR_HITS(1),.CLEAR_MARGIN_MM(0),.QUALITY_ENABLE(0),.FAULT_ENABLE(0),.WATCHDOG_CYCLES(400000)) dut(
        .sys_clk(clk),.sys_rst_n(rst_n),.uwb_rx(rx),.pc_rx(pc_rx),.pc_tx(tx),.beep(beep));
    function automatic [15:0] crc_next(input[15:0]prev,input[7:0]v);
        reg[15:0]c;
        begin c=prev^{v,8'h00};for(integer i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crc_next=c;end
    endfunction
    reg[7:0]packet[0:41],b;
    reg[15:0]crc;
    integer index=0,target=42,count=0,acks=0,capture=0,expected[1:10];string path;
    initial begin
        expected[1]=1;expected[2]=1;expected[3]=1;expected[4]=8;expected[5]=1;
        expected[6]=8;expected[7]=16;expected[8]=3;expected[9]=4;expected[10]=1;
        if($value$plusargs("CAPTURE=%s",path))capture=$fopen(path,"w");
    end
    initial forever begin
        @(negedge tx);#15000;
        for(integer i=0;i<8;i=i+1)begin b[i]=tx;#10000;end
        if(tx!==1)$fatal(1,"Confirm UART stop");
        packet[index]=b;index=index+1;
        if(index==3)target=(packet[2]==3)?42:18;
        if(index==target)begin
            if(packet[0]!==8'h55 || packet[1]!==8'haa)$fatal(1,"Confirm UART header");
            crc=16'hffff;for(integer i=0;i<target-2;i=i+1)crc=crc_next(crc,packet[i]);
            if({packet[target-1],packet[target-2]}!==crc)$fatal(1,"Confirm UART CRC");
            if(packet[2]==3)begin
                count=count+1;
                if(packet[5]!==count || packet[33]!==expected[count])$fatal(1,"Confirmation frame %0d flag %0d",count,packet[33]);
                if(beep!==((count==8 || count==9)?1'b1:1'b0))$fatal(1,"Premature / missing buzzer at %0d",count);
                if(count==4 && ({packet[11],packet[10],packet[9],packet[8]}!==5000 ||
                    {packet[23],packet[22],packet[21],packet[20]}!==1500))$fatal(1,"Raw spike / median alignment");
            end else begin
                acks=acks+1;
                if(packet[6][3])$fatal(1,"AI command caused early beep");
            end
            if(capture)begin for(integer i=0;i<target;i=i+1)$fwrite(capture,"%02x",packet[i]);$fwrite(capture,"\n");end
            index=0;
        end
    end
    task automatic command;
        reg[127:0]payload;reg[15:0]c;reg[7:0]v;
        begin
            payload={32'b0,32'h12345678,8'h00,8'h01,16'h0001,8'h01,8'h10,16'haa55};c=16'hffff;
            for(integer i=0;i<18;i=i+1)begin
                if(i<16)begin v=payload[i*8+:8];c=crc_next(c,v);end
                else v=(i==16)?c[7:0]:c[15:8];
                pc_rx=0;#10000;for(integer j=0;j<8;j=j+1)begin pc_rx=v[j];#10000;end pc_rx=1;#10000;
            end
            #2500000;
            if(!dut.host_warning || !dut.armed || beep)$fatal(1,"AI early-beep gating failed");
        end
    endtask
    task automatic line(input integer s,m,a,c,d);
        string text;reg[7:0]mb,sb,v;reg[15:0]sw;
        begin
            mb=m;sb=s;sw=s;
            text=$sformatf("mc %02x %08x %08x %08x 00000000 %04x %02x 00000000 a2:0\015\012",mb,a,c,d,sw,sb);
            for(integer i=0;i<text.len();i=i+1)begin
                v=text[i];rx=0;#10000;for(integer j=0;j<8;j=j+1)begin rx=v[j];#10000;end rx=1;#10000;
            end
            #5000000;
        end
    endtask
    initial begin
        #2000;rst_n=1;#10000;command();
        line(1,7,2000,2000,2000);line(2,7,2000,2000,2000);line(3,7,2000,2000,2000);
        line(4,7,5000,2000,2000);line(5,7,2000,2000,2000);
        line(6,7,5000,2000,2000);line(7,7,5000,2000,2000);line(8,7,5000,2000,2000);
        line(9,1,2000,0,0);line(10,7,2000,2000,2000);
        if(count!=10 || acks!=1)$fatal(1,"Missing confirmation UART records");
        #250000000;
        if(!dut.watchdog_fault || beep)$fatal(1,"Watchdog diagnostic must remain, without buzzer");
        if(capture)$fclose(capture);
        $display("PASS tb_confirm_system: default AI3, isolated spike pending/reset, third-frame UART+buzzer, raw/median counted once, AI early beep disabled, watchdog silent");$finish;
    end
    initial begin #1000000000;$fatal(1,"Confirm timeout");end
endmodule
