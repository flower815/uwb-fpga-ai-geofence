`timescale 1ns/1ps
module tb_position_watchdog;
    reg clk=0,rst_n=0,valid=0,trust=0;always #5 clk=~clk;
    reg[7:0]tag=2,seq=0;wire fault,pred;wire[7:0]last_seq;
    position_watchdog #(.TIMEOUT_CYCLES(14),.STARTUP_CYCLES(30)) dut(
        .clk(clk),.rst_n(rst_n),.sample_valid(valid),.trustworthy(trust),.tag(tag),.seq(seq),
        .fault(fault),.record_fault(pred),.last_seq(last_seq));
    task automatic sample(input integer t,s,q,expected);
        begin
            @(negedge clk);valid=1;tag=t;seq=s;trust=q;#1;
            if(pred!==expected)$fatal(1,"Watchdog prediction tag %0d seq %0d got %0d expected %0d age %0d recover %0d",t,s,pred,expected,dut.age,dut.recover);
            @(posedge clk);#1;if(fault!==expected)$fatal(1,"Watchdog state seq %0d",s);
            @(negedge clk);valid=0;
        end
    endtask
    initial begin
        #20;rst_n=1;repeat(24)@(negedge clk);if(fault)$fatal(1,"Startup grace too short");
        repeat(8)@(negedge clk);if(!fault)$fatal(1,"No-data startup not detected");
        sample(2,1,1,1);sample(2,1,1,1);sample(2,2,1,1);sample(2,3,1,0);
        for(integer i=0;i<8;i=i+1)sample(2,3,1,(i<6)?0:1);
        if(!fault)$fatal(1,"Duplicates fed watchdog");
        sample(2,5,1,1);sample(2,8,1,1);sample(2,9,1,0);sample(2,10,1,0);
        repeat(8)@(negedge clk);sample(4,1,1,0);repeat(8)@(negedge clk);
        if(!fault)$fatal(1,"Other tag fed watchdog");
        sample(2,11,1,1);sample(2,12,0,1);sample(2,13,1,1);sample(2,14,1,1);sample(2,15,1,0);
        // Backwards/repeated packets never move the accepted baseline or feed.
        for(integer i=0;i<9;i=i+1)sample(2,14,1,(i<6)?0:1);
        if(!fault)$fatal(1,"Backwards data fed watchdog");
        sample(2,17,1,1);sample(2,19,1,0);sample(2,21,1,0);
        repeat(16)@(negedge clk);
        // A changed counter after a real outage can re-establish a baseline.
        sample(2,200,1,1);sample(2,254,1,1);sample(2,0,1,0);
        $display("PASS tb_position_watchdog: startup, forward gaps, duplicates/backwards ignored, timeout counter resync, wrap, invalid and wrong tag");$finish;
    end
endmodule
