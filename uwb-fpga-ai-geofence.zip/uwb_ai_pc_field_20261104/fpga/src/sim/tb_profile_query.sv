`timescale 1ns/1ps
module tb_profile_query;
    localparam integer CLK_HZ=2_000_000,BAUD=100000,BIT_NS=10000;
    reg clk=0,rst_n=0,rx=1;
    always #250 clk=~clk;
    wire tx,host_warning,armed,watchdog_fault;
    wire [7:0] profile_index;
    wire [31:0] profile_value;
    wire profile_valid;
    // Distinct negative coordinates verify signed configuration bit patterns.
    uwb_profile #(.X0(-250),.X2(-1500),.TAG_Z(-100),.QUALITY_ENABLE(0)) profile(
        .index(profile_index),.value(profile_value),.valid(profile_valid));
    ai_usb_link #(.CLK_HZ(CLK_HZ),.BAUD(BAUD),.WATCHDOG_CYCLES(CLK_HZ/100)) dut(
        .clk(clk),.rst_n(rst_n),.rx(rx),.stream_online(1'b1),.command_data(8'b0),
        .command_valid(1'b0),.command_error(1'b0),.stream_data(),.stream_valid(),.stream_ready(1'b0),
        .record_in(288'b0),.record_valid(1'b0),.record_ready(),.local_alarm(1'b0),.beep_state(1'b0),
        .host_warning(host_warning),.armed(armed),.watchdog_fault(watchdog_fault),.tx(tx),
        .profile_index(profile_index),.profile_value(profile_value),.profile_valid(profile_valid));
    function automatic [15:0] crc_next(input [15:0] previous,input [7:0] value);
        reg [15:0] c;
        begin c=previous^{value,8'h00};for(integer i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crc_next=c;end
    endfunction
    reg [7:0] packet[0:17],b;
    reg [15:0] crc;
    reg [31:0] registers[0:22],expected_value[0:63];
    integer expected_opcode[0:63],expected_result[0:63];
    integer count=0,ack_count=0,seq,capture=0;
    string path;
    initial begin
        registers[0]=32'h55574235;registers[1]=32'h00050006;
        registers[2]=32'hffffff06;registers[3]=0;registers[4]=1000;
        registers[5]=3000;registers[6]=0;registers[7]=1000;
        registers[8]=32'hfffffa24;registers[9]=2600;registers[10]=1000;registers[11]=32'hffffff9c;
        registers[12]=1;registers[13]=3;registers[14]=1;registers[15]=0;
        registers[16]=1000;registers[17]=2;registers[18]=200;registers[19]=0;
        registers[20]=50000000;registers[21]=115200;registers[22]=2;
        for(integer i=0;i<64;i=i+1)begin expected_opcode[i]=-1;expected_result[i]=-1;expected_value[i]=0;end
        if($value$plusargs("CAPTURE=%s",path))capture=$fopen(path,"w");
    end
    initial forever begin
        @(negedge tx);#(BIT_NS+BIT_NS/2);
        for(integer i=0;i<8;i=i+1)begin b[i]=tx;#(BIT_NS);end
        if(tx!==1)$fatal(1,"Profile UART stop bit");
        packet[count]=b;count=count+1;
        if(count==18)begin
            if({packet[2],packet[1],packet[0]}!==24'h11aa55)$fatal(1,"Profile ACK header");
            crc=16'hffff;for(integer i=0;i<16;i=i+1)crc=crc_next(crc,packet[i]);
            if({packet[17],packet[16]}!==crc)$fatal(1,"Profile ACK CRC");
            seq={packet[5],packet[4]};
            if(seq>36 || packet[3]!==expected_opcode[seq] || packet[7]!==expected_result[seq])
                $fatal(1,"Profile ACK routing/result seq=%0d got opcode=%0d result=%0d",seq,packet[3],packet[7]);
            if({packet[11],packet[10],packet[9],packet[8]}!==(32'habc00000+seq))$fatal(1,"Profile token mismatch");
            if(packet[3]==3 && {packet[15],packet[14],packet[13],packet[12]}!==expected_value[seq])
                $fatal(1,"Profile value mismatch seq=%0d got %h",seq,{packet[15],packet[14],packet[13],packet[12]});
            if(seq<=26 && packet[6]!==0)$fatal(1,"Read changed unarmed state");
            if(seq>=28 && seq<=34 && (!packet[6][4] || packet[6][0]))$fatal(1,"Read altered armed/warning state");
            if(seq==34 && !packet[6][1])$fatal(1,"Read cleared watchdog fault");
            if(seq>=35 && packet[6]!==0)$fatal(1,"Read armed after release");
            if(capture)begin for(integer i=0;i<18;i=i+1)$fwrite(capture,"%02x",packet[i]);$fwrite(capture,"\n");end
            ack_count=ack_count+1;count=0;
        end
    end
    task automatic send_byte(input [7:0] v);
        begin rx=0;#BIT_NS;for(integer i=0;i<8;i=i+1)begin rx=v[i];#BIT_NS;end rx=1;#BIT_NS;end
    endtask
    task automatic request(input integer op,n,flags,reserved,bad_crc);
        reg [127:0] body;reg [15:0] c;
        begin
            body={32'b0,(32'habc00000+n),8'(reserved),8'(flags),16'(n),8'(op),8'h10,16'haa55};
            c=16'hffff;for(integer i=0;i<16;i=i+1)begin send_byte(body[i*8+:8]);c=crc_next(c,body[i*8+:8]);end
            send_byte(c[7:0]^(bad_crc?8'h01:8'h00));send_byte(c[15:8]);
        end
    endtask
    task automatic checked(input integer op,n,flags,reserved,result,input [31:0]value);
        integer previous;
        begin
            expected_opcode[n]=op;expected_result[n]=result;expected_value[n]=value;
            previous=ack_count;request(op,n,flags,reserved,0);
            wait(ack_count==previous+1);#10000;
        end
    endtask
    integer before_bad;
    initial begin
        #5000;rst_n=1;#5000;
        for(integer i=0;i<23;i=i+1)checked(3,i+1,i,0,0,registers[i]);
        if(armed || host_warning || watchdog_fault)$fatal(1,"Profile query armed controller");
        checked(3,24,255,0,3,0);checked(3,25,0,1,2,0);checked(99,26,0,0,1,0);
        before_bad=ack_count;request(3,27,0,0,1);#2500000;
        if(ack_count!=before_bad || armed)$fatal(1,"Bad query CRC executed");
        checked(1,28,0,0,0,0);
        if(!armed || host_warning)$fatal(1,"Baseline SET failed");
        for(integer i=0;i<5;i=i+1)checked(3,29+i,i,0,0,registers[i]);
        if(!watchdog_fault || !host_warning)$fatal(1,"Profile queries kept lease alive");
        checked(3,34,1,0,0,registers[1]);
        if(!watchdog_fault)$fatal(1,"Profile query cleared fault");
        checked(2,35,0,0,0,0);checked(3,36,0,0,0,registers[0]);
        if(ack_count!=35)$fatal(1,"Missing profile ACKs");
        if(capture)$fclose(capture);
        $display("PASS tb_profile_query: 23 registers, signed coordinates, token/CRC, unsupported index, malformed request, read-only state and watchdog lease");$finish;
    end
    initial begin #1000000000;$fatal(1,"Profile query timeout");end
endmodule
