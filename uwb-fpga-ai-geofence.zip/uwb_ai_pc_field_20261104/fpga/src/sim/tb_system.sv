`timescale 1ns/1ps
module tb_system;
    parameter integer CLK_HZ=2_000_000, BAUD=100000, ENABLE_ANGLES=0, ENABLE_FENCE=0;
    localparam integer BIT_NS=1_000_000_000/BAUD;
    localparam integer BODY_BYTES=(ENABLE_ANGLES || ENABLE_FENCE) ? 40 : 32, FRAME_BYTES=BODY_BYTES+2;
    reg clk=0, rst_n=0, rx=1;
    wire tx;
    always #(500_000_000/CLK_HZ) clk=~clk;
    uwb_top #(.CLK_HZ(CLK_HZ),.UWB_BAUD(BAUD),.PC_BAUD(BAUD),.ENABLE_ANGLES(ENABLE_ANGLES),.ENABLE_FENCE(ENABLE_FENCE)) dut(
        .sys_clk(clk),.sys_rst_n(rst_n),.uwb_rx(rx),.pc_tx(tx));
    // Maximum-size buffer also keeps the disabled V2 checks in bounds for V1.
    reg [7:0] packet[0:41];
    integer packet_bytes=0, received=0, expected=0;
    reg [7:0] exp_status[0:31],exp_mask[0:31],exp_seq[0:31],exp_tag[0:31];
    reg [31:0] exp_d0[0:31],exp_d1[0:31],exp_d2[0:31];
    integer exp_x[0:31],exp_y[0:31];
    reg [7:0] b;
    integer k;
    integer reference_angle,observed_angle,angle_error;
    integer reference_fence;
    reg [8:0] reference_alarms=0;
    real radians;
    reg [15:0] check_crc;
    integer capture=0;
    string capture_path;
    initial begin
        // Optional: export actual UART wire bytes for the NEW Python decoder.
        // No file is needed by Vivado's ordinary behavioral simulation.
        if($value$plusargs("CAPTURE=%s",capture_path)) begin
            capture=$fopen(capture_path,"w");
            if(!capture) $fatal(1,"Cannot open UART capture file");
        end
    end
    function automatic [31:0] u32(input integer offset);
        u32={packet[offset+3],packet[offset+2],packet[offset+1],packet[offset]};
    endfunction
    function automatic [15:0] crc_next(input [15:0] prev,input [7:0] value);
        integer j; reg [15:0] c;
        begin
            c=prev^{value,8'b0};
            for(j=0;j<8;j=j+1) c=c[15] ? (c<<1)^16'h1021 : c<<1;
            crc_next=c;
        end
    endfunction
    // Independent UART monitor uses elapsed wire time, not the UART RTL receiver.
    initial forever begin
        @(negedge tx);
        #(BIT_NS+BIT_NS/2);
        for(k=0;k<8;k=k+1) begin b[k]=tx; #(BIT_NS); end
        if(tx!==1) $fatal(1,"PC UART stop bit invalid");
        packet[packet_bytes]=b;
        packet_bytes=packet_bytes+1;
        if(packet_bytes==FRAME_BYTES) begin
            if(received>=expected) $fatal(1,"Unexpected output packet");
            if(packet[0]!==8'h55 || packet[1]!==8'haa || packet[2]!==(ENABLE_FENCE ? 8'd3 : ENABLE_ANGLES ? 8'd2 : 8'd1) || packet[7]!==0)
                $fatal(1,"Bad packet header");
            check_crc=16'hffff;
            for(integer j=0;j<BODY_BYTES;j=j+1) check_crc=crc_next(check_crc,packet[j]);
            if({packet[BODY_BYTES+1],packet[BODY_BYTES]}!==check_crc) $fatal(1,"CRC mismatch");
            if(packet[3]!==exp_status[received] || packet[4]!==exp_mask[received] ||
               packet[5]!==exp_seq[received] || packet[6]!==exp_tag[received])
                $fatal(1,"Metadata mismatch packet %0d status=%h mask=%h seq=%h tag=%h",
                    received,packet[3],packet[4],packet[5],packet[6]);
            if(u32(8)!==exp_d0[received] || u32(12)!==exp_d1[received] || u32(16)!==exp_d2[received])
                $fatal(1,"Distances mismatch");
            if($signed(u32(20))!==exp_x[received] || $signed(u32(24))!==exp_y[received] || u32(28)!==0)
                $fatal(1,"Coordinates mismatch packet %0d x=%0d y=%0d",received,$signed(u32(20)),$signed(u32(24)));
            if(ENABLE_ANGLES || ENABLE_FENCE) begin
                reference_fence=0;
                if(ENABLE_FENCE)begin
                    if((exp_status[received]&8'h7f)==0)begin
                        reference_fence=exp_x[received]>=0 && exp_y[received]>=0 && exp_x[received]*8000+exp_y[received]*6000<=48000000 ? 1 : 3;
                        reference_alarms[exp_tag[received]]=(reference_fence==3);
                    end else reference_fence=reference_alarms[exp_tag[received]] ? 4 : 0;
                end
                if(packet[33] !== reference_fence[7:0] ||
                    packet[32]!==((ENABLE_ANGLES && (exp_status[received]&8'h7f)==0) ? 8'd7 : 8'd0))
                    $fatal(1,"Bad angle validity/reserved byte");
                for(integer a=0;a<3;a=a+1) begin
                    observed_angle={packet[35+a*2],packet[34+a*2]};
                    if(ENABLE_ANGLES && (exp_status[received]&8'h7f)==0) begin
                        radians=$atan2($itor(exp_y[received]-(a==2 ? 8000 : 0)),
                                       $itor(exp_x[received]-(a==1 ? 6000 : 0)));
                        reference_angle=$rtoi(radians*18000.0/3.141592653589793+36000.5)%36000;
                        angle_error=observed_angle-reference_angle;
                        if(angle_error<0)angle_error=-angle_error;
                        if(angle_error>18000)angle_error=36000-angle_error;
                        if(observed_angle>=36000 || angle_error>1)$fatal(1,"USB angle mismatch A%0d",a);
                    end else if(observed_angle!=65535)$fatal(1,"Invalid position angle must be FFFF");
                end
            end
            if(capture) begin
                for(integer j=0;j<FRAME_BYTES;j=j+1) $fwrite(capture,"%02x",packet[j]);
                $fwrite(capture,"\n");
            end
            received=received+1;
            packet_bytes=0;
        end
    end
    task automatic send_byte(input [7:0] value);
        begin
            rx=0; #(BIT_NS);
            for(integer j=0;j<8;j=j+1) begin rx=value[j]; #(BIT_NS); end
            rx=1; #(BIT_NS);
        end
    endtask
    task automatic send_line(input string line);
        begin for(integer j=0;j<line.len();j=j+1) send_byte(line[j]); end
    endtask
    task automatic expect_record(input [7:0] status,mask,seq,tag,
        input [31:0] d0,d1,d2,input integer x,y);
        begin
            exp_status[expected]=status; exp_mask[expected]=mask; exp_seq[expected]=seq; exp_tag[expected]=tag;
            exp_d0[expected]=d0; exp_d1[expected]=d1; exp_d2[expected]=d2;
            exp_x[expected]=x; exp_y[expected]=y; expected=expected+1;
        end
    endtask
    initial begin
        #10000; rst_n=1; #10000;
        expect_record(1,1,1,2,328,0,0,0,0);
        send_line("mc 01 00000148 00000000 00000000 00000000 0001 01 0000a70e a2:0\015\012");
        expect_record(0,7,2,2,5000,5000,5000,3000,4000);
        send_line("mc 07 00001388 00001388 00001388 00000000 0002 02 00000000 a2:0\015\012");
        // A negative X result, with distance rounding in the UWB report.
        expect_record(0,7,3,2,5000,9849,5000,-3000,4000);
        send_line("mc 07 00001388 00002679 00001388 00000000 0003 03 00000000 a2:0\012");
        // ma/mr messages and malformed hexadecimal must not become locations.
        send_line("ma 07 00001388 00001388 00001388 00000000 0004 04 00000000 a2:0\015\012");
        send_line("mr 07 00001388 00001388 00001388 00000000 0004 04 00000000 a2:0\015\012");
        send_line("mc 07 0000Z388 00001388 00001388 00000000 0004 04 00000000 a2:0\015\012");
        send_line("mc 07 00001388\015\012");
        // Timeout and recovery from a partial message without a newline.
        send_line("mc 07 0000"); #25000000;
        expect_record(0,15,5,8,5000,5000,5000,3000,4000);
        send_line("mc 0F 00001388 00001388 00001388 FFFFFFFF 0005 05 ABCDEFAB t8:0\015\012");
        expect_record(2,7,6,2,0,5000,5000,0,0);
        send_line("mc 07 00000000 00001388 00001388 00000000 0006 06 00000000 a2:0\015\012");
        expect_record(2,7,7,2,32'hffffffff,5000,5000,0,0);
        send_line("mc 07 FFFFFFFF 00001388 00001388 00000000 0007 07 00000000 a2:0\015\012");
        expect_record(8,7,8,2,60000,1,1,0,0);
        send_line("mc 07 0000ea60 00000001 00000001 00000000 0008 08 00000000 a2:0\015\012");
        // A line containing a UART framing fault is discarded.
        send_line("mc 07 "); rx=0; #(BIT_NS*12); rx=1; #(BIT_NS*2);
        send_line("00001388 00001388 00001388 00000000 0009 09 00000000 a2:0\015\012");
        expect_record(0,7,10,2,5000,5000,5000,3000,4000);
        send_line("mc 07 00001388 00001388 00001388 00000000 000a 0a 00000000 a2:0\015\012");
        wait(received==expected);
        #1000000;
        if(capture) $fclose(capture);
        $display("PASS tb_system: %0d packets, angles=%0d, UART/CRC, actual mc01, signed XY, invalid/partial lines, timeout and framing recovery",received,ENABLE_ANGLES);
        $finish;
    end
    initial begin #200000000; $fatal(1,"System simulation timeout"); end
endmodule
