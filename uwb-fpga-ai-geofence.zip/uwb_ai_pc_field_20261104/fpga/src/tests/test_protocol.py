import sys
from pathlib import Path
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"host"))
from protocol import Position, Decoder, encode, crc16, SIZE


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.good = Position(0, 7, 255, 2, (5000, 9849, 5000), (-3000, 4000, -900))

    def test_ccitt_reference(self):
        self.assertEqual(crc16(b"123456789"), 0x29B1)

    def test_signed_coordinates(self):
        packet = encode(self.good)
        self.assertEqual(len(packet), SIZE)
        self.assertEqual(Decoder().feed(packet), [self.good])

    def test_arbitrary_fragmentation(self):
        packet = encode(self.good)
        for split in range(len(packet)+1):
            decoder = Decoder()
            self.assertEqual(decoder.feed(packet[:split])+decoder.feed(packet[split:]), [self.good])
        decoder = Decoder()
        output = []
        for b in packet*3:
            output += decoder.feed(bytes([b]))
        self.assertEqual(output, [self.good]*3)

    def test_corruption_and_resynchronization(self):
        damaged = bytearray(encode(self.good))
        damaged[15] ^= 4
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"noise\x55"+damaged+encode(self.good)), [self.good])
        self.assertGreater(decoder.crc_errors, 0)

    def test_actual_partial_range(self):
        p = Position(1, 1, 1, 2, (328, 0, 0), (0, 0, 0))
        self.assertFalse(p.located)
        self.assertIn("测距不完整", p.message)
        self.assertEqual(Decoder().feed(encode(p)), [p])

    def test_overrun_flag_keeps_current_location(self):
        p = Position(128, 7, 2, 2, (5000, 5000, 5000), (3000, 4000, 0))
        self.assertTrue(p.located)
        self.assertIn("丢帧", p.message)

    def test_bad_status_invalidates_coordinates(self):
        for status in [1,2,4,8,129]:
            self.assertFalse(Position(status,7,0,2,(0,0,0),(0,0,0)).located)


if __name__ == "__main__":
    unittest.main()
