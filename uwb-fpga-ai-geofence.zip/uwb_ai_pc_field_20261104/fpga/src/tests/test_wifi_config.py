"""Validate generated AT command bytes without using real network credentials."""
import tempfile
import unittest
from pathlib import Path
import tkinter

ROOT = Path(__file__).resolve().parents[1]


class WifiConfigTests(unittest.TestCase):
    def generate(self, **changes):
        fields = dict(WIFI_SSID="lab", WIFI_PASSWORD="secret123", WIFI_PC_IP="192.168.10.26",
                      WIFI_PC_PORT="9000", WIFI_AT_PROFILE="legacy_cur", WIFI_TCP_KEEPALIVE="5")
        fields.update(changes)
        folder = ROOT / "build/test_tmp"
        folder.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=folder) as temp:
            path = Path(temp) / "wifi.tcl"
            path.write_text("\n".join(
                f"set {name} [encoding convertfrom utf-8 [binary format H* {{{str(value).encode('utf-8').hex()}}}]]"
                for name, value in fields.items()), encoding="ascii")
            interp = tkinter.Tcl()
            interp.call("source", str(ROOT / "scripts/wifi_config.tcl"))
            interp.setvar("WIFI_CONFIG_FILE", path.as_posix())
            result = interp.call("wifi_generics", ROOT.as_posix())
            return dict(item.split("=", 1) for item in interp.splitlist(result))

    @staticmethod
    def command(result, name):
        return bytes.fromhex(result[name].split("'h", 1)[1]).decode("utf-8")

    def test_legacy_profile(self):
        result = self.generate()
        self.assertEqual(result["LEGACY_CUR"], "1")
        self.assertEqual(self.command(result, "JOIN_COMMAND"), 'AT+CWJAP_CUR="lab","secret123"\r\n')
        self.assertEqual(self.command(result, "TCP_COMMAND"), 'AT+CIPSTART="TCP","192.168.10.26",9000,5\r\n')
        self.assertEqual(int(result["JOIN_LEN"]), 32)

    def test_modern_profile(self):
        result = self.generate(WIFI_AT_PROFILE="modern")
        self.assertEqual(result["LEGACY_CUR"], "0")
        self.assertEqual(self.command(result, "JOIN_COMMAND"), 'AT+CWJAP="lab","secret123"\r\n')

    def test_escape_and_utf8(self):
        result = self.generate(WIFI_SSID='实验室,a"b\\c', WIFI_PASSWORD='a,b"c\\d')
        command = self.command(result, "JOIN_COMMAND")
        self.assertEqual(command, 'AT+CWJAP_CUR="实验室\\,a\\"b\\\\c","a\\,b\\"c\\\\d"\r\n')
        self.assertEqual(len(command.encode("utf-8")), int(result["JOIN_LEN"]))

    def test_open_wifi(self):
        result = self.generate(WIFI_PASSWORD="")
        self.assertIn(',""\r\n', self.command(result, "JOIN_COMMAND"))

    def test_length_and_placeholder_rejection(self):
        for fields in [dict(WIFI_SSID=""), dict(WIFI_SSID="a" * 33), dict(WIFI_SSID="中" * 11),
                       dict(WIFI_PASSWORD="a" * 65), dict(WIFI_SSID="YOUR_2G_WIFI"),
                       dict(WIFI_PASSWORD="YOUR_PASSWORD")]:
            with self.subTest(fields=fields), self.assertRaises(tkinter.TclError):
                self.generate(**fields)

    def test_control_character_rejection(self):
        for value in ["x\r\nAT", "x\0y", "x\t"]:
            with self.subTest(value=value), self.assertRaises(tkinter.TclError):
                self.generate(WIFI_PASSWORD=value)

    def test_address_rejection(self):
        for ip in ["0.0.0.0", "127.0.0.1", "224.0.0.1", "192.168.1.256", "host.local", "1.2.3"]:
            with self.subTest(ip=ip), self.assertRaises(tkinter.TclError):
                self.generate(WIFI_PC_IP=ip)

    def test_port_keepalive_and_profile_rejection(self):
        for fields in [dict(WIFI_PC_PORT="0"), dict(WIFI_PC_PORT="65536"), dict(WIFI_PC_PORT="abc"),
                       dict(WIFI_TCP_KEEPALIVE="-1"), dict(WIFI_TCP_KEEPALIVE="7201"),
                       dict(WIFI_AT_PROFILE="unknown")]:
            with self.subTest(fields=fields), self.assertRaises(tkinter.TclError):
                self.generate(**fields)


if __name__ == "__main__":
    unittest.main()
