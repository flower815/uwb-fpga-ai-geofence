# Manufacturer V2 NAVIGATOR_ZYNQ_IO.xdc mapping, checked 2026-10-23.
# Default P1 UART2_RX input; P1 UART2_TX wired to P5 pin3/CH340 RX.
# scripts/create_project.tcl generates build/vivado/board.xdc from board.tcl.
# For a manually created project this file is the equivalent 50MHz preset.
# Use ONLY ONE of this file and the generated file, never the full vendor IO list.
set_property -dict {PACKAGE_PIN U18 IOSTANDARD LVCMOS33} [get_ports sys_clk]
set_property -dict {PACKAGE_PIN N16 IOSTANDARD LVCMOS33} [get_ports sys_rst_n]
set_property -dict {PACKAGE_PIN K14 IOSTANDARD LVCMOS33} [get_ports uwb_rx]
set_property -dict {PACKAGE_PIN M15 IOSTANDARD LVCMOS33} [get_ports pc_tx]
set_property -dict {PACKAGE_PIN M14 IOSTANDARD LVCMOS33} [get_ports beep]
create_clock -name sys_clk -period 20.000 [get_ports sys_clk]
set_property PULLUP TRUE [get_ports uwb_rx]
set_false_path -from [get_ports uwb_rx] -to [get_cells -hier -filter {NAME =~ */rx_meta_reg}]
set_false_path -from [get_ports sys_rst_n]
set_false_path -to [get_ports pc_tx]
set_false_path -to [get_ports beep]
