`timescale 1ns/1ps
`default_nettype none
// Independent of PC connectivity. Only fresh, trustworthy EXPECTED_TAG samples feed it.
module position_watchdog #(
    parameter integer TIMEOUT_CYCLES=50_000_000,STARTUP_CYCLES=150_000_000,
    parameter integer EXPECTED_TAG=2,RECOVERY_HITS=3
)(
    input wire clk,rst_n,sample_valid,trustworthy,
    input wire [7:0] tag,seq,
    output reg fault,
    output reg record_fault,
    output reg [7:0] last_seq
);
    localparam integer MAX_AGE=(STARTUP_CYCLES>TIMEOUT_CYCLES)?STARTUP_CYCLES:TIMEOUT_CYCLES;
    localparam integer AGE_W=(MAX_AGE<2)?1:$clog2(MAX_AGE+1);
    reg [AGE_W-1:0] age;
    reg seen,ever_trusted;
    reg [1:0] recover;
    wire expected=sample_valid && tag==EXPECTED_TAG;
    wire expired=age>=(ever_trusted?TIMEOUT_CYCLES-1:STARTUP_CYCLES-1);
    wire [7:0] seq_step=seq-last_seq;
    // Serial-number arithmetic: allow forward gaps and wrap, reject replay.
    // After a real timeout a changed sequence may establish a new baseline.
    wire fresh=!seen || (seq_step!=0 && (!seq_step[7] || (fault && expired)));
    wire continuous=seen && fresh && age<TIMEOUT_CYCLES;
    reg [1:0] next_recover;
    always @*begin
        record_fault=fault || expired;
        next_recover=expired?0:recover;
        if(expected)begin
            if(!trustworthy)next_recover=0;
            else if(fresh)begin
                if(!fault)begin record_fault=0;next_recover=0;end
                else begin
                    next_recover=(continuous && recover!=0)?recover+1'b1:1;
                    if(next_recover>=RECOVERY_HITS)begin record_fault=0;next_recover=0;end
                end
            end
        end
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin age<=0;fault<=0;last_seq<=0;seen<=0;ever_trusted<=0;recover<=0;end
        else begin
            if(age<MAX_AGE)age<=age+1'b1;
            if(expired)begin fault<=1;recover<=0;end
            if(expected)begin
                if(fresh)begin last_seq<=seq;seen<=1;end
                recover<=next_recover;fault<=record_fault;
                if(trustworthy && fresh)begin age<=0;ever_trusted<=1;end
            end
        end
    end
endmodule
`default_nettype wire
