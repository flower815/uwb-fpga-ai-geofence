`timescale 1ns/1ps
`default_nettype none
module uwb_top #(
    parameter integer CLK_HZ=50_000_000,
    parameter integer UWB_BAUD=115200, PC_BAUD=115200,
    parameter integer X0=0,Y0=0,Z0=0, X1=6000,Y1=0,Z1=0, X2=0,Y2=8000,Z2=0,
    parameter integer TAG_Z=0, ENABLE_ANGLES=0, ENABLE_FENCE=0, ENABLE_BUZZER=0
)(
    input wire sys_clk,
    input wire sys_rst_n,
    input wire uwb_rx,
    output wire pc_tx,
    output wire beep
);
    // Asynchronous reset assertion; synchronous release and power-on settling.
    (* ASYNC_REG="TRUE" *) reg [3:0] reset_pipe = 4'b0000;
    always @(posedge sys_clk or negedge sys_rst_n)
        if (!sys_rst_n) reset_pipe<=0;
        else reset_pipe<={reset_pipe[2:0],1'b1};
    wire rst_n=reset_pipe[3];
    localparam integer RECORD_WIDTH=(ENABLE_ANGLES || ENABLE_FENCE) ? 288 : 224;
    wire [RECORD_WIDTH-1:0] queue_record;
    wire queue_valid,packet_ready;
    wire fence_alarm;
    uwb_position_core #(.CLK_HZ(CLK_HZ),.UWB_BAUD(UWB_BAUD),
        .X0(X0),.Y0(Y0),.Z0(Z0),.X1(X1),.Y1(Y1),.Z1(Z1),
        .X2(X2),.Y2(Y2),.Z2(Z2),.TAG_Z(TAG_Z),.ENABLE_ANGLES(ENABLE_ANGLES),.ENABLE_FENCE(ENABLE_FENCE)) core(
        .clk(sys_clk),.rst_n(rst_n),.uwb_rx(uwb_rx),.stream_enable(1'b1),
        .record_out(queue_record),.record_valid(queue_valid),.record_ready(packet_ready),.fence_alarm(fence_alarm));
    geofence_buzzer #(.CLK_HZ(CLK_HZ),.ENABLE_BUZZER(ENABLE_BUZZER)) buzzer(
        .clk(sys_clk),.rst_n(rst_n),.alarm(fence_alarm),.beep(beep));
    position_packet_tx #(.CLK_HZ(CLK_HZ),.BAUD(PC_BAUD),.ENABLE_ANGLES(ENABLE_ANGLES),.ENABLE_FENCE(ENABLE_FENCE)) packet(
        .clk(sys_clk),.rst_n(rst_n),.record_in(queue_record),.record_valid(queue_valid),
        .record_ready(packet_ready),.tx(pc_tx));
endmodule
`default_nettype wire
