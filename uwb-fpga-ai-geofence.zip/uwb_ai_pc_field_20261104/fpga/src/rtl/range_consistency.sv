`timescale 1ns/1ps
`default_nettype none
// Check raw ranges against THEIR raw solution, not against filtered coordinates.
// Exact squared interval: (max(d-limit,0))^2 <= geometric_range^2 <= (d+limit)^2.
module range_consistency #(
    parameter integer X0=0,Y0=0,Z0=0,X1=3000,Y1=0,Z1=0,X2=1500,Y2=2600,Z2=0,
    parameter integer LIMIT_MM=200
)(
    input wire clk,rst_n,in_valid,
    input wire [223:0] record_in,
    output reg out_valid,good
);
    wire signed [31:0] px=record_in[159:128],py=record_in[191:160],pz=record_in[223:192];
    wire signed [16:0] dx0=px-X0,dy0=py-Y0,dz0=pz-Z0;
    wire signed [16:0] dx1=px-X1,dy1=py-Y1,dz1=pz-Z1;
    wire signed [16:0] dx2=px-X2,dy2=py-Y2,dz2=pz-Z2;
    wire [31:0] d0=record_in[63:32],d1=record_in[95:64],d2=record_in[127:96];
    wire [16:0] lo0=(d0>LIMIT_MM)?d0-LIMIT_MM:0,hi0=d0+LIMIT_MM;
    wire [16:0] lo1=(d1>LIMIT_MM)?d1-LIMIT_MM:0,hi1=d1+LIMIT_MM;
    wire [16:0] lo2=(d2>LIMIT_MM)?d2-LIMIT_MM:0,hi2=d2+LIMIT_MM;
    function automatic [33:0] square_delta(input signed [16:0] v);
        begin square_delta=v*v;end
    endfunction
    reg [35:0] norm0,norm1,norm2;
    reg [33:0] lower0,upper0,lower1,upper1,lower2,upper2;
    reg pending,position_ok;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            pending<=0;out_valid<=0;good<=0;position_ok<=0;
            norm0<=0;norm1<=0;norm2<=0;
            lower0<=0;upper0<=0;lower1<=0;upper1<=0;lower2<=0;upper2<=0;
        end else begin
            pending<=in_valid;out_valid<=pending;
            if(in_valid)begin
                norm0<={2'b0,square_delta(dx0)}+{2'b0,square_delta(dy0)}+{2'b0,square_delta(dz0)};
                norm1<={2'b0,square_delta(dx1)}+{2'b0,square_delta(dy1)}+{2'b0,square_delta(dz1)};
                norm2<={2'b0,square_delta(dx2)}+{2'b0,square_delta(dy2)}+{2'b0,square_delta(dz2)};
                lower0<=lo0*lo0;upper0<=hi0*hi0;
                lower1<=lo1*lo1;upper1<=hi1*hi1;
                lower2<=lo2*lo2;upper2<=hi2*hi2;
                position_ok<=record_in[6:0]==0 && record_in[10:8]==7 &&
                    d0>0 && d0<=60000 && d1>0 && d1<=60000 && d2>0 && d2<=60000;
            end
            if(pending)good<=position_ok && norm0>=lower0 && norm0<=upper0 &&
                norm1>=lower1 && norm1<=upper1 && norm2>=lower2 && norm2<=upper2;
        end
    end
endmodule
`default_nettype wire
