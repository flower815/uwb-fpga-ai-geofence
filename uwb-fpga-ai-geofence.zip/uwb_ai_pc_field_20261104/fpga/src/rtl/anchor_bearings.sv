`timescale 1ns/1ps
`default_nettype none
// Append A0/A1/A2 -> tag azimuths to one solved record, using the same XY.
module anchor_bearings #(
    parameter integer X0=0,Y0=0,X1=6000,Y1=0,X2=0,Y2=8000
)(
    input wire clk,rst_n,start,
    input wire [223:0] record_in,
    output wire busy,
    output reg valid,
    output reg [287:0] record_out
);
    localparam [1:0] IDLE=0,LAUNCH=1,WAIT_ANGLE=2,PACK=3;
    reg [1:0] state,index;
    reg [223:0] base;
    reg [47:0] angles;
    reg [2:0] angle_mask;
    wire signed [31:0] anchor_x=index==0 ? X0 : index==1 ? X1 : X2;
    wire signed [31:0] anchor_y=index==0 ? Y0 : index==1 ? Y1 : Y2;
    wire signed [31:0] dx=$signed(base[159:128])-anchor_x;
    wire signed [31:0] dy=$signed(base[191:160])-anchor_y;
    wire angle_done,angle_defined,cordic_busy;
    wire signed [31:0] angle;
    wire signed [31:0] normalized=angle<0 ? angle+32'sd36000 : angle;
    wire [15:0] azimuth=normalized>=36000 ? 16'd0 : normalized[15:0];
    assign busy=(state!=IDLE);
    cordic_atan2 cordic(.clk(clk),.rst_n(rst_n),.start(state==LAUNCH),
        .x_in(dx),.y_in(dy),.busy(cordic_busy),.valid(angle_done),
        .direction_valid(angle_defined),.angle_cdeg(angle));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; index<=0; base<=0; angles<=48'hffffffffffff;
            angle_mask<=0; valid<=0; record_out<=0;
        end else begin
            valid<=0;
            case(state)
                IDLE: if(start) begin
                    base<=record_in; index<=0; angles<=48'hffffffffffff; angle_mask<=0;
                    if(record_in[6:0]!=0 || record_in[10:8]!=3'b111) begin
                        record_out<={48'hffffffffffff,16'h0000,record_in}; valid<=1;
                    end else state<=LAUNCH;
                end
                LAUNCH: state<=WAIT_ANGLE;
                WAIT_ANGLE: if(angle_done) begin
                    angles[index*16 +: 16]<=angle_defined ? azimuth : 16'hffff;
                    angle_mask[index]<=angle_defined;
                    if(index==2) state<=PACK;
                    else begin index<=index+1'b1; state<=LAUNCH; end
                end
                PACK: begin
                    record_out<={angles,8'h00,5'b0,angle_mask,base}; valid<=1; state<=IDLE;
                end
                default: state<=IDLE;
            endcase
        end
    end
endmodule
`default_nettype wire
