`timescale 1ns/1ps
`default_nettype none
// Shared measurement/solver/FIFO path. rst_n is synchronized by the top level.
module uwb_position_core #(
    parameter integer CLK_HZ=50_000_000, UWB_BAUD=115200,
    parameter integer X0=0,Y0=0,Z0=0, X1=6000,Y1=0,Z1=0, X2=0,Y2=8000,Z2=0,
    parameter integer TAG_Z=0, ENABLE_ANGLES=0, ENABLE_FENCE=0, RANGE_FILTER=0,FENCE_CONFIRM=1,
    parameter integer CLEAR_HITS=1,CLEAR_MARGIN_MM=0,QUALITY_ENABLE=0,QUALITY_LIMIT_MM=200,
    parameter integer FAULT_ENABLE=0,FAULT_TIMEOUT_MS=1000,FAULT_STARTUP_MS=3000,EXPECTED_TAG=2,
    parameter integer RECORD_WIDTH=(ENABLE_ANGLES || ENABLE_FENCE) ? 288 : 224
)(
    input wire clk, rst_n, uwb_rx,stream_enable,
    output wire [RECORD_WIDTH-1:0] record_out,
    output wire record_valid,
    input wire record_ready,
    output wire fence_alarm,position_fault
);
    wire [7:0] rx_data,mask,seq,tag;
    wire rx_valid,rx_error,frame_valid,solver_busy,sol_valid;
    wire [31:0] d0,d1,d2;
    wire [223:0] solved,result;
    wire sample_valid;
    wire [7:0] sample_mask,sample_seq,sample_tag;
    wire [31:0] sample0,sample1,sample2,raw0,raw1,raw2;
    reg [95:0] saved_raw;
    wire solve_start=sample_valid && !solver_busy && !angle_busy;
    generate if(RANGE_FILTER) begin : range_filter
        range_median3 #(.GAP_CYCLES(CLK_HZ)) median_filter(
            .clk(clk),.rst_n(rst_n),.in_valid(frame_valid),
            .mask_in(mask),.seq_in(seq),.tag_in(tag),.d0_in(d0),.d1_in(d1),.d2_in(d2),
            .out_valid(sample_valid),.mask_out(sample_mask),.seq_out(sample_seq),.tag_out(sample_tag),
            .d0_out(sample0),.d1_out(sample1),.d2_out(sample2),.raw0(raw0),.raw1(raw1),.raw2(raw2));
    end else begin : range_bypass
        assign sample_valid=frame_valid;
        assign {sample_mask,sample_seq,sample_tag}={mask,seq,tag};
        assign {sample0,sample1,sample2,raw0,raw1,raw2}={d0,d1,d2,d0,d1,d2};
    end endgenerate
    always @(posedge clk or negedge rst_n)
        if(!rst_n) saved_raw<=0;
        else if(solve_start) saved_raw<={raw2,raw1,raw0};
    // Packet distances remain the CURRENT RAW measurements for diagnostics.
    assign result={solved[223:128],saved_raw,solved[31:0]};
    wire [RECORD_WIDTH-1:0] processed,angle_record,reported,enqueue_record,heartbeat_record;
    wire processed_valid,angle_valid,angle_busy;
    wire queue_ready,heartbeat_pending;
    wire heartbeat_take=heartbeat_pending && !processed_valid && queue_ready && stream_enable;
    wire enqueue_valid=processed_valid || heartbeat_pending;
    wire [RECORD_WIDTH-1:0] selected_record=processed_valid?reported:heartbeat_record;
    reg lost;
    assign enqueue_record={selected_record[RECORD_WIDTH-1:8],(selected_record[7:0] | (lost ? 8'h80 : 8'h00))};
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) lost<=0;
        else if (!stream_enable) lost<=0;
        else if ((sample_valid && (solver_busy || angle_busy)) || (processed_valid && !queue_ready)) lost<=1;
        else if (processed_valid && queue_ready) lost<=0;
    end
    uart_rx #(.CLK_HZ(CLK_HZ),.BAUD(UWB_BAUD)) rx_uart(
        .clk(clk),.rst_n(rst_n),.rx(uwb_rx),.data(rx_data),.valid(rx_valid),.framing_error(rx_error));
    mini5_parser #(.CLK_HZ(CLK_HZ)) parser(
        .clk(clk),.rst_n(rst_n),.data(rx_data),.byte_valid(rx_valid),.framing_error(rx_error),
        .frame_valid(frame_valid),.mask(mask),.seq(seq),.tag(tag),.d0(d0),.d1(d1),.d2(d2));
    trilateration_2d #(.X0(X0),.Y0(Y0),.Z0(Z0),.X1(X1),.Y1(Y1),.Z1(Z1),
        .X2(X2),.Y2(Y2),.Z2(Z2),.TAG_Z(TAG_Z)) solver(
        .clk(clk),.rst_n(rst_n),.start(solve_start),
        .mask_in(sample_mask),.seq_in(sample_seq),.tag_in(sample_tag),.d0_in(sample0),.d1_in(sample1),.d2_in(sample2),
        .busy(solver_busy),.valid(sol_valid),.record_out(solved));
    generate if(ENABLE_ANGLES) begin : with_angles
        anchor_bearings #(.X0(X0),.Y0(Y0),.X1(X1),.Y1(Y1),.X2(X2),.Y2(Y2)) bearings(
            .clk(clk),.rst_n(rst_n),.start(sol_valid),.record_in(result),
            .busy(angle_busy),.valid(angle_valid),.record_out(angle_record));
    end else begin : without_angles
        if(ENABLE_FENCE) assign angle_record={48'hffffffffffff,16'h0000,result};
        else assign angle_record=result;
        assign angle_valid=sol_valid;
        assign angle_busy=1'b0;
    end endgenerate
    generate if(ENABLE_FENCE) begin : with_fence
        wire [8:0] alarm_tags;
        wire next_alarm;
        wire [1:0] next_hits;
        wire [7:0] raw_flags;
        wire [223:0] raw_result;
        wire raw_valid;
        wire raw_deep;
        reg saved_raw_deep;
        wire raw_quality;
        triangle_inset #(.X0(X0),.Y0(Y0),.X1(X1),.Y1(Y1),.X2(X2),.Y2(Y2),.MARGIN_MM(CLEAR_MARGIN_MM)) raw_inset(
            .record_in(raw_result),.deep_inside(raw_deep));
        always @(posedge clk or negedge rst_n)
            if(!rst_n)saved_raw_deep<=0;else if(raw_valid)saved_raw_deep<=raw_deep;
        if(QUALITY_ENABLE)begin : quality_check
            wire quality_valid,quality_good;
            reg saved_quality;
            range_consistency #(.X0(X0),.Y0(Y0),.Z0(Z0),.X1(X1),.Y1(Y1),.Z1(Z1),
                .X2(X2),.Y2(Y2),.Z2(Z2),.LIMIT_MM(QUALITY_LIMIT_MM)) check_raw(
                .clk(clk),.rst_n(rst_n),.in_valid(raw_valid),.record_in(raw_result),.out_valid(quality_valid),.good(quality_good));
            always @(posedge clk or negedge rst_n)
                if(!rst_n)saved_quality<=0;else if(quality_valid)saved_quality<=quality_good;
            assign raw_quality=saved_quality;
        end else begin : no_quality_check
            assign raw_quality=1'b1;
        end
        if(RANGE_FILTER) begin : raw_protection
            wire raw_fence_valid;
            wire [287:0] raw_fenced;
            trilateration_2d #(.X0(X0),.Y0(Y0),.Z0(Z0),.X1(X1),.Y1(Y1),.Z1(Z1),
                .X2(X2),.Y2(Y2),.Z2(Z2),.TAG_Z(TAG_Z)) raw_solver(
                .clk(clk),.rst_n(rst_n),.start(solve_start),.busy(),.valid(raw_valid),.record_out(raw_result),
                .mask_in(sample_mask),.seq_in(sample_seq),.tag_in(sample_tag),.d0_in(raw0),.d1_in(raw1),.d2_in(raw2));
            triangle_geofence #(.X0(X0),.Y0(Y0),.X1(X1),.Y1(Y1),.X2(X2),.Y2(Y2)) raw_fence(
                .clk(clk),.rst_n(rst_n),.in_valid(raw_valid),.record_in({64'b0,raw_result}),
                .out_valid(raw_fence_valid),.record_out(raw_fenced));
            reg [7:0] saved_raw_flags;
            always @(posedge clk or negedge rst_n)
                if(!rst_n)saved_raw_flags<=0;
                else if(raw_fence_valid)saved_raw_flags<=raw_fenced[239:232];
            assign raw_flags=saved_raw_flags;
        end else begin : no_raw_protection
            assign raw_flags=processed[239:232];
            assign raw_result=solved;
            assign raw_valid=sol_valid;
        end
        wire [RECORD_WIDTH-1:0] fenced;
        wire fenced_valid;
        triangle_geofence #(.X0(X0),.Y0(Y0),.X1(X1),.Y1(Y1),.X2(X2),.Y2(Y2)) fence(
            .clk(clk),.rst_n(rst_n),.in_valid(angle_valid),.record_in(angle_record),
            .out_valid(fenced_valid),.record_out(fenced));
        if(RANGE_FILTER || QUALITY_ENABLE || CLEAR_HITS>1) begin : align_raw_alarm
            reg valid;
            reg [RECORD_WIDTH-1:0] saved;
            always @(posedge clk or negedge rst_n)
                if(!rst_n) begin valid<=0;saved<=0;end
                else begin valid<=fenced_valid;if(fenced_valid)saved<=fenced;end
            assign processed_valid=valid;
            assign processed=saved;
        end else begin : no_alignment
            assign processed_valid=fenced_valid;
            assign processed=fenced;
        end
        // Each sample votes once, even if both raw and filtered paths are outside.
        wire [7:0] vote_flags=!raw_quality?8'd0:(raw_flags==3 || processed[239:232]==3)?8'd3:
                               (raw_flags==1 && processed[239:232]==1)?8'd1:8'd0;
        wire [287:0] vote_record={processed[287:240],vote_flags,processed[231:8],vote_flags==0 ? 8'h01 : 8'h00};
        wire filtered_deep;
        triangle_inset #(.X0(X0),.Y0(Y0),.X1(X1),.Y1(Y1),.X2(X2),.Y2(Y2),.MARGIN_MM(CLEAR_MARGIN_MM)) filtered_inset(
            .record_in(processed[223:0]),.deep_inside(filtered_deep));
        geofence_alarm #(.CONFIRM_HITS(FENCE_CONFIRM),.GAP_CYCLES(CLK_HZ),.CLEAR_HITS(CLEAR_HITS)) latch(
            .clk(clk),.rst_n(rst_n),.record_valid(processed_valid),.record_in(vote_record),
            .alarm(fence_alarm),.alarm_tags(alarm_tags),.record_alarm(next_alarm),.record_hits(next_hits),
            .clear_ok(saved_raw_deep && filtered_deep && raw_quality));
        wire position_ok=(processed[6:0]==0 && processed[10:8]==7);
        wire [7:0] report_flags=next_alarm ? ((processed[239:232]==3 && position_ok && raw_quality)?8'd3:8'd4):
            (vote_flags==3 && position_ok && next_hits>0)?((next_hits==1)?8'd8:8'd16):
            (vote_flags==1)?8'd1:8'd0;
        wire record_fault;
        wire [7:0] expected_seq;
        if(FAULT_ENABLE)begin : measurement_fault
            position_watchdog #(.TIMEOUT_CYCLES((CLK_HZ/1000)*FAULT_TIMEOUT_MS),
                .STARTUP_CYCLES((CLK_HZ/1000)*FAULT_STARTUP_MS),.EXPECTED_TAG(EXPECTED_TAG),.RECOVERY_HITS(3)) watchdog(
                .clk(clk),.rst_n(rst_n),.sample_valid(processed_valid),
                // Localization health is independent of fence confirmation.
                .trustworthy(position_ok && raw_quality),
                .tag(processed[31:24]),.seq(processed[23:16]),.fault(position_fault),
                .record_fault(record_fault),.last_seq(expected_seq));
            localparam integer HEARTBEAT_CYCLES=(CLK_HZ/5<1)?1:CLK_HZ/5;
            reg [31:0] heartbeat_age;
            reg pending,previous_fault;
            always @(posedge clk or negedge rst_n)begin
                if(!rst_n)begin heartbeat_age<=0;pending<=0;previous_fault<=0;end
                else begin
                    previous_fault<=position_fault;
                    if(!position_fault)begin heartbeat_age<=0;pending<=0;end
                    else begin
                        if(!previous_fault || heartbeat_age>=HEARTBEAT_CYCLES-1)begin
                            heartbeat_age<=0;pending<=1;
                        end else heartbeat_age<=heartbeat_age+1'b1;
                        if(heartbeat_take)pending<=0;
                    end
                end
            end
            assign heartbeat_pending=pending && position_fault;
            wire held_expected=alarm_tags[EXPECTED_TAG];
            localparam [7:0] EXPECTED_ID=EXPECTED_TAG;
            localparam [31:0] CONFIG_Z=TAG_Z;
            assign heartbeat_record={48'hffffffffffff,(held_expected?8'h24:8'h20),8'h00,
                CONFIG_Z,32'b0,32'b0,96'b0,EXPECTED_ID,expected_seq,8'h00,8'h10};
        end else begin : no_measurement_fault
            assign position_fault=0;assign record_fault=0;assign expected_seq=0;
            assign heartbeat_pending=0;assign heartbeat_record=0;
        end
        wire expected_fault=FAULT_ENABLE && processed[31:24]==EXPECTED_TAG && record_fault;
        wire [7:0] final_flags=expected_fault?(next_alarm?8'h24:8'h20):report_flags;
        wire [7:0] final_status=processed[7:0] | ((!raw_quality || expected_fault)?8'h10:8'h00);
        // Bad quality and recovery-wait samples are not published as trusted XY.
        assign reported=(final_status[6:0]!=0)?
            {48'hffffffffffff,final_flags,8'h00,processed[223:8],final_status}:
            {processed[287:240],final_flags,processed[231:8],final_status};
    end else begin : without_fence
        assign processed=angle_record;
        assign processed_valid=angle_valid;
        assign fence_alarm=1'b0;
        assign position_fault=1'b0;
        assign heartbeat_pending=1'b0;assign heartbeat_record=0;
        assign reported=processed;
    end endgenerate
    // Local geofence keeps running without USB/TCP. Only the transmit FIFO clears.
    wire queue_rst_n=rst_n && stream_enable;
    record_fifo #(.WIDTH(RECORD_WIDTH)) queue(.clk(clk),.rst_n(queue_rst_n),.in_data(enqueue_record),
        .in_valid(enqueue_valid && stream_enable),.in_ready(queue_ready),.out_data(record_out),
        .out_valid(record_valid),.out_ready(record_ready));
endmodule
`default_nettype wire
