`timescale 1ns/1ps
`default_nettype none
module uwb_wifi_top #(
    parameter integer CLK_HZ=50_000_000, UWB_BAUD=115200, PC_BAUD=115200,
    parameter integer X0=0,Y0=0,Z0=0, X1=6000,Y1=0,Z1=0, X2=0,Y2=8000,Z2=0,
    parameter integer TAG_Z=0, LEGACY_CUR=0, ENABLE_ANGLES=0, ENABLE_FENCE=0, ENABLE_BUZZER=0,
    parameter integer JOIN_LEN=38, TCP_LEN=42,
    parameter [2047:0] JOIN_COMMAND="AT+CWJAP=\"YOUR_WIFI\",\"YOUR_PASSWORD\"\015\012",
    parameter [1023:0] TCP_COMMAND="AT+CIPSTART=\"TCP\",\"192.168.1.100\",9000,5\015\012",
    parameter integer RESET_MS=100, BOOT_MS=2000, GUARD_MS=1100,
    parameter integer FLUSH_MS=200, RETRY_MS=2000, ACK_TIMEOUT_MS=3000,
    parameter integer JOIN_TIMEOUT_MS=40000, TCP_TIMEOUT_MS=10000,
    parameter integer SEND_TIMEOUT_MS=10000, POLL_MS=5000
)(
    input wire sys_clk,sys_rst_n,uwb_rx,esp_rx,
    output wire esp_tx,
    output wire esp_rst_n,
    output wire beep
);
    (* ASYNC_REG="TRUE" *) reg [3:0] reset_pipe=4'b0000;
    always @(posedge sys_clk or negedge sys_rst_n)
        if(!sys_rst_n) reset_pipe<=0;
        else reset_pipe<={reset_pipe[2:0],1'b1};
    wire rst_n=reset_pipe[3];
    (* MARK_DEBUG="TRUE" *) wire online;
    (* MARK_DEBUG="TRUE" *) wire [7:0] last_error;
    (* MARK_DEBUG="TRUE" *) wire [15:0] retry_count;
    (* MARK_DEBUG="TRUE" *) wire [3:0] state_debug,command_debug;
    wire reset_asserted;
    // Open-drain reset: ESP-01S must have its 3.3V reset pull-up fitted.
    assign esp_rst_n=reset_asserted ? 1'b0 : 1'bz;
    localparam integer RECORD_WIDTH=(ENABLE_ANGLES || ENABLE_FENCE) ? 288 : 224;
    wire [RECORD_WIDTH-1:0] record;
    wire record_valid,record_ready;
    // Network outages do not disable local measurement/geofence/buzzer logic.
    wire fence_alarm;
    uwb_position_core #(.CLK_HZ(CLK_HZ),.UWB_BAUD(UWB_BAUD),
        .X0(X0),.Y0(Y0),.Z0(Z0),.X1(X1),.Y1(Y1),.Z1(Z1),
        .X2(X2),.Y2(Y2),.Z2(Z2),.TAG_Z(TAG_Z),.ENABLE_ANGLES(ENABLE_ANGLES),.ENABLE_FENCE(ENABLE_FENCE)) core(
        .clk(sys_clk),.rst_n(rst_n),.uwb_rx(uwb_rx),.stream_enable(online),
        .record_out(record),.record_valid(record_valid),.record_ready(record_ready),.fence_alarm(fence_alarm));
    geofence_buzzer #(.CLK_HZ(CLK_HZ),.ENABLE_BUZZER(ENABLE_BUZZER)) buzzer(
        .clk(sys_clk),.rst_n(rst_n),.alarm(fence_alarm),.beep(beep));
    esp01s_at_link #(.CLK_HZ(CLK_HZ),.BAUD(PC_BAUD),.LEGACY_CUR(LEGACY_CUR),.ENABLE_ANGLES(ENABLE_ANGLES),.ENABLE_FENCE(ENABLE_FENCE),
        .JOIN_LEN(JOIN_LEN),.JOIN_COMMAND(JOIN_COMMAND),.TCP_LEN(TCP_LEN),.TCP_COMMAND(TCP_COMMAND),
        .RESET_MS(RESET_MS),.BOOT_MS(BOOT_MS),.GUARD_MS(GUARD_MS),.FLUSH_MS(FLUSH_MS),
        .RETRY_MS(RETRY_MS),.ACK_TIMEOUT_MS(ACK_TIMEOUT_MS),.JOIN_TIMEOUT_MS(JOIN_TIMEOUT_MS),
        .TCP_TIMEOUT_MS(TCP_TIMEOUT_MS),.SEND_TIMEOUT_MS(SEND_TIMEOUT_MS),.POLL_MS(POLL_MS)) wifi(
        .clk(sys_clk),.rst_n(rst_n),.esp_rx(esp_rx),.esp_tx(esp_tx),.reset_asserted(reset_asserted),
        .record_in(record),.record_valid(record_valid),.record_ready(record_ready),.online(online),
        .last_error(last_error),.retry_count(retry_count),.state_debug(state_debug),.command_debug(command_debug));
endmodule
`default_nettype wire
