`timescale 1ns/1ps
`default_nettype none
// ESP8266 CIPMUX=0, CIPDINFO=0: +IPD,<decimal length>:<exact binary bytes>.
// TCP chunks may split a command or contain multiple commands. Binary data
// never reaches the AT reply matcher, even if it contains CLOSED / SEND OK.
module esp_ipd_demux #(
    parameter integer CLK_HZ=50_000_000, GAP_CYCLES=CLK_HZ/20
)(
    input wire clk,rst_n,
    input wire [7:0] in_data,
    input wire in_valid,in_error,
    output reg [7:0] text_data,app_data,
    output reg text_valid,text_clear,app_valid,error
);
    localparam [3:0] NORMAL=0,I=1,P=2,D=3,COMMA=4,LENGTH=5,BINARY=6,DROP=7;
    reg [3:0] state;
    reg [15:0] length,remaining;
    reg [2:0] digits;
    reg [31:0] gap;
    wire digit=(in_data>=8'h30 && in_data<=8'h39);
    wire [3:0] number=in_data-8'h30;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state<=NORMAL;length<=0;remaining<=0;digits<=0;gap<=0;
            text_data<=0;app_data<=0;text_valid<=0;text_clear<=0;app_valid<=0;error<=0;
        end else begin
            text_valid<=0;text_clear<=0;app_valid<=0;error<=0;
            if(state!=NORMAL && state!=DROP)begin
                if(gap>=GAP_CYCLES-1)begin state<=DROP;text_clear<=1;error<=1;end
                else gap<=gap+1'b1;
            end
            if(in_error)begin state<=DROP;text_clear<=1;error<=1;gap<=0;end
            else if(in_valid)begin
                gap<=0;
                case(state)
                    NORMAL:if(in_data=="+")begin state<=I;text_clear<=1;end
                           else begin text_data<=in_data;text_valid<=1;end
                    I:if(in_data=="I")state<=P;else state<=DROP;
                    P:if(in_data=="P")state<=D;else state<=DROP;
                    D:if(in_data=="D")state<=COMMA;else state<=DROP;
                    COMMA:if(in_data==",")begin state<=LENGTH;length<=0;digits<=0;end
                          else begin state<=DROP;error<=1;end
                    LENGTH:begin
                        if(digit && digits<5 && (length<6553 || (length==6553 && number<=5)))begin
                            length<=length*10+number;digits<=digits+1'b1;
                        end else if(in_data==":" && digits!=0)begin
                            remaining<=length;state<=length==0 ? NORMAL : BINARY;text_clear<=1;
                        end else begin state<=DROP;text_clear<=1;error<=1;end
                    end
                    BINARY:begin
                        app_data<=in_data;app_valid<=1;remaining<=remaining-1'b1;
                        if(remaining==1)begin state<=NORMAL;text_clear<=1;end
                    end
                    DROP:if(in_data==8'h0a)begin state<=NORMAL;text_clear<=1;end
                    default:begin state<=NORMAL;text_clear<=1;end
                endcase
            end
        end
    end
endmodule
`default_nettype wire
