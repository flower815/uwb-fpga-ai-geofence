`timescale 1ns/1ps
`default_nettype none
// Distances and coordinates in mm. Tag height is a known constant, not estimated.
// Bounds: |anchor coordinates|, |TAG_Z| <= 30000; 0 < ranges <= 60000.
module trilateration_2d #(
    parameter integer X0=0, Y0=0, Z0=0,
    parameter integer X1=6000, Y1=0, Z1=0,
    parameter integer X2=0, Y2=8000, Z2=0,
    parameter integer TAG_Z=0,
    parameter integer MIN_ABS_DET=1_000_000
)(
    input wire clk, rst_n, start,
    input wire [7:0] mask_in, seq_in, tag_in,
    input wire [31:0] d0_in, d1_in, d2_in,
    output wire busy,
    output reg valid,
    output reg [223:0] record_out
);
    localparam signed [63:0] AX0=X0, AY0=Y0, AZ0=Z0,
        AX1=X1, AY1=Y1, AZ1=Z1, AX2=X2, AY2=Y2, AZ2=Z2, TZ=TAG_Z;
    localparam signed [63:0] A=2*(AX1-AX0), B=2*(AY1-AY0),
        C=2*(AX2-AX0), D=2*(AY2-AY0), DET=A*D-B*C;
    localparam signed [63:0] K1=AX1*AX1+AY1*AY1+(AZ1-TZ)*(AZ1-TZ)
        -AX0*AX0-AY0*AY0-(AZ0-TZ)*(AZ0-TZ);
    localparam signed [63:0] K2=AX2*AX2+AY2*AY2+(AZ2-TZ)*(AZ2-TZ)
        -AX0*AX0-AY0*AY0-(AZ0-TZ)*(AZ0-TZ);
    localparam BAD_COORD = X0 < -30000 || X0 > 30000 || Y0 < -30000 || Y0 > 30000 ||
        Z0 < -30000 || Z0 > 30000 || X1 < -30000 || X1 > 30000 || Y1 < -30000 || Y1 > 30000 ||
        Z1 < -30000 || Z1 > 30000 || X2 < -30000 || X2 > 30000 || Y2 < -30000 || Y2 > 30000 ||
        Z2 < -30000 || Z2 > 30000 || TAG_Z < -30000 || TAG_Z > 30000;
    reg [3:0] state;
    reg [7:0] mask, seq, tag, status;
    reg [31:0] d0,d1,d2;
    reg signed [63:0] e, f, nx, ny, x, y;
    reg div_start;
    reg signed [63:0] div_n;
    wire div_done;
    wire signed [63:0] div_q;
    assign busy = state != 0;
    function automatic signed [63:0] square_range(input [31:0] v);
        reg signed [63:0] wide;
        begin wide = {32'b0,v}; square_range = wide*wide; end
    endfunction
    signed_div64 divider(.clk(clk),.rst_n(rst_n),.start(div_start),
        .numerator(div_n),.denominator(DET),.busy(),.done(div_done),
        .divide_by_zero(),.quotient(div_q));
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; valid<=0; record_out<=0; div_start<=0; div_n<=0;
            mask<=0; seq<=0; tag<=0; status<=0; d0<=0; d1<=0; d2<=0;
            e<=0; f<=0; nx<=0; ny<=0; x<=0; y<=0;
        end else begin
            valid <= 0; div_start <= 0;
            case (state)
                0: if (start) begin
                    mask<=mask_in; seq<=seq_in; tag<=tag_in;
                    d0<=d0_in; d1<=d1_in; d2<=d2_in; x<=0; y<=0; status<=0; state<=1;
                end
                1: begin
                    if ((mask & 8'h07) != 7) begin status<=8'h01; state<=9; end
                    else if (d0==0 || d1==0 || d2==0 || d0>60000 || d1>60000 || d2>60000)
                        begin status<=8'h02; state<=9; end
                    else if (BAD_COORD || DET==0 || (DET > -MIN_ABS_DET && DET < MIN_ABS_DET))
                        begin status<=8'h04; state<=9; end
                    else state<=2;
                end
                2: begin
                    e<=square_range(d0)-square_range(d1)+K1;
                    f<=square_range(d0)-square_range(d2)+K2; state<=3;
                end
                3: begin nx<=e*D-B*f; ny<=A*f-e*C; state<=4; end
                4: begin div_n<=nx; div_start<=1; state<=5; end
                5: if (div_done) begin x<=div_q; state<=6; end
                6: begin div_n<=ny; div_start<=1; state<=7; end
                7: if (div_done) begin y<=div_q; state<=8; end
                8: begin
                    if (x < -30000 || x > 30000 || y < -30000 || y > 30000) begin
                        status<=8'h08; x<=0; y<=0;
                    end
                    state<=9;
                end
                9: begin
                    record_out <= {TZ[31:0], y[31:0], x[31:0], d2,d1,d0,tag,seq,mask,status};
                    valid<=1; state<=0;
                end
                default: state<=0;
            endcase
        end
    end
endmodule
`default_nettype wire
