`timescale 1ns/1ps
`default_nettype none
module record_fifo #(
    parameter integer WIDTH=224, ADDR_BITS=4
)(
    input wire clk,rst_n,
    input wire [WIDTH-1:0] in_data,
    input wire in_valid,
    output wire in_ready,
    output wire [WIDTH-1:0] out_data,
    output wire out_valid,
    input wire out_ready
);
    reg [WIDTH-1:0] mem[0:(1<<ADDR_BITS)-1];
    reg [ADDR_BITS-1:0] wr,rd;
    reg [ADDR_BITS:0] count;
    wire push = in_valid && in_ready;
    wire pop = out_valid && out_ready;
    // A full FIFO can replace the word being consumed on this same edge.
    // The asynchronous head is sampled before the nonblocking memory write.
    assign in_ready = count < (1<<ADDR_BITS) || (out_valid && out_ready);
    assign out_valid = count != 0;
    assign out_data = mem[rd];
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin wr<=0; rd<=0; count<=0; end
        else begin
            if (push) begin mem[wr]<=in_data; wr<=wr+1'b1; end
            if (pop) rd<=rd+1'b1;
            case ({push,pop})
                2'b10: count<=count+1'b1;
                2'b01: count<=count-1'b1;
                default: count<=count;
            endcase
        end
    end
endmodule
`default_nettype wire
