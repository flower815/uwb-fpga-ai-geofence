`timescale 1ns/1ps
`default_nettype none
// Distinct from the 500ms on/off geofence alarm: 100ms every second.
module position_fault_buzzer #(
    parameter integer CLK_HZ=50_000_000,ENABLE_BUZZER=1
)(input wire clk,rst_n,fault,output wire beep);
    localparam integer PERIOD=(CLK_HZ<10)?10:CLK_HZ;
    localparam integer ON_CYCLES=PERIOD/10;
    reg [31:0] count;
    always @(posedge clk or negedge rst_n)
        if(!rst_n)count<=0;
        else if(!fault || count==PERIOD-1)count<=0;
        else count<=count+1'b1;
    assign beep=ENABLE_BUZZER && rst_n && fault && count<ON_CYCLES;
endmodule
`default_nettype wire
