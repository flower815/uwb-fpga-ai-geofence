`timescale 1ns/1ps
`default_nettype none
// Atomic V3 telemetry / 18-byte control ACK multiplexing on one UART.
// Requests: 55 aa 10 opcode seq16 flags reserved token32 reserved32 crc16.
// ACKs:     55 aa 11 opcode seq16 state result   token32 tick32     crc16.
// Read-only opcode 3: flags is register index; ACK tick32 is register value.
module ai_usb_link #(
    parameter integer CLK_HZ=50_000_000, BAUD=115200,
    parameter integer WATCHDOG_CYCLES=2*CLK_HZ,
    parameter integer RX_TIMEOUT_CYCLES=CLK_HZ/20, EXTERNAL_BYTES=0
)(
    input wire clk,rst_n,rx,stream_online,
    input wire [7:0] command_data,
    input wire command_valid,command_error,
    output wire [7:0] stream_data,
    output wire stream_valid,
    input wire stream_ready,
    input wire [287:0] record_in,
    input wire record_valid,
    output wire record_ready,
    input wire local_alarm,beep_state,
    output wire host_warning,
    output reg armed,watchdog_fault,
    output wire tx,
    input wire [31:0] profile_value,
    input wire profile_valid,
    output wire [7:0] profile_index
);
    function automatic [15:0] crc_byte(input [15:0] previous,input [7:0] value);
        reg [15:0] c;integer i;
        begin
            c=previous^{value,8'h00};
            for(i=0;i<8;i=i+1)c=c[15] ? (c<<1)^16'h1021 : c<<1;
            crc_byte=c;
        end
    endfunction
    wire [7:0] rx_data;wire rx_valid,rx_error;
    generate if(EXTERNAL_BYTES)begin : network_rx
        assign rx_data=command_data;assign rx_valid=command_valid;assign rx_error=command_error;
    end else begin : serial_rx
        uart_rx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) receiver(
            .clk(clk),.rst_n(rst_n),.rx(rx),.data(rx_data),.valid(rx_valid),.framing_error(rx_error));
    end endgenerate
    reg [4:0] rx_index;
    reg [127:0] request;
    reg [15:0] rx_crc;
    reg [7:0] crc_low;
    reg [31:0] rx_age,tick,lease_age;
    reg warning_reg;
    assign host_warning=warning_reg || watchdog_fault;
    reg ack_pending;
    reg [127:0] ack;
    wire [7:0] opcode=request[31:24];
    assign profile_index=request[55:48];
    wire valid_command=(request[23:16]==8'h10 && request[63:56]==0 && request[127:96]==0 &&
                        (opcode==3 || (request[55:48]&8'hfe)==0));
    wire profile_supported=(profile_valid === 1'b1);
    wire [7:0] result_code=!valid_command ? 8'd2 : opcode>3 ? 8'd1 :
                           (opcode==3 && !profile_supported) ? 8'd3 : 8'd0;
    wire [31:0] reply_value=(opcode==3) ? ((result_code==0)?profile_value:32'b0) : tick;
    reg [7:0] next_state;
    always @* begin
        next_state={3'b000,armed,beep_state,local_alarm,watchdog_fault,warning_reg};
        if(result_code==0 && opcode==1) begin
            next_state[4]=1;next_state[1]=0;next_state[0]=request[48];
        end
        if(result_code==0 && opcode==2) begin
            next_state[4]=0;next_state[1:0]=0;
        end
    end
    wire byte_ready;
    reg active;
    reg [335:0] payload;
    reg [5:0] tx_index,body_bytes;
    reg [15:0] tx_crc;
    wire [7:0] tx_data=tx_index<body_bytes ? payload[tx_index*8+:8] :
                                    tx_index==body_bytes ? tx_crc[7:0] : tx_crc[15:8];
    wire take_ack=!active && ack_pending && stream_online;
    assign record_ready=!active && !ack_pending && stream_online;
    assign stream_data=tx_data;assign stream_valid=active && stream_online;
    generate if(EXTERNAL_BYTES)begin : network_tx
        assign byte_ready=stream_ready;assign tx=1'b1;
    end else begin : serial_tx
        uart_tx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) sender(
            .clk(clk),.rst_n(rst_n),.data(tx_data),.valid(active),.ready(byte_ready),.tx(tx));
    end endgenerate
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            rx_index<=0;request<=0;rx_crc<=16'hffff;crc_low<=0;rx_age<=0;
            tick<=0;lease_age<=0;warning_reg<=0;armed<=0;watchdog_fault<=0;
            ack_pending<=0;ack<=0;
        end else begin
            tick<=tick+1'b1;
            if(armed && !watchdog_fault) begin
                if(lease_age>=WATCHDOG_CYCLES-1)watchdog_fault<=1;
                else lease_age<=lease_age+1'b1;
            end
            if(take_ack)ack_pending<=0;
            if(!stream_online)ack_pending<=0;
            if(rx_index!=0)begin
                if(rx_age>=RX_TIMEOUT_CYCLES-1)begin rx_index<=0;rx_age<=0;end
                else rx_age<=rx_age+1'b1;
            end
            if(rx_error || !stream_online)begin rx_index<=0;rx_age<=0;end
            else if(rx_valid)begin
                rx_age<=0;
                case(rx_index)
                    0:if(rx_data==8'h55)begin
                        request[7:0]<=rx_data;rx_crc<=crc_byte(16'hffff,rx_data);rx_index<=1;
                    end
                    1:if(rx_data==8'haa)begin
                        request[15:8]<=rx_data;rx_crc<=crc_byte(rx_crc,rx_data);rx_index<=2;
                    end else if(rx_data==8'h55)rx_crc<=crc_byte(16'hffff,rx_data);
                    else rx_index<=0;
                    16:begin crc_low<=rx_data;rx_index<=17;end
                    17:begin
                        rx_index<=0;
                        // Backpressure at packet granularity. Busy requests are not executed;
                        // the PC observes a timeout and may retry its idempotent SET command.
                        if({rx_data,crc_low}==rx_crc && (!ack_pending || take_ack))begin
                            ack<={reply_value,request[95:64],result_code,next_state,request[47:32],opcode,8'h11,16'haa55};
                            ack_pending<=1;
                            if(result_code==0 && opcode==1)begin
                                armed<=1;warning_reg<=request[48];watchdog_fault<=0;lease_age<=0;
                            end
                            if(result_code==0 && opcode==2)begin
                                armed<=0;warning_reg<=0;watchdog_fault<=0;lease_age<=0;
                            end
                        end
                    end
                    default:begin
                        request[rx_index*8+:8]<=rx_data;rx_crc<=crc_byte(rx_crc,rx_data);rx_index<=rx_index+1'b1;
                    end
                endcase
            end
        end
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin active<=0;payload<=0;tx_index<=0;body_bytes<=0;tx_crc<=16'hffff;end
        else if(!stream_online)begin active<=0;tx_index<=0;body_bytes<=0;tx_crc<=16'hffff;end
        else if(!active)begin
            if(ack_pending)begin payload<={208'b0,ack};body_bytes<=16;active<=1;tx_index<=0;tx_crc<=16'hffff;end
            else if(record_valid)begin
                payload<={16'b0,record_in[287:32],8'h00,record_in[31:0],8'h03,16'haa55};
                body_bytes<=40;active<=1;tx_index<=0;tx_crc<=16'hffff;
            end
        end else if(byte_ready)begin
            if(tx_index<body_bytes)tx_crc<=crc_byte(tx_crc,tx_data);
            if(tx_index==body_bytes+1)active<=0;
            else tx_index<=tx_index+1'b1;
        end
    end
endmodule
`default_nettype wire
