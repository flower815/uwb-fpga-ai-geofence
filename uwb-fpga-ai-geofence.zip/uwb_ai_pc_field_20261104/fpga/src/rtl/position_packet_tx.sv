`timescale 1ns/1ps
`default_nettype none
// V1: 34 bytes. V2: 42 bytes, appends validity/reserved/three uint16 azimuths.
// Little endian, CRC16/CCITT-FALSE over all bytes preceding the two CRC bytes.
module position_packet_tx #(
    parameter integer CLK_HZ=50_000_000, BAUD=115200, ENABLE_ANGLES=0, ENABLE_FENCE=0,
    parameter integer RECORD_WIDTH=(ENABLE_ANGLES || ENABLE_FENCE) ? 288 : 224
)(
    input wire clk,rst_n,
    input wire [RECORD_WIDTH-1:0] record_in,
    input wire record_valid,
    output wire record_ready,
    output wire tx
);
    reg active;
    localparam integer BODY_BYTES=(ENABLE_ANGLES || ENABLE_FENCE) ? 40 : 32;
    localparam [7:0] VERSION=ENABLE_FENCE ? 8'h03 : ENABLE_ANGLES ? 8'h02 : 8'h01;
    reg [BODY_BYTES*8-1:0] payload;
    reg [5:0] idx;
    reg [15:0] crc;
    wire byte_ready;
    wire [7:0] byte_data = idx < BODY_BYTES ? payload[idx*8 +: 8] : (idx==BODY_BYTES ? crc[7:0] : crc[15:8]);
    assign record_ready = !active;
    function automatic [15:0] crc_byte(input [15:0] old_crc, input [7:0] b);
        reg [15:0] c;
        integer k;
        begin
            c=old_crc^{b,8'h00};
            for(k=0;k<8;k=k+1) c=c[15] ? (c<<1)^16'h1021 : c<<1;
            crc_byte=c;
        end
    endfunction
    uart_tx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) uart(
        .clk(clk),.rst_n(rst_n),.data(byte_data),.valid(active),.ready(byte_ready),.tx(tx));
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin active<=0; payload<=0; idx<=0; crc<=16'hffff; end
        else if (!active) begin
            if (record_valid) begin
                payload<={record_in[RECORD_WIDTH-1:32],8'h00,record_in[31:0],VERSION,16'haa55};
                crc<=16'hffff; idx<=0; active<=1;
            end
        end else if (byte_ready) begin
            if (idx<BODY_BYTES) crc<=crc_byte(crc,byte_data);
            if (idx==BODY_BYTES+1) active<=0;
            else idx<=idx+1'b1;
        end
    end
endmodule
`default_nettype wire
