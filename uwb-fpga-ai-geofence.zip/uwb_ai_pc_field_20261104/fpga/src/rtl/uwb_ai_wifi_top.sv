`timescale 1ns/1ps
`default_nettype none
module uwb_ai_wifi_top #(
    parameter integer CLK_HZ=50_000_000,UWB_BAUD=115200,PC_BAUD=115200,
    parameter integer X0=0,Y0=0,Z0=1000,X1=3000,Y1=0,Z1=1000,X2=1500,Y2=2600,Z2=1000,
    parameter integer TAG_Z=0,ENABLE_ANGLES=1,ENABLE_FENCE=1,ENABLE_BUZZER=1,TELEMETRY_STEP_MM=1,
    parameter integer CLEAR_HITS=1,CLEAR_MARGIN_MM=0,QUALITY_ENABLE=1,QUALITY_LIMIT_MM=200,
    parameter integer FAULT_ENABLE=1,FAULT_TIMEOUT_MS=1000,FAULT_STARTUP_MS=3000,EXPECTED_TAG=2,
    parameter integer RANGE_FILTER=1,FENCE_CONFIRM=3,AI_EARLY_BEEP=0,LEGACY_CUR=1,JOIN_LEN=38,TCP_LEN=42,
    parameter [2047:0] JOIN_COMMAND="AT+CWJAP_CUR=\"YOUR_WIFI\",\"YOUR_PASSWORD\"\015\012",
    parameter [1023:0] TCP_COMMAND="AT+CIPSTART=\"TCP\",\"192.168.1.100\",9000,5\015\012",
    parameter integer RESET_MS=100,BOOT_MS=2000,GUARD_MS=1100,FLUSH_MS=200,RETRY_MS=2000,
    parameter integer ACK_TIMEOUT_MS=3000,JOIN_TIMEOUT_MS=40000,TCP_TIMEOUT_MS=10000,
    parameter integer SEND_TIMEOUT_MS=10000,POLL_MS=5000,WATCHDOG_CYCLES=2*CLK_HZ
)(
    input wire sys_clk,sys_rst_n,uwb_rx,esp_rx,
    output wire esp_tx,esp_rst_n,beep
);
    (* ASYNC_REG="TRUE" *)reg[3:0]reset_pipe=0;
    always @(posedge sys_clk or negedge sys_rst_n)
        if(!sys_rst_n)reset_pipe<=0;else reset_pipe<={reset_pipe[2:0],1'b1};
    wire rst_n=reset_pipe[3];
    wire [287:0]record_data;
    wire [287:0]telemetry_data;
    wire telemetry_valid,telemetry_ready;
    telemetry_coordinate_buffer #(.STEP_MM(TELEMETRY_STEP_MM),.COORD_BITS(16)) round_wire(
        .clk(sys_clk),.rst_n(rst_n && online),.record_in(record_data),.in_valid(record_valid),.in_ready(record_ready),
        .record_out(telemetry_data),.out_valid(telemetry_valid),.out_ready(telemetry_ready));
    wire record_valid,record_ready,local_alarm,host_warning,armed,watchdog_fault,position_fault;
    (* MARK_DEBUG="TRUE" *)wire online;
    (* MARK_DEBUG="TRUE" *)wire[7:0]last_error;
    (* MARK_DEBUG="TRUE" *)wire[15:0]retry_count;
    wire reset_asserted;
    assign esp_rst_n=reset_asserted ? 1'b0 : 1'bz;
    uwb_position_core #(.CLK_HZ(CLK_HZ),.UWB_BAUD(UWB_BAUD),.X0(X0),.Y0(Y0),.Z0(Z0),
        .X1(X1),.Y1(Y1),.Z1(Z1),.X2(X2),.Y2(Y2),.Z2(Z2),.TAG_Z(TAG_Z),
        .ENABLE_ANGLES(ENABLE_ANGLES),.ENABLE_FENCE(ENABLE_FENCE),.RANGE_FILTER(RANGE_FILTER),.FENCE_CONFIRM(FENCE_CONFIRM),
        .CLEAR_HITS(CLEAR_HITS),.CLEAR_MARGIN_MM(CLEAR_MARGIN_MM),.QUALITY_ENABLE(QUALITY_ENABLE),.QUALITY_LIMIT_MM(QUALITY_LIMIT_MM),
        .FAULT_ENABLE(FAULT_ENABLE),.FAULT_TIMEOUT_MS(FAULT_TIMEOUT_MS),.FAULT_STARTUP_MS(FAULT_STARTUP_MS),.EXPECTED_TAG(EXPECTED_TAG))core(
        .clk(sys_clk),.rst_n(rst_n),.uwb_rx(uwb_rx),.stream_enable(online),.record_out(record_data),
        .record_valid(record_valid),.record_ready(record_ready),.fence_alarm(local_alarm),.position_fault(position_fault));
    wire[7:0]command_data,stream_data;
    wire command_valid,command_error,stream_valid,stream_ready;
    wire [7:0] profile_index;
    wire [31:0] profile_value;
    wire profile_valid;
    uwb_profile #(.CLK_HZ(CLK_HZ),.UWB_BAUD(UWB_BAUD),.X0(X0),.Y0(Y0),.Z0(Z0),.X1(X1),.Y1(Y1),.Z1(Z1),
        .X2(X2),.Y2(Y2),.Z2(Z2),.TAG_Z(TAG_Z),.RANGE_FILTER(RANGE_FILTER),.FENCE_CONFIRM(FENCE_CONFIRM),
        .CLEAR_HITS(CLEAR_HITS),.CLEAR_MARGIN_MM(CLEAR_MARGIN_MM),.FAULT_TIMEOUT_MS(FAULT_TIMEOUT_MS),.EXPECTED_TAG(EXPECTED_TAG),
        .QUALITY_LIMIT_MM(QUALITY_LIMIT_MM),.AI_EARLY_BEEP(AI_EARLY_BEEP),.QUALITY_ENABLE(QUALITY_ENABLE),.FAULT_ENABLE(FAULT_ENABLE))profile(
        .index(profile_index),.value(profile_value),.valid(profile_valid));
    ai_usb_link #(.CLK_HZ(CLK_HZ),.BAUD(PC_BAUD),.WATCHDOG_CYCLES(WATCHDOG_CYCLES),.EXTERNAL_BYTES(1))router(
        .clk(sys_clk),.rst_n(rst_n),.rx(1'b1),.stream_online(online),
        .command_data(command_data),.command_valid(command_valid),.command_error(command_error),
        .stream_data(stream_data),.stream_valid(stream_valid),.stream_ready(stream_ready),
        .profile_index(profile_index),.profile_value(profile_value),.profile_valid(profile_valid),
        .record_in(telemetry_data),.record_valid(telemetry_valid),.record_ready(telemetry_ready),
        .local_alarm(local_alarm),.beep_state(beep),.host_warning(host_warning),.armed(armed),.watchdog_fault(watchdog_fault));
    wire[335:0]tx_frame;
    wire[5:0]tx_frame_length;
    wire tx_frame_valid,tx_frame_ready;
    ai_frame_buffer frames(.clk(sys_clk),.rst_n(rst_n && online),.data(stream_data),.valid(stream_valid),
        .ready(stream_ready),.frame(tx_frame),.frame_length(tx_frame_length),.frame_valid(tx_frame_valid),.frame_ready(tx_frame_ready));
    esp01s_at_link #(.CLK_HZ(CLK_HZ),.BAUD(PC_BAUD),.LEGACY_CUR(LEGACY_CUR),.EXTERNAL_FRAME(1),
        .ENABLE_ANGLES(ENABLE_ANGLES),.ENABLE_FENCE(ENABLE_FENCE),.JOIN_LEN(JOIN_LEN),.JOIN_COMMAND(JOIN_COMMAND),
        .TCP_LEN(TCP_LEN),.TCP_COMMAND(TCP_COMMAND),.RESET_MS(RESET_MS),.BOOT_MS(BOOT_MS),.GUARD_MS(GUARD_MS),
        .FLUSH_MS(FLUSH_MS),.RETRY_MS(RETRY_MS),.ACK_TIMEOUT_MS(ACK_TIMEOUT_MS),.JOIN_TIMEOUT_MS(JOIN_TIMEOUT_MS),
        .TCP_TIMEOUT_MS(TCP_TIMEOUT_MS),.SEND_TIMEOUT_MS(SEND_TIMEOUT_MS),.POLL_MS(POLL_MS))wifi(
        .clk(sys_clk),.rst_n(rst_n),.esp_rx(esp_rx),.esp_tx(esp_tx),.reset_asserted(reset_asserted),
        .record_in(288'b0),.record_valid(1'b0),.tx_frame(tx_frame),.tx_frame_length(tx_frame_length),
        .tx_frame_valid(tx_frame_valid),.tx_frame_ready(tx_frame_ready),.command_data(command_data),
        .command_valid(command_valid),.command_error(command_error),.online(online),.last_error(last_error),.retry_count(retry_count));
    // Faults remain visible in telemetry/ACKs, but cannot sound the buzzer.
    wire main_alarm=local_alarm || (AI_EARLY_BEEP && host_warning && !watchdog_fault);
    geofence_buzzer #(.CLK_HZ(CLK_HZ),.ENABLE_BUZZER(ENABLE_BUZZER))buzzer(
        .clk(sys_clk),.rst_n(rst_n),.alarm(main_alarm),.beep(beep));
endmodule
`default_nettype wire
