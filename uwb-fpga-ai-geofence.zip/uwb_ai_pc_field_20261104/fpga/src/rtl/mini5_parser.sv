`timescale 1ns/1ps
`default_nettype none
// Exact Mini5 V1.1 fixed-width TOF line; all hexadecimal fields are validated.
// The single decimal digit in aT:A supports the documented short IDs 0..8.
module mini5_parser #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer GAP_MS = 20
)(
    input wire clk, rst_n,
    input wire [7:0] data,
    input wire byte_valid, framing_error,
    output reg frame_valid,
    output reg [7:0] mask, seq, tag,
    output reg [31:0] d0, d1, d2
);
    localparam integer GAP_CYCLES = (CLK_HZ/1000)*GAP_MS;
    reg [6:0] pos;
    reg bad;
    reg [31:0] gap;
    reg [7:0] mask_tmp, seq_tmp, tag_tmp;
    reg [31:0] r0, r1, r2;
    function automatic is_hex(input [7:0] c);
        is_hex = (c >= "0" && c <= "9") || (c >= "a" && c <= "f") || (c >= "A" && c <= "F");
    endfunction
    function automatic [3:0] nibble(input [7:0] c);
        if (c >= "0" && c <= "9") nibble = c-"0";
        else if (c >= "a" && c <= "f") nibble = c-"a"+10;
        else nibble = c-"A"+10;
    endfunction
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pos <= 0; bad <= 0; gap <= 0; frame_valid <= 0;
            mask_tmp <= 0; seq_tmp <= 0; tag_tmp <= 0;
            r0 <= 0; r1 <= 0; r2 <= 0;
            mask <= 0; seq <= 0; tag <= 0; d0 <= 0; d1 <= 0; d2 <= 0;
        end else begin
            frame_valid <= 0;
            if (framing_error) begin bad <= 1; gap <= 0; end
            else if (byte_valid) begin
                gap <= 0;
                if (data == 8'h0d || data == 8'h0a) begin
                    if (pos == 63 && !bad) begin
                        frame_valid <= 1; mask <= mask_tmp; seq <= seq_tmp; tag <= tag_tmp;
                        d0 <= r0; d1 <= r1; d2 <= r2;
                    end
                    pos <= 0; bad <= 0;
                end else begin
                    if (pos < 64) pos <= pos+1;
                    else bad <= 1;
                    case (pos)
                        0: if (data != "m") bad <= 1;
                        1: if (data != "c") bad <= 1;
                        2,5,14,23,32,41,46,49,58: if (data != " ") bad <= 1;
                        3,4: begin
                            if (!is_hex(data)) bad <= 1;
                            mask_tmp <= {mask_tmp[3:0], nibble(data)};
                        end
                        6,7,8,9,10,11,12,13: begin
                            if (!is_hex(data)) bad <= 1;
                            r0 <= {r0[27:0], nibble(data)};
                        end
                        15,16,17,18,19,20,21,22: begin
                            if (!is_hex(data)) bad <= 1;
                            r1 <= {r1[27:0], nibble(data)};
                        end
                        24,25,26,27,28,29,30,31: begin
                            if (!is_hex(data)) bad <= 1;
                            r2 <= {r2[27:0], nibble(data)};
                        end
                        33,34,35,36,37,38,39,40,42,43,44,45,50,51,52,53,54,55,56,57:
                            if (!is_hex(data)) bad <= 1;
                        47,48: begin
                            if (!is_hex(data)) bad <= 1;
                            seq_tmp <= {seq_tmp[3:0], nibble(data)};
                        end
                        59: if (data != "a" && data != "t") bad <= 1;
                        60: begin
                            if (data < "0" || data > "8") bad <= 1;
                            tag_tmp <= data-"0";
                        end
                        61: if (data != ":") bad <= 1;
                        62: if (data < "0" || data > "3") bad <= 1;
                        default: bad <= 1;
                    endcase
                end
            end else if (pos != 0 || bad) begin
                if (gap >= GAP_CYCLES-1) begin pos <= 0; bad <= 0; gap <= 0; end
                else gap <= gap+1;
            end
        end
    end
endmodule
`default_nettype wire
