`timescale 1ns/1ps
`default_nettype none
// Keep each tag's last known outside state. Invalid data cannot clear an alarm.
module geofence_alarm #(parameter integer CONFIRM_HITS=1,GAP_CYCLES=50_000_000,CLEAR_HITS=1)(
    input wire clk,rst_n,record_valid,
    input wire [287:0] record_in,
    output wire alarm,
    output reg [8:0] alarm_tags,
    output reg record_alarm,
    output reg [1:0] record_hits,
    input wire clear_ok
);
    wire [7:0] tag=record_in[31:24];
    reg [1:0] hits[0:8];
    reg [1:0] clear_hits[0:8];
    reg [1:0] next_clear;
    reg [7:0] last_seq[0:8];
    reg [8:0] seen;
    localparam integer AGE_W=(GAP_CYCLES<2)?1:$clog2(GAP_CYCLES+1);
    reg [AGE_W-1:0] age[0:8];
    wire position_ok=record_in[232] && record_in[6:0]==0 && record_in[10:8]==7;
    reg duplicate,continuous;
    reg [7:0] seq_step;
    assign alarm=|alarm_tags;
    // Predict AFTER this record, so the third frame itself reports alarm.
    always @* begin
        record_alarm=0;record_hits=0;duplicate=0;continuous=0;next_clear=0;seq_step=0;
        if(tag<=8)begin
            record_alarm=alarm_tags[tag];
            if((CONFIRM_HITS==1 && CLEAR_HITS==1) || age[tag]<GAP_CYCLES)begin
                record_hits=hits[tag];next_clear=clear_hits[tag];
            end
            seq_step=record_in[23:16]-last_seq[tag];
            duplicate=((CONFIRM_HITS>1 || CLEAR_HITS>1) && seen[tag] &&
                       (seq_step==0 || (age[tag]<GAP_CYCLES && seq_step[7])));
            continuous=(seen[tag] && age[tag]<GAP_CYCLES && !duplicate);
            if(!position_ok)begin record_hits=0;next_clear=0;end
            else if(!duplicate)begin
                if(!record_in[233])begin
                    record_hits=0;
                    if(CLEAR_HITS==1)begin record_alarm=0;next_clear=0;end
                    else if(!record_alarm || !clear_ok)next_clear=0;
                    else begin
                        next_clear=(continuous && next_clear!=0)?next_clear+1'b1:1;
                        if(next_clear>=CLEAR_HITS)begin record_alarm=0;next_clear=0;end
                    end
                end
                else begin
                    next_clear=0;
                    if(CONFIRM_HITS==1)record_hits=1;
                    else if(continuous && record_hits!=0)begin
                        if(record_hits<CONFIRM_HITS)record_hits=record_hits+1'b1;
                    end else record_hits=1;
                    if(record_hits>=CONFIRM_HITS)record_alarm=1;
                end
            end
        end
    end
    integer i;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n)begin
            alarm_tags<=0;seen<=0;
            for(i=0;i<9;i=i+1)begin hits[i]<=0;clear_hits[i]<=0;last_seq[i]<=0;age[i]<=GAP_CYCLES;end
        end else begin
            for(i=0;i<9;i=i+1)if(age[i]<GAP_CYCLES)age[i]<=age[i]+1'b1;
            if(record_valid && tag<=8)begin
                hits[tag]<=record_hits;clear_hits[tag]<=next_clear;alarm_tags[tag]<=record_alarm;
                if(!duplicate)begin
                    seen[tag]<=1;last_seq[tag]<=record_in[23:16];age[tag]<=0;
                end
            end
        end
    end
endmodule

// The Navigator baseboard uses an active, high-level-driven buzzer (M14).
module geofence_buzzer #(
    parameter integer CLK_HZ=50_000_000, ENABLE_BUZZER=1
)(
    input wire clk,rst_n,alarm,
    output wire beep
);
    localparam integer HALF_SECOND=(CLK_HZ/2 < 1) ? 1 : CLK_HZ/2;
    reg [31:0] timer;
    reg quiet;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin timer<=0; quiet<=0; end
        else if(!alarm) begin timer<=0; quiet<=0; end
        else if(timer==HALF_SECOND-1) begin timer<=0; quiet<=!quiet; end
        else timer<=timer+1'b1;
    end
    assign beep=ENABLE_BUZZER && rst_n && alarm && !quiet;
endmodule
`default_nettype wire
