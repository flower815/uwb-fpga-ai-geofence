`timescale 1ns/1ps
`default_nettype none
// Restoring divider. start is accepted only while !busy. Truncates toward zero.
// The caller excludes signed overflow (INT64_MIN / -1).
module signed_div64(
    input wire clk, rst_n, start,
    input wire signed [63:0] numerator, denominator,
    output reg busy, done, divide_by_zero,
    output reg signed [63:0] quotient
);
    reg [63:0] q, divisor;
    reg [64:0] remainder;
    reg negative;
    reg [5:0] count;
    wire [64:0] trial = {remainder[63:0], q[63]};
    wire take = trial >= {1'b0, divisor};
    wire [64:0] next_r = take ? trial-{1'b0, divisor} : trial;
    wire [63:0] next_q = {q[62:0], take};
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy <= 0; done <= 0; divide_by_zero <= 0; quotient <= 0;
            q <= 0; divisor <= 0; remainder <= 0; negative <= 0; count <= 0;
        end else begin
            done <= 0;
            if (start && !busy) begin
                divide_by_zero <= denominator == 0;
                if (denominator == 0) begin quotient <= 0; done <= 1; end
                else begin
                    q <= numerator[63] ? -numerator : numerator;
                    divisor <= denominator[63] ? -denominator : denominator;
                    negative <= numerator[63] ^ denominator[63];
                    remainder <= 0; count <= 0; busy <= 1;
                end
            end else if (busy) begin
                q <= next_q; remainder <= next_r;
                if (count == 63) begin
                    quotient <= negative ? -$signed(next_q) : $signed(next_q);
                    busy <= 0; done <= 1;
                end else count <= count+1;
            end
        end
    end
endmodule
`default_nettype wire
