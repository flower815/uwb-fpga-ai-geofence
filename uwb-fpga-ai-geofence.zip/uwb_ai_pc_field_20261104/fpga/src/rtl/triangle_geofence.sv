`timescale 1ns/1ps
`default_nettype none
// XY triangle, closed boundary. Two-stage signed-64-bit cross products.
// V3 flag byte: 00 unknown, 01 inside/on edge, 03 outside.
module triangle_geofence #(
    parameter integer X0=0,Y0=0,X1=3000,Y1=0,X2=1500,Y2=2600
)(
    input wire clk,rst_n,in_valid,
    input wire [287:0] record_in,
    output reg out_valid,
    output reg [287:0] record_out
);
    localparam signed [63:0] AX0=X0,AY0=Y0,AX1=X1,AY1=Y1,AX2=X2,AY2=Y2;
    localparam signed [63:0] AREA=(AX1-AX0)*(AY2-AY0)-(AY1-AY0)*(AX2-AX0);
    wire signed [63:0] px={{32{record_in[159]}},record_in[159:128]};
    wire signed [63:0] py={{32{record_in[191]}},record_in[191:160]};
    reg signed [63:0] c0,c1,c2;
    reg pending,position_ok;
    reg [287:0] saved;
    wire in_triangle=((c0>=0 && c1>=0 && c2>=0) || (c0<=0 && c1<=0 && c2<=0));
    wire [7:0] flags=(position_ok && AREA!=0) ? (in_triangle ? 8'h01 : 8'h03) : 8'h00;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            c0<=0; c1<=0; c2<=0; pending<=0; position_ok<=0;
            saved<=0; out_valid<=0; record_out<=0;
        end else begin
            pending<=in_valid;
            out_valid<=pending;
            if(in_valid) begin
                c0<=(AX1-AX0)*(py-AY0)-(AY1-AY0)*(px-AX0);
                c1<=(AX2-AX1)*(py-AY1)-(AY2-AY1)*(px-AX1);
                c2<=(AX0-AX2)*(py-AY2)-(AY0-AY2)*(px-AX2);
                position_ok<=(record_in[6:0]==0 && record_in[10:8]==3'b111);
                saved<=record_in;
            end
            if(pending) record_out<={saved[287:240],flags,saved[231:0]};
        end
    end
endmodule
`default_nettype wire
