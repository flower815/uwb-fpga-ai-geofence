`timescale 1ns/1ps
`default_nettype none
// ESP8266 AT, single TCP client, normal (length-delimited) send mode.
// Command echo/replies never enter the PC's V1/V2 positioning stream.
module esp01s_at_link #(
    parameter integer CLK_HZ=50_000_000, BAUD=115200, ENABLE_ANGLES=0, ENABLE_FENCE=0, EXTERNAL_FRAME=0,
    parameter integer RECORD_WIDTH=(ENABLE_ANGLES || ENABLE_FENCE) ? 288 : 224,
    parameter integer LEGACY_CUR=0,
    parameter integer JOIN_LEN=38,
    parameter [2047:0] JOIN_COMMAND="AT+CWJAP=\"YOUR_WIFI\",\"YOUR_PASSWORD\"\015\012",
    parameter integer TCP_LEN=42,
    parameter [1023:0] TCP_COMMAND="AT+CIPSTART=\"TCP\",\"192.168.1.100\",9000,5\015\012",
    parameter integer RESET_MS=100, BOOT_MS=2000, GUARD_MS=1100,
    parameter integer FLUSH_MS=200, RETRY_MS=2000,
    parameter integer ACK_TIMEOUT_MS=3000, JOIN_TIMEOUT_MS=40000,
    parameter integer TCP_TIMEOUT_MS=10000, SEND_TIMEOUT_MS=10000,
    parameter integer POLL_MS=5000
)(
    input wire clk,rst_n,esp_rx,
    output wire esp_tx, reset_asserted,
    input wire [RECORD_WIDTH-1:0] record_in,
    input wire record_valid,
    output wire record_ready,
    input wire [335:0] tx_frame,
    input wire [5:0] tx_frame_length,
    input wire tx_frame_valid,
    output wire tx_frame_ready,
    output wire [7:0] command_data,
    output wire command_valid,command_error,
    output reg online,
    output reg [7:0] last_error,
    output reg [15:0] retry_count,
    output wire [3:0] state_debug,
    output wire [3:0] command_debug
);
    localparam [3:0] RESET=0,BOOT=1,ESC_PRE=2,ESC_TX=3,ESC_POST=4,
        FLUSH_TX=5,FLUSH_WAIT=6,COMMAND=7,WAIT_REPLY=8,IDLE=9,
        PAYLOAD=10,SEND_REPLY=11,BACKOFF=12;
    localparam [3:0] C_AT=0,C_ECHO=1,C_GMR=2,C_STORE=3,C_CLOSE=4,
        C_MODE=5,C_MUX=6,C_SLEEP=7,C_WIFI_MODE=8,C_JOIN=9,C_TCP=10,
        C_SEND=11,C_STATUS=12,C_DHCP=13,C_IPDINFO=14;
    reg [3:0] state,command;
    reg [8:0] command_pos;
    reg [5:0] payload_pos;
    localparam integer BODY_BYTES=(ENABLE_ANGLES || ENABLE_FENCE) ? 40 : 32;
    localparam [7:0] VERSION=ENABLE_FENCE ? 8'h03 : ENABLE_ANGLES ? 8'h02 : 8'h01;
    reg [BODY_BYTES*8-1:0] payload;
    reg [335:0] network_payload;
    reg [5:0] network_length;
    reg [15:0] crc;
    reg [31:0] ms_div,timer;
    reg seen_ok,seen_connect,seen_status3;
    localparam integer MS_DIV=(CLK_HZ/1000 < 1) ? 1 : CLK_HZ/1000;
    wire ms_tick=(ms_div==MS_DIV-1);
    assign state_debug=state;
    assign command_debug=command;
    assign record_ready=(state==IDLE && online && !EXTERNAL_FRAME);
    assign tx_frame_ready=(state==IDLE && online && EXTERNAL_FRAME);
    assign reset_asserted=!rst_n || state==RESET;

    function automatic integer command_length(input [3:0] c);
        begin
            case(c)
                C_AT: command_length=4;
                C_ECHO: command_length=6;
                C_GMR: command_length=8;
                C_STORE: command_length=LEGACY_CUR ? 4 : 15;
                C_CLOSE: command_length=13;
                C_MODE: command_length=14;
                C_MUX: command_length=13;
                C_SLEEP: command_length=12;
                C_WIFI_MODE: command_length=LEGACY_CUR ? 17 : 13;
                C_JOIN: command_length=JOIN_LEN;
                C_TCP: command_length=TCP_LEN;
                C_SEND: command_length=15;
                C_STATUS: command_length=14;
                C_DHCP: command_length=LEGACY_CUR ? 19 : 15;
                C_IPDINFO: command_length=15;
                default: command_length=4;
            endcase
        end
    endfunction
    function automatic [7:0] command_byte(input [3:0] c,input integer p);
        reg [2047:0] s;
        integer n;
        begin
            case(c)
                C_AT: s="AT\015\012";
                C_ECHO: s="ATE0\015\012";
                C_GMR: s="AT+GMR\015\012";
                C_STORE: s=LEGACY_CUR ? "AT\015\012" : "AT+SYSSTORE=0\015\012";
                C_CLOSE: s="AT+CIPCLOSE\015\012";
                C_MODE: s="AT+CIPMODE=0\015\012";
                C_MUX: s="AT+CIPMUX=0\015\012";
                C_SLEEP: s="AT+SLEEP=0\015\012";
                C_WIFI_MODE: s=LEGACY_CUR ? "AT+CWMODE_CUR=1\015\012" : "AT+CWMODE=1\015\012";
                C_JOIN: s=JOIN_COMMAND;
                C_TCP: s=TCP_COMMAND;
                C_SEND: if(EXTERNAL_FRAME && network_length==18)s="AT+CIPSEND=18\015\012";
                        else s=(ENABLE_ANGLES || ENABLE_FENCE) ? "AT+CIPSEND=42\015\012" : "AT+CIPSEND=34\015\012";
                C_STATUS: s="AT+CIPSTATUS\015\012";
                C_DHCP: s=LEGACY_CUR ? "AT+CWDHCP_CUR=1,1\015\012" : "AT+CWDHCP=1,1\015\012";
                C_IPDINFO: s="AT+CIPDINFO=0\015\012";
                default: s="AT\015\012";
            endcase
            n=command_length(c);
            command_byte=(p<n) ? s[(n-1-p)*8 +: 8] : 8'h00;
        end
    endfunction
    function automatic [15:0] crc_byte(input [15:0] prev,input [7:0] b);
        reg [15:0] c; integer k;
        begin
            c=prev^{b,8'h00};
            for(k=0;k<8;k=k+1) c=c[15] ? (c<<1)^16'h1021 : c<<1;
            crc_byte=c;
        end
    endfunction
    wire [7:0] payload_byte=EXTERNAL_FRAME ? network_payload[payload_pos*8+:8] : payload_pos<BODY_BYTES ? payload[payload_pos*8 +: 8] :
        (payload_pos==BODY_BYTES ? crc[7:0] : crc[15:8]);
    wire uart_valid=(state==COMMAND || state==ESC_TX || state==FLUSH_TX || state==PAYLOAD);
    wire [7:0] uart_data=state==COMMAND ? command_byte(command,command_pos) :
        state==ESC_TX ? 8'h2b : state==FLUSH_TX ? (command_pos==0 ? 8'h0d : 8'h0a) : payload_byte;
    wire uart_ready;
    uart_tx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) tx_uart(
        .clk(clk),.rst_n(rst_n),.data(uart_data),.valid(uart_valid),.ready(uart_ready),.tx(esp_tx));
    wire [7:0] rx_data,raw_rx_data;
    wire rx_valid,rx_error,raw_rx_valid,raw_rx_error,text_clear;
    uart_rx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) rx_uart(
        .clk(clk),.rst_n(rst_n),.rx(esp_rx),.data(raw_rx_data),.valid(raw_rx_valid),.framing_error(raw_rx_error));
    generate if(EXTERNAL_FRAME)begin : duplex_rx
        esp_ipd_demux #(.CLK_HZ(CLK_HZ)) demux(.clk(clk),.rst_n(rst_n && state!=RESET),
            .in_data(raw_rx_data),.in_valid(raw_rx_valid),.in_error(raw_rx_error),
            .text_data(rx_data),.text_valid(rx_valid),.text_clear(text_clear),
            .app_data(command_data),.app_valid(command_valid),.error(rx_error));
        assign command_error=rx_error || raw_rx_error;
    end else begin : telemetry_rx
        assign rx_data=raw_rx_data;assign rx_valid=raw_rx_valid;assign rx_error=raw_rx_error;assign text_clear=1'b0;
        assign command_data=0;assign command_valid=0;assign command_error=raw_rx_error;
    end endgenerate

    // Exact reply lines, bounded storage, no substring matching (e.g. NOT OK).
    reg [767:0] line;
    reg [6:0] line_len;
    reg line_overflow;
    reg ev_ok,ev_error,ev_prompt,ev_connect,ev_closed,ev_disconnect,ev_ready,ev_send_ok,ev_status3;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            line<=0; line_len<=0; line_overflow<=0;
            ev_ok<=0; ev_error<=0; ev_prompt<=0; ev_connect<=0;
            ev_closed<=0; ev_disconnect<=0; ev_ready<=0; ev_send_ok<=0; ev_status3<=0;
        end else begin
            ev_ok<=0; ev_error<=0; ev_prompt<=0; ev_connect<=0;
            ev_closed<=0; ev_disconnect<=0; ev_ready<=0; ev_send_ok<=0; ev_status3<=0;
            if(rx_error || text_clear || state==RESET) begin line<=0; line_len<=0; line_overflow<=0; end
            else if(rx_valid) begin
                if(rx_data==">" && command==C_SEND && state==WAIT_REPLY) begin
                    ev_prompt<=1; line<=0; line_len<=0; line_overflow<=0;
                end else if(rx_data==8'h0a) begin
                    if(!line_overflow) begin
                        ev_ok<=(line=="OK");
                        ev_error<=(line=="ERROR" || line=="FAIL" || line=="SEND FAIL" ||
                            line=="busy p..." || line=="busy s..." || line=="ALREADY CONNECTED" || line=="ALREADY CONNECT");
                        ev_connect<=(line=="CONNECT");
                        ev_closed<=(line=="CLOSED");
                        ev_disconnect<=(line=="WIFI DISCONNECT");
                        ev_ready<=(line=="ready");
                        ev_send_ok<=(line=="SEND OK");
                        ev_status3<=(line=="STATUS:3");
                    end
                    line<=0; line_len<=0; line_overflow<=0;
                end else if(rx_data!=8'h0d && !(line_len==0 && rx_data==" ")) begin
                    if(line_len<96) begin line<={line[759:0],rx_data}; line_len<=line_len+1'b1; end
                    else line_overflow<=1;
                end
            end
        end
    end

    task automatic start_command(input [3:0] c);
        begin command<=c; command_pos<=0; seen_ok<=0; seen_connect<=0;
            seen_status3<=0; timer<=0; state<=COMMAND; end
    endtask
    task automatic fail_link(input [7:0] code);
        begin online<=0; last_error<=code; retry_count<=retry_count+1'b1;
            timer<=0; state<=BACKOFF; end
    endtask
    wire wait_expired=timer >= (command==C_JOIN ? JOIN_TIMEOUT_MS :
        command==C_TCP ? TCP_TIMEOUT_MS : ACK_TIMEOUT_MS);
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            ms_div<=0; timer<=0; state<=RESET; command<=C_AT; command_pos<=0;
            payload_pos<=0; payload<=0; crc<=16'hffff; online<=0;
            network_payload<=0;network_length<=0;
            last_error<=0; retry_count<=0; seen_ok<=0; seen_connect<=0; seen_status3<=0;
        end else begin
            if(ms_tick) begin ms_div<=0; timer<=timer+1'b1; end
            else ms_div<=ms_div+1'b1;
            if(online && (ev_closed || ev_disconnect || ev_ready || rx_error)) begin
                fail_link(rx_error ? 8'he4 : ev_ready ? 8'he3 : ev_disconnect ? 8'he2 : 8'he1);
            end else case(state)
                RESET: if(timer>=RESET_MS) begin state<=BOOT; timer<=0; end
                BOOT: if(timer>=BOOT_MS) begin state<=ESC_PRE; timer<=0; end
                ESC_PRE: if(timer>=GUARD_MS) begin state<=ESC_TX; command_pos<=0; timer<=0; end
                ESC_TX: if(uart_ready) begin
                    if(command_pos==2) begin state<=ESC_POST; timer<=0; end
                    else command_pos<=command_pos+1'b1;
                end
                // Include the last character's stop bit before the full quiet guard.
                ESC_POST: if(uart_ready && timer>=GUARD_MS+2) begin state<=FLUSH_TX; command_pos<=0; timer<=0; end
                FLUSH_TX: if(uart_ready) begin
                    if(command_pos==1) begin state<=FLUSH_WAIT; timer<=0; end
                    else command_pos<=command_pos+1'b1;
                end
                FLUSH_WAIT: if(uart_ready && timer>=FLUSH_MS) start_command(C_AT);
                COMMAND: if(uart_ready) begin
                    if(command_pos==command_length(command)-1) begin state<=WAIT_REPLY; timer<=0; end
                    else command_pos<=command_pos+1'b1;
                end
                WAIT_REPLY: begin
                    if(ev_ok) seen_ok<=1;
                    if(ev_connect) seen_connect<=1;
                    if(ev_status3) seen_status3<=1;
                    if(ev_error && command!=C_CLOSE) fail_link(8'h20+{4'b0,command});
                    else if(command==C_SEND) begin
                        if(ev_prompt) begin state<=PAYLOAD; payload_pos<=0; timer<=0; end
                        else if(wait_expired) fail_link(8'h40+{4'b0,command});
                    end else if(command==C_TCP) begin
                        if((ev_ok || seen_ok) && (ev_connect || seen_connect)) begin
                            online<=1; last_error<=0; state<=IDLE; timer<=0;
                        end else if(wait_expired) fail_link(8'h40+{4'b0,command});
                    end else if(command==C_STATUS) begin
                        if(ev_ok) begin
                            if(seen_status3 || ev_status3) begin state<=IDLE; timer<=0; end
                            else fail_link(8'he5);
                        end else if(wait_expired) fail_link(8'h40+{4'b0,command});
                    end else if(ev_ok || (command==C_CLOSE && ev_error)) begin
                        if(command==C_MUX && EXTERNAL_FRAME)start_command(C_IPDINFO);
                        else if(command==C_IPDINFO)start_command(C_SLEEP);
                        else if(command==C_WIFI_MODE) start_command(C_DHCP);
                        else if(command==C_DHCP) start_command(C_JOIN);
                        else start_command(command+1'b1);
                    end else if(wait_expired) fail_link(8'h40+{4'b0,command});
                end
                IDLE: begin
                    if(EXTERNAL_FRAME && tx_frame_valid)begin
                        if(tx_frame_length==18 || tx_frame_length==42)begin
                            network_payload<=tx_frame;network_length<=tx_frame_length;start_command(C_SEND);
                        end else fail_link(8'he8);
                    end else if(!EXTERNAL_FRAME && record_valid) begin
                        payload<={record_in[RECORD_WIDTH-1:32],8'h00,record_in[31:0],VERSION,16'haa55};
                        crc<=16'hffff; start_command(C_SEND);
                    end else if(POLL_MS>0 && timer>=POLL_MS) start_command(C_STATUS);
                end
                PAYLOAD: if(uart_ready) begin
                    if(!EXTERNAL_FRAME && payload_pos<BODY_BYTES) crc<=crc_byte(crc,payload_byte);
                    if((EXTERNAL_FRAME && payload_pos==network_length-1) || (!EXTERNAL_FRAME && payload_pos==BODY_BYTES+1)) begin state<=SEND_REPLY; timer<=0; end
                    else payload_pos<=payload_pos+1'b1;
                end
                SEND_REPLY: begin
                    if(ev_send_ok) begin state<=IDLE; timer<=0; end
                    else if(ev_error) fail_link(8'he6);
                    else if(timer>=SEND_TIMEOUT_MS) fail_link(8'he7);
                end
                BACKOFF: if(uart_ready && timer>=RETRY_MS) begin state<=RESET; timer<=0; end
                default: fail_link(8'hef);
            endcase
        end
    end
endmodule
`default_nettype wire
