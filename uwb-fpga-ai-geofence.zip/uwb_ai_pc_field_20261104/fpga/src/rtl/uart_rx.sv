`timescale 1ns/1ps
`default_nettype none
module uart_rx #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD = 115200
)(
    input wire clk, rst_n, rx,
    output reg [7:0] data,
    output reg valid, framing_error
);
    localparam integer DIV = (CLK_HZ + BAUD/2)/BAUD;
    (* ASYNC_REG = "TRUE" *) reg rx_meta, rx_sync;
    reg [2:0] state;
    reg [2:0] bit_idx;
    reg [31:0] timer;
    reg [7:0] shift;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin rx_meta <= 1; rx_sync <= 1; end
        else begin rx_meta <= rx; rx_sync <= rx_meta; end
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= 0; timer <= 0; bit_idx <= 0; shift <= 0;
            data <= 0; valid <= 0; framing_error <= 0;
        end else begin
            valid <= 0; framing_error <= 0;
            case (state)
                0: if (!rx_sync) begin timer <= (DIV-1)/2; state <= 1; end
                1: if (timer != 0) timer <= timer-1;
                   else if (!rx_sync) begin timer <= DIV-1; bit_idx <= 0; state <= 2; end
                   else state <= 0;
                2: if (timer != 0) timer <= timer-1;
                   else begin
                       shift[bit_idx] <= rx_sync; timer <= DIV-1;
                       if (bit_idx == 7) state <= 3;
                       else bit_idx <= bit_idx+1;
                   end
                3: if (timer != 0) timer <= timer-1;
                   else if (rx_sync) begin data <= shift; valid <= 1; state <= 0; end
                   else begin framing_error <= 1; state <= 4; end
                4: if (rx_sync) state <= 0;
                default: state <= 0;
            endcase
        end
    end
endmodule
`default_nettype wire
