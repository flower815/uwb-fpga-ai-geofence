`timescale 1ns/1ps
`default_nettype none
module uart_tx #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD = 115200
)(
    input wire clk, rst_n,
    input wire [7:0] data,
    input wire valid,
    output wire ready,
    output wire tx
);
    localparam integer DIV = (CLK_HZ + BAUD/2)/BAUD;
    reg busy;
    reg [9:0] shift;
    reg [3:0] bit_idx;
    reg [31:0] timer;
    assign ready = !busy;
    assign tx = busy ? shift[0] : 1'b1;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin busy <= 0; shift <= 10'h3ff; bit_idx <= 0; timer <= 0; end
        else if (!busy) begin
            if (valid) begin
                shift <= {1'b1, data, 1'b0}; busy <= 1; bit_idx <= 0; timer <= DIV-1;
            end
        end else if (timer != 0) timer <= timer-1;
        else if (bit_idx == 9) busy <= 0;
        else begin shift <= {1'b1, shift[9:1]}; bit_idx <= bit_idx+1; timer <= DIV-1; end
    end
endmodule
`default_nettype wire
