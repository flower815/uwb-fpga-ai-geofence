`timescale 1ns/1ps
`default_nettype none
// Full-quadrant atan2(y,x), degrees*100, rounded to nearest centidegree.
// The zero vector completes with direction_valid=0. No vendor IP is needed.
module cordic_atan2(
    input wire clk,rst_n,start,
    input wire signed [31:0] x_in,y_in,
    output reg busy,valid,direction_valid,
    output reg signed [31:0] angle_cdeg
);
    reg signed [63:0] x,y;
    reg signed [31:0] z;
    reg [4:0] iteration;
    wire signed [63:0] wx={{32{x_in[31]}},x_in};
    wire signed [63:0] wy={{32{y_in[31]}},y_in};
    function automatic signed [31:0] atan_lut(input [4:0] i);
        begin
            case(i)
                5'd0: atan_lut=32'sd294912000;
                5'd1: atan_lut=32'sd174096719;
                5'd2: atan_lut=32'sd91987925;
                5'd3: atan_lut=32'sd46694507;
                5'd4: atan_lut=32'sd23437865;
                5'd5: atan_lut=32'sd11730358;
                5'd6: atan_lut=32'sd5866610;
                5'd7: atan_lut=32'sd2933484;
                5'd8: atan_lut=32'sd1466764;
                5'd9: atan_lut=32'sd733385;
                5'd10: atan_lut=32'sd366693;
                5'd11: atan_lut=32'sd183346;
                5'd12: atan_lut=32'sd91673;
                5'd13: atan_lut=32'sd45837;
                5'd14: atan_lut=32'sd22918;
                5'd15: atan_lut=32'sd11459;
                5'd16: atan_lut=32'sd5730;
                5'd17: atan_lut=32'sd2865;
                5'd18: atan_lut=32'sd1432;
                5'd19: atan_lut=32'sd716;
                5'd20: atan_lut=32'sd358;
                5'd21: atan_lut=32'sd179;
                5'd22: atan_lut=32'sd90;
                5'd23: atan_lut=32'sd45;
                default: atan_lut=0;
            endcase
        end
    endfunction
    function automatic signed [31:0] rounded(input signed [31:0] phase);
        begin
            rounded=phase<0 ? -(((-phase)+32'sd32768)>>>16) : ((phase+32'sd32768)>>>16);
        end
    endfunction
    wire signed [31:0] dz=atan_lut(iteration);
    wire signed [63:0] next_x=y>0 ? x+(y>>>iteration) : y<0 ? x-(y>>>iteration) : x;
    wire signed [63:0] next_y=y>0 ? y-(x>>>iteration) : y<0 ? y+(x>>>iteration) : y;
    wire signed [31:0] next_z=y>0 ? z+dz : y<0 ? z-dz : z;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            x<=0; y<=0; z<=0; iteration<=0; busy<=0;
            valid<=0; direction_valid<=0; angle_cdeg<=0;
        end else begin
            valid<=0;
            if(!busy) begin
                if(start) begin
                    direction_valid<=(x_in!=0 || y_in!=0);
                    if(x_in==0 || y_in==0) begin
                        angle_cdeg<=x_in==0 ? (y_in>0 ? 32'sd9000 : y_in<0 ? -32'sd9000 : 0) :
                            (x_in<0 ? 32'sd18000 : 0);
                        valid<=1;
                    end else begin
                        // Q24 coordinates prevent small integer vectors losing precision.
                        x<=x_in<0 ? -(wx<<<24) : (wx<<<24);
                        y<=x_in<0 ? -(wy<<<24) : (wy<<<24);
                        z<=x_in<0 ? (y_in<0 ? -32'sd1179648000 : 32'sd1179648000) : 0;
                        iteration<=0; busy<=1;
                    end
                end
            end else begin
                x<=next_x; y<=next_y; z<=next_z;
                if(iteration==23) begin
                    angle_cdeg<=rounded(next_z); busy<=0; valid<=1;
                end else iteration<=iteration+1'b1;
            end
        end
    end
endmodule
`default_nettype wire
