`timescale 1ns/1ps
`default_nettype none
// One atomic network frame. Reset/flush on network loss, not the alarm latch.
module ai_frame_buffer(
    input wire clk,rst_n,
    input wire [7:0] data,
    input wire valid,
    output wire ready,
    output reg [335:0] frame,
    output reg [5:0] frame_length,
    output reg frame_valid,
    input wire frame_ready
);
    reg [5:0] count,target;
    assign ready=!frame_valid;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin frame<=0;frame_length<=0;frame_valid<=0;count<=0;target<=0;end
        else begin
            if(frame_valid && frame_ready)frame_valid<=0;
            if(valid && ready)begin
                if(count==0 && data!=8'h55)begin count<=0;target<=0;end
                else if(count==1 && data!=8'haa)begin count<=0;target<=0;end
                else if(count==2 && data!=3 && data!=8'h11)begin count<=0;target<=0;end
                else begin
                    frame[count*8+:8]<=data;
                    if(count==2)target<=data==3 ? 42 : 18;
                    if(target!=0 && count==target-1)begin
                        frame_length<=target;frame_valid<=1;count<=0;target<=0;
                    end else count<=count+1'b1;
                end
            end
        end
    end
endmodule
`default_nettype wire
