`timescale 1ns/1ps
`default_nettype none
// Wire units stay mm. Only XYZ are quantized; core/fence/quality see raw mm.
module telemetry_coordinate_round #(parameter integer STEP_MM=100,COORD_BITS=32)(
    input wire [287:0] record_in,
    output wire [287:0] record_out
);
    function automatic signed [31:0] rounded(input signed [31:0] value);
        reg [COORD_BITS-1:0] magnitude,biased,quotient,scaled;
        reg [31:0] result;
        begin
            // Unsigned magnitude represents abs(INT32_MIN) without overflow.
            // AI cores guarantee |XYZ|<=30000mm, so their transmit path uses
            // COORD_BITS=16. General/independent tests retain all int32 bits.
            magnitude=value[31] ? (~$unsigned(value)+32'd1) : $unsigned(value);
            biased=magnitude+COORD_BITS'(STEP_MM/2);
            quotient=biased/COORD_BITS'(STEP_MM);
            scaled=quotient*COORD_BITS'(STEP_MM);
            result=scaled;
            rounded=value[31] ? (~result+32'd1) : result;
        end
    endfunction
    generate if(STEP_MM==1)begin
        assign record_out=record_in;
    end else begin
        assign record_out={record_in[287:224],rounded($signed(record_in[223:192])),
            rounded($signed(record_in[191:160])),rounded($signed(record_in[159:128])),record_in[127:0]};
    end endgenerate
endmodule

// One elastic register separates FIFO read mux timing from coordinate math.
module telemetry_coordinate_buffer #(parameter integer STEP_MM=100,COORD_BITS=16)(
    input wire clk,rst_n,
    input wire [287:0] record_in,
    input wire in_valid,
    output wire in_ready,
    output wire [287:0] record_out,
    output wire out_valid,
    input wire out_ready
);
    reg [287:0] saved;
    reg full;
    assign in_ready=!full || out_ready;
    assign out_valid=full;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin saved<=0;full<=0;end
        else if(in_ready)begin
            full<=in_valid;
            if(in_valid)saved<=record_in;
        end
    end
    telemetry_coordinate_round #(.STEP_MM(STEP_MM),.COORD_BITS(COORD_BITS)) quantize(
        .record_in(saved),.record_out(record_out));
endmodule
`default_nettype wire
