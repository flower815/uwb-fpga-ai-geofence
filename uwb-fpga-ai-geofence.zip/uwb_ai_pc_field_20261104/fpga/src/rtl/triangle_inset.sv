`timescale 1ns/1ps
`default_nettype none
// Constant geometry: inset thresholds are elaboration-time ceil(margin*edge length).
module triangle_inset #(
    parameter integer X0=0,Y0=0,X1=3000,Y1=0,X2=1500,Y2=2600,MARGIN_MM=150
)(
    input wire [223:0] record_in,
    output wire deep_inside
);
    localparam signed [63:0] AX0=X0,AY0=Y0,AX1=X1,AY1=Y1,AX2=X2,AY2=Y2;
    localparam signed [63:0] AREA=(AX1-AX0)*(AY2-AY0)-(AY1-AY0)*(AX2-AX0);
    function automatic [63:0] root_floor(input [63:0] n);
        reg [63:0] remainder,result,bit_value;
        begin
            remainder=n;result=0;bit_value=64'h4000000000000000;
            for(integer i=0;i<32;i=i+1)begin
                if(remainder>=result+bit_value)begin
                    remainder=remainder-result-bit_value;result=(result>>1)+bit_value;
                end else result=result>>1;
                bit_value=bit_value>>2;
            end
            root_floor=result;
        end
    endfunction
    function automatic [63:0] root_ceil(input [63:0] n);
        reg [63:0] r;
        begin r=root_floor(n);root_ceil=(r*r==n)?r:r+1'b1;end
    endfunction
    localparam [63:0] M=MARGIN_MM;
    localparam signed [63:0] T0=root_ceil(M*M*((AX1-AX0)*(AX1-AX0)+(AY1-AY0)*(AY1-AY0)));
    localparam signed [63:0] T1=root_ceil(M*M*((AX2-AX1)*(AX2-AX1)+(AY2-AY1)*(AY2-AY1)));
    localparam signed [63:0] T2=root_ceil(M*M*((AX0-AX2)*(AX0-AX2)+(AY0-AY2)*(AY0-AY2)));
    wire signed [63:0] px={{32{record_in[159]}},record_in[159:128]};
    wire signed [63:0] py={{32{record_in[191]}},record_in[191:160]};
    wire signed [63:0] c0=(AX1-AX0)*(py-AY0)-(AY1-AY0)*(px-AX0);
    wire signed [63:0] c1=(AX2-AX1)*(py-AY1)-(AY2-AY1)*(px-AX1);
    wire signed [63:0] c2=(AX0-AX2)*(py-AY2)-(AY0-AY2)*(px-AX2);
    wire signed [63:0] q0=(AREA>0)?c0:-c0,q1=(AREA>0)?c1:-c1,q2=(AREA>0)?c2:-c2;
    assign deep_inside=AREA!=0 && record_in[6:0]==0 && record_in[10:8]==7 && q0>=T0 && q1>=T1 && q2>=T2;
endmodule
`default_nettype wire
