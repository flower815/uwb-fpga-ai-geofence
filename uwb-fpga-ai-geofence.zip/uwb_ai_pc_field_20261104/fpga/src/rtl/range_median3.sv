`timescale 1ns/1ps
`default_nettype none
// Three fresh valid received samples per tag; forward sequence gaps are allowed.
// Invalid, duplicate and backwards samples never advance the history window.
module range_median3 #(
    parameter integer GAP_CYCLES=50_000_000
)(
    input wire clk,rst_n,in_valid,
    input wire [7:0] mask_in,seq_in,tag_in,
    input wire [31:0] d0_in,d1_in,d2_in,
    output reg out_valid,
    output reg [7:0] mask_out,seq_out,tag_out,
    output reg [31:0] d0_out,d1_out,d2_out,
    output reg [31:0] raw0,raw1,raw2
);
    reg [31:0] recent[0:26],older[0:26];
    reg [1:0] count[0:8];
    reg [7:0] last_seq[0:8];
    reg [8:0] seen;
    localparam integer AGE_W=(GAP_CYCLES<2)?1:$clog2(GAP_CYCLES+1);
    reg [AGE_W-1:0] age[0:8];
    wire good=(mask_in[2:0]==7 && d0_in>0 && d0_in<=60000 &&
               d1_in>0 && d1_in<=60000 && d2_in>0 && d2_in<=60000);
    function automatic [31:0] median(input [31:0] a,b,c);
        begin
            if(a<b) median=(b<c)?b:((a<c)?c:a);
            else median=(a<c)?a:((b<c)?c:b);
        end
    endfunction
    integer i,j;
    reg continuous,fresh;
    reg [7:0] seq_step;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            out_valid<=0;mask_out<=0;seq_out<=0;tag_out<=0;seen<=0;
            d0_out<=0;d1_out<=0;d2_out<=0;raw0<=0;raw1<=0;raw2<=0;
            for(i=0;i<9;i=i+1) begin count[i]<=0;last_seq[i]<=0;age[i]<=GAP_CYCLES;end
            for(i=0;i<27;i=i+1) begin recent[i]<=0;older[i]<=0;end
        end else begin
            out_valid<=in_valid;
            for(i=0;i<9;i=i+1) if(age[i]<GAP_CYCLES) age[i]<=age[i]+1'b1;
            if(in_valid) begin
                mask_out<=mask_in;seq_out<=seq_in;tag_out<=tag_in;
                d0_out<=d0_in;d1_out<=d1_in;d2_out<=d2_in;
                raw0<=d0_in;raw1<=d1_in;raw2<=d2_in;
                if(tag_in<=8) begin
                    seq_step=seq_in-last_seq[tag_in];
                    fresh=!seen[tag_in] || (seq_step!=0 && (!seq_step[7] || age[tag_in]>=GAP_CYCLES));
                    if(fresh)begin age[tag_in]<=0;last_seq[tag_in]<=seq_in;seen[tag_in]<=1;end
                    if(!good) count[tag_in]<=0;
                    else if(fresh) begin
                        continuous=(count[tag_in]!=0 && age[tag_in]<GAP_CYCLES &&
                                    fresh);
                        count[tag_in]<=continuous?2:1;
                        for(j=0;j<3;j=j+1) older[tag_in*3+j]<=recent[tag_in*3+j];
                        recent[tag_in*3]<=d0_in;recent[tag_in*3+1]<=d1_in;recent[tag_in*3+2]<=d2_in;
                        if(continuous && count[tag_in]==2) begin
                            d0_out<=median(d0_in,recent[tag_in*3],older[tag_in*3]);
                            d1_out<=median(d1_in,recent[tag_in*3+1],older[tag_in*3+1]);
                            d2_out<=median(d2_in,recent[tag_in*3+2],older[tag_in*3+2]);
                        end
                    end
                end
            end
        end
    end
endmodule
`default_nettype wire
