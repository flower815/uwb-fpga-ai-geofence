`timescale 1ns/1ps
`default_nettype none
// Public, read-only build parameters. Contains no Wi-Fi credentials or addresses.
module uwb_profile #(
    parameter integer X0=0,Y0=0,Z0=1000,X1=3000,Y1=0,Z1=1000,X2=1500,Y2=2600,Z2=1000,
    parameter integer TAG_Z=0,RANGE_FILTER=1,FENCE_CONFIRM=3,CLEAR_HITS=1,CLEAR_MARGIN_MM=0,
    parameter integer FAULT_TIMEOUT_MS=1000,EXPECTED_TAG=2,QUALITY_LIMIT_MM=200,
    parameter integer AI_EARLY_BEEP=0,CLK_HZ=50_000_000,UWB_BAUD=115200,
    parameter integer QUALITY_ENABLE=1,FAULT_ENABLE=1,
    parameter [31:0] FW_VERSION=32'h00050006
)(
    input wire [7:0] index,
    output reg [31:0] value,
    output reg valid
);
    always @* begin
        valid=1'b1;value=0;
        case(index)
            0:value=32'h55574235;
            1:value=FW_VERSION;
            2:value=X0;
            3:value=Y0;
            4:value=Z0;
            5:value=X1;
            6:value=Y1;
            7:value=Z1;
            8:value=X2;
            9:value=Y2;
            10:value=Z2;
            11:value=TAG_Z;
            12:value=RANGE_FILTER;
            13:value=FENCE_CONFIRM;
            14:value=CLEAR_HITS;
            15:value=CLEAR_MARGIN_MM;
            16:value=FAULT_TIMEOUT_MS;
            17:value=EXPECTED_TAG;
            18:value=QUALITY_LIMIT_MM;
            19:value=AI_EARLY_BEEP;
            20:value=CLK_HZ;
            21:value=UWB_BAUD;
            22:value=(QUALITY_ENABLE?32'd1:32'd0)|(FAULT_ENABLE?32'd2:32'd0);
            default:begin valid=1'b0;value=0;end
        endcase
    end
endmodule
`default_nettype wire
