# Creates a separate WIFI project; does not replace the original USB project.
set BUILD_OUTPUT_MODE WIFI
set wifi_create_rc [catch {
    source [file join [file dirname [info script]] create_project.tcl]
} wifi_create_result wifi_create_options]
unset BUILD_OUTPUT_MODE
if {$wifi_create_rc} {return -options $wifi_create_options $wifi_create_result}
