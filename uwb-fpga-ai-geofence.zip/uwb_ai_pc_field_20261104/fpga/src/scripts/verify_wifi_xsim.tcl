# Run after verify_wifi_vivado.tcl; mock ESP only, never connects to hardware.
set root [file normalize [file join [file dirname [info script]] ..]]
set project_dir [file join $root build vivado_wifi_check]
open_project [file join $project_dir mini5_fpga_wifi.xpr]
set_property top tb_wifi [get_filesets sim_1]
set_property generic {LEGACY_CUR=1 ENABLE_ANGLES=1} [get_filesets sim_1]
set_property xsim.simulate.runtime all [get_filesets sim_1]
launch_simulation -mode behavioral
# Close the simulator before reading its buffered logfile.
close_sim
set passed 0
foreach log_file [glob -nocomplain [file join $project_dir mini5_fpga_wifi.sim sim_1 behav xsim *.log]] {
    set f [open $log_file r]
    set content [read $f]
    close $f
    if {[string first "PASS tb_wifi:" $content]>=0} {set passed 1}
}
if {!$passed} {error "XSim did not report PASS tb_wifi"}
puts "PASS WIFI VIVADO 2020.2 XSIM (legacy_cur mock ESP)"
close_project
exit
