# Verify default USB V2 testbench using the same Vivado 2020.2 as the user.
set root [file normalize [file join [file dirname [info script]] ..]]
set project_dir [file join $root build vivado_angles_check]
open_project [file join $project_dir mini5_fpga.xpr]
set_property generic {ENABLE_ANGLES=1} [get_filesets sim_1]
set_property xsim.simulate.runtime all [get_filesets sim_1]
launch_simulation -mode behavioral
close_sim
set passed 0
foreach log_file [glob -nocomplain [file join $project_dir mini5_fpga.sim sim_1 behav xsim *.log]] {
    set f [open $log_file r]
    set content [read $f]
    close $f
    if {[string first "PASS tb_system:" $content]>=0} {set passed 1}
}
if {!$passed} {error "USB angle XSim did not report PASS tb_system"}
puts "PASS USB ANGLES VIVADO 2020.2 XSIM"
close_project
exit
