"""Check generated filtered projects against local geometry/network settings; never print credentials."""
import hashlib
import json
from pathlib import Path
import re
import tkinter
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    tcl=tkinter.Tcl()
    for name in ('board.tcl','ai.tcl'):tcl.call('source',str(ROOT/'config'/name))
    anchors=[[int(v) for v in tcl.splitlist(row)] for row in tcl.splitlist(tcl.getvar('ANCHORS_MM'))]
    tag_z=int(tcl.getvar('TAG_Z_MM'))
    geometry=dict(zip(('X0','Y0','Z0','X1','Y1','Z1','X2','Y2','Z2'),sum(anchors,[])))
    geometry.update(TAG_Z=tag_z,RANGE_FILTER=int(tcl.getvar('AI_RANGE_FILTER')),
                    FENCE_CONFIRM=int(tcl.getvar('AI_FENCE_CONFIRM')),AI_EARLY_BEEP=int(tcl.getvar('AI_EARLY_BEEP')),
                    ENABLE_FENCE=1,ENABLE_ANGLES=1,ENABLE_BUZZER=1,TELEMETRY_STEP_MM=1)
    for name in ('CLEAR_HITS','CLEAR_MARGIN_MM','QUALITY_ENABLE','QUALITY_LIMIT_MM','FAULT_ENABLE',
                 'FAULT_TIMEOUT_MS','FAULT_STARTUP_MS','EXPECTED_TAG'):
        geometry[name]=int(tcl.getvar('AI_'+name))
    tcl.call('source',str(ROOT/'scripts/wifi_config.tcl'))
    wifi=dict(str(v).split('=',1) for v in tcl.splitlist(tcl.call('wifi_generics',str(ROOT))))
    projects=[]
    for mode,name in [('wifi','mini5_fpga_wifi.xpr'),('usb','mini5_fpga.xpr')]:
        folder=str(tcl.getvar(f'AI_{mode.upper()}_PROJECT_DIR'))
        path=ROOT/'build'/folder/name
        values={x.get('Name'):x.get('Val') for x in ET.parse(path).getroot().iter('Generic')}
        assert all(values.get(k)==str(v) for k,v in geometry.items()),f'{mode} geometry/filter configuration differs'
        if mode=='wifi':assert all(values.get(k,'').lower()==v.lower() for k,v in wifi.items()),'Local Wi-Fi settings differ'
        bit=ROOT/f'build/uwb_ai_{mode}_quality.bit'
        alias=ROOT/('build/uwb_ai_wifi_top.bit' if mode=='wifi' else 'build/uwb_ai_top.bit')
        assert bit.read_bytes()==alias.read_bytes(),'Default bit alias differs'
        assert bit.read_bytes()==(ROOT/f'build/uwb_ai_{mode}_tx_mm.bit').read_bytes(),'v5.6 named bit differs'
        rpt=(ROOT/f'build/reliability/ai_{mode}_timing.rpt').read_text()
        assert 'All user specified timing constraints are met.' in rpt,'Timing not met'
        row=re.search(r'\n\s*(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+\d+\s+\d+\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+\d+\s+\d+',rpt)
        assert row and float(row[1])>=0 and float(row[3])>=0
        projects.append(dict(mode=mode,project=path.relative_to(ROOT).as_posix(),bit=bit.relative_to(ROOT).as_posix(),
                             bit_sha256=digest(bit),wns_ns=float(row[1]),whs_ns=float(row[3])))
    tcl.call('source',str(ROOT/'config/wifi.local.tcl'))
    source_files=[p.relative_to(ROOT).as_posix() for p in sorted((ROOT/'rtl').glob('*.sv'))]
    source_files += [
                  'shangweiji/pc_upper/uwb_pc/display_filter.py','shangweiji/pc_upper/uwb_pc/map_widget.py',
                  'shangweiji/pc_upper/uwb_pc/window.py','shangweiji/pc_upper/uwb_pc/protocol.py',
                  'shangweiji/pc_upper/uwb_pc/dashboard.py','shangweiji/pc_upper/uwb_pc/ai_panel.py',
                  'shangweiji/pc_upper/main.py',
                  'shangweiji/pc_upper/uwb_pc/history_replay.py',
                  'shangweiji/pc_upper/uwb_pc/coordinate_precision.py',
                  'shangweiji/pc_upper/examples/history_20261027.jsonl','shangweiji/pc_upper/examples/history_20261027.json',
                  'shangweiji/pc_upper/uwb_pc/profile.py','shangweiji/pc_upper/uwb_pc/known_point.py',
                  'shangweiji/pc_upper/uwb_pc/simulator.py',
                  'shangweiji/pc_upper/uwb_pc/known_point_dialog.py','config/ai.tcl','config/board.tcl',
                  'scripts/create_ai_project.tcl','scripts/build_tx_mm.tcl',
                  'shangweiji/pc_upper/uwb_pc/geofence.py','shangweiji/pc_upper/model/risk_mlp.json',
                  'shangweiji/pc_upper/uwb_pc/ai_model.py','shangweiji/pc_upper/assets/competition_watermark.png']
    source_files += [p.relative_to(ROOT).as_posix() for p in sorted((ROOT/'shangweiji/pc_upper/examples/field_tests').glob('*')) if p.is_file()]
    report=dict(version='20261101_telemetry_mm_internal_mm',firmware_version='20261101_tx_mm_v5.6',
                ai_prediction_horizon_s=.7,map_smoothing_default=True,map_smoothing_control_visible=False,
                installation_coordinate_step_mm=100,internal_coordinate_step_mm=1,telemetry_coordinate_step_mm=1,
                fault_buzzer_enabled=False,localization_health_independent_of_fence=True,
                sequence_policy="forward_modulo_256_under_128_with_timeout_resync",
                app_coordinate_step_mm=1,app_coordinate_rounding='half_away_from_zero',app_coordinate_display_decimals=1,
                map_display_stationary_lock=True,
                default_demo_pixels_per_metre=50,default_demo_grid_mm=100,
                anchors_mm=anchors,tag_z_mm=tag_z,range_filter=geometry['RANGE_FILTER'],
                fence_confirm=geometry['FENCE_CONFIRM'],ai_early_beep=geometry['AI_EARLY_BEEP'],
                policy={k:v for k,v in geometry.items() if k in ('CLEAR_HITS','CLEAR_MARGIN_MM','QUALITY_ENABLE','QUALITY_LIMIT_MM',
                          'FAULT_ENABLE','FAULT_TIMEOUT_MS','FAULT_STARTUP_MS','EXPECTED_TAG')},
                wifi_matches_local_configuration=True,compiled_pc_ip=str(tcl.getvar('WIFI_PC_IP')),
                compiled_pc_port=int(tcl.getvar('WIFI_PC_PORT')),physical_validation=False,projects=projects,
                source_sha256={p:digest(ROOT/p) for p in source_files})
    out=ROOT/'build/reliability/build_verified.json';out.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('PASS quality USB/Wi-Fi parameters, unchanged local network, bit aliases and timing')


if __name__=='__main__':main()
