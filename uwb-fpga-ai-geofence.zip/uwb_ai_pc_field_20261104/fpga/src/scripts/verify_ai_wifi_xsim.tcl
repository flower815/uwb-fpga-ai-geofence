set root [file normalize [file join [file dirname [info script]] ..]]
source [file join $root config ai.tcl]
set ai_wifi_dir vivado_ai_wifi
if {[info exists AI_WIFI_PROJECT_DIR]} {set ai_wifi_dir $AI_WIFI_PROJECT_DIR}
open_project [file join $root build $ai_wifi_dir mini5_fpga_wifi.xpr]
source [file join $root scripts wifi_config.tcl]
set expected_tcp [lsearch -inline [wifi_generics $root] TCP_COMMAND=*]
set actual_tcp [lsearch -inline [get_property generic [get_filesets sources_1]] TCP_COMMAND=*]
if {[string tolower $actual_tcp] ne [string tolower $expected_tcp]} {error "Wi-Fi target in project differs from current local configuration"}
puts "PASS AI WIFI project target matches local TCP configuration (credentials not printed)"
set_property xsim.simulate.runtime all [get_filesets sim_1]
launch_simulation -mode behavioral
close_sim
set f [open [file join $root build $ai_wifi_dir mini5_fpga_wifi.sim sim_1 behav xsim simulate.log] r]
set log_content [read $f];close $f
if {[string first "PASS tb_ai_wifi_system:" $log_content]<0} {error "AI WiFi XSim did not pass"}
puts "PASS AI WIFI VIVADO 2020.2 XSIM"
close_project
exit
