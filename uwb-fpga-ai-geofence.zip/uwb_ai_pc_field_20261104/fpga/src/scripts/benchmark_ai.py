"""Batch=1 local CPU/HIP prototype benchmark; synthetic truth, not field accuracy."""
import argparse
import csv
import json
from pathlib import Path
import random
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.ai_model import RiskModel,risk_features
from uwb_pc.ai_metrics import percentile
from uwb_pc.geofence import AI_POSITION_BOUNDS_M,AI_MAX_VELOCITY_MPS,AI_HORIZON_S


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--backend',choices=['native_cpu','torch_cpu','torch_rocm'],default='native_cpu')
    parser.add_argument('--samples',type=int,default=2000)
    parser.add_argument('--output',type=Path,default=ROOT/'metrics'/'synthetic_cpu')
    args=parser.parse_args();model=RiskModel(args.backend);rng=random.Random(20261029)
    if args.samples<1:raise ValueError('Positive sample count required')
    args.output.mkdir(parents=True,exist_ok=True)
    for _ in range(100):model.predict(risk_features(1.5,1,0,0))
    reference=RiskModel();max_delta=0.
    rows=[];start=time.perf_counter_ns()
    for index in range(args.samples):
        xmin,xmax,ymin,ymax=AI_POSITION_BOUNDS_M;speed=AI_MAX_VELOCITY_MPS
        x,y,vx,vy=[rng.uniform(a,b) for a,b in [(xmin,xmax),(ymin,ymax),(-speed,speed),(-speed,speed)]]
        a=time.perf_counter_ns();features=risk_features(x,y,vx,vy);b=time.perf_counter_ns()
        probability=model.predict(features);c=time.perf_counter_ns()
        predicted=int(probability>=.5);d=time.perf_counter_ns()
        future=risk_features(x+AI_HORIZON_S*vx,y+AI_HORIZON_S*vy,0,0)
        truth=int(min(features[::2])<0 or min(future[::2])<0)
        if args.backend!='native_cpu':max_delta=max(max_delta,abs(probability-reference.predict(features)))
        rows.append([index,truth,predicted,probability,(b-a)/1e6,(c-b)/1e6,(d-c)/1e6,(d-a)/1e6])
    elapsed=(time.perf_counter_ns()-start)/1e9
    tp=sum(r[1]==1 and r[2]==1 for r in rows);fp=sum(r[1]==0 and r[2]==1 for r in rows)
    fn=sum(r[1]==1 and r[2]==0 for r in rows);tn=len(rows)-tp-fp-fn
    f1=lambda t,f,n:2*t/max(1,2*t+f+n)
    report={'source':'independent_synthetic_seed_20261029','field_accuracy_measured':False,
            'accuracy':(tp+tn)/len(rows),'macro_f1':(f1(tp,fp,fn)+f1(tn,fn,fp))/2,
            'samples':len(rows),'benchmark_loop_samples_per_s':len(rows)/elapsed,
            'max_score_delta_from_native_cpu':max_delta,'backend_parity_pass':max_delta<=1e-4,
            'throughput_conditions':'short synthetic loop includes generation and truth checks; not field sustained throughput',
            'environment':model.environment()}
    for label,col in [('preprocess_ms',4),('inference_ms',5),('postprocess_ms',6),('total_ms',7)]:
        values=[r[col] for r in rows]
        report[label]={f'p{q}':percentile(values,q/100) for q in (50,95,99)};report[label]['max']=max(values)
    with (args.output/'samples.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['sample','truth','prediction','score','preprocess_ms','inference_ms','postprocess_ms','total_ms']);writer.writerows(rows)
    (args.output/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    if max_delta>1e-4:raise SystemExit('Backend numerical parity check failed')


if __name__=='__main__':main()
