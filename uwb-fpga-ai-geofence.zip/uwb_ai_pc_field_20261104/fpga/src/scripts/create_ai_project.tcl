# Local scope prevents BUILD_OUTPUT_DIR/MODE from leaking between Vivado projects.
proc create_ai_project_impl {} {
    global AI_BUILD_MODE AI_BUILD_DIR
    set root [file normalize [file join [file dirname [info script]] ..]]
    source [file join $root config ai.tcl]
    if {[info exists AI_BUILD_MODE]} {set AI_OUTPUT_MODE $AI_BUILD_MODE}
    if {$AI_OUTPUT_MODE ni {USB WIFI}} {error "AI_OUTPUT_MODE must be USB or WIFI"}
    set BUILD_OUTPUT_MODE $AI_OUTPUT_MODE
    set BUILD_OUTPUT_DIR [file join $root build vivado_ai_[string tolower $AI_OUTPUT_MODE]]
    if {$AI_OUTPUT_MODE eq "WIFI" && [info exists AI_WIFI_PROJECT_DIR]} {
        if {![regexp {^[a-z0-9_-]+$} $AI_WIFI_PROJECT_DIR]} {error "Invalid AI_WIFI_PROJECT_DIR"}
        set BUILD_OUTPUT_DIR [file join $root build $AI_WIFI_PROJECT_DIR]
    }
    if {$AI_OUTPUT_MODE eq "USB" && [info exists AI_USB_PROJECT_DIR]} {
        if {![regexp {^[a-z0-9_-]+$} $AI_USB_PROJECT_DIR]} {error "Invalid AI_USB_PROJECT_DIR"}
        set BUILD_OUTPUT_DIR [file join $root build $AI_USB_PROJECT_DIR]
    }
    if {[info exists AI_BUILD_DIR]} {set BUILD_OUTPUT_DIR [file normalize $AI_BUILD_DIR]}
    source [file join $root scripts create_project.tcl]
    if {!$ENABLE_FENCE || !$ENABLE_ANGLES} {error "AI project requires ENABLE_FENCE=1 and ENABLE_ANGLES=1"}
    if {$AI_OUTPUT_MODE eq "WIFI"} {
        set top uwb_ai_wifi_top
        set sim_top tb_ai_wifi_system
    } else {
        set top uwb_ai_top
        set sim_top tb_ai_system
        if {$PIN_ESP_RX in $pins} {error "AI PC RX pin conflicts with an existing port"}
        set fd [open $xdc a]
        puts $fd [format {set_property -dict {PACKAGE_PIN %s IOSTANDARD LVCMOS33 PULLUP TRUE} [get_ports pc_rx]} $PIN_ESP_RX]
        puts $fd {set_false_path -from [get_ports pc_rx] -to [get_cells -hier -filter {NAME =~ */rx_meta_reg}]}
        close $fd
    }
    set_property top $top [get_filesets sources_1]
    set_property generic "[get_property generic [get_filesets sources_1]] TELEMETRY_STEP_MM=1" [get_filesets sources_1]
    if {![info exists AI_RANGE_FILTER]} {set AI_RANGE_FILTER 1}
    if {$AI_RANGE_FILTER ni {0 1}} {error "AI_RANGE_FILTER must be 0 or 1"}
    set_property generic "[get_property generic [get_filesets sources_1]] RANGE_FILTER=$AI_RANGE_FILTER" [get_filesets sources_1]
    if {![info exists AI_FENCE_CONFIRM]} {set AI_FENCE_CONFIRM 3}
    if {![info exists AI_EARLY_BEEP]} {set AI_EARLY_BEEP 0}
    if {$AI_FENCE_CONFIRM ni {1 3} || $AI_EARLY_BEEP ni {0 1}} {error "FENCE_CONFIRM must be 1/3 and AI_EARLY_BEEP must be 0/1"}
    set_property generic "[get_property generic [get_filesets sources_1]] FENCE_CONFIRM=$AI_FENCE_CONFIRM AI_EARLY_BEEP=$AI_EARLY_BEEP" [get_filesets sources_1]
    foreach {name minimum maximum default} {
        CLEAR_HITS 1 3 1
        CLEAR_MARGIN_MM 0 1000 0
        QUALITY_ENABLE 0 1 1
        QUALITY_LIMIT_MM 1 2000 200
        FAULT_ENABLE 0 1 1
        FAULT_TIMEOUT_MS 100 10000 1000
        FAULT_STARTUP_MS 100 10000 3000
        EXPECTED_TAG 0 8 2
    } {
        set key AI_$name
        if {![info exists $key]} {set $key $default}
        set value [set $key]
        if {![string is integer -strict $value] || $value<$minimum || $value>$maximum} {error "Invalid $key"}
        set_property generic "[get_property generic [get_filesets sources_1]] $name=$value" [get_filesets sources_1]
    }
    foreach name {AI_FAULT_TIMEOUT_MS AI_FAULT_STARTUP_MS} {
        if {($CLK_HZ/1000)*wide([set $name])>2147483647} {error "$name exceeds timer capacity at this clock"}
    }
    if {$AI_CLEAR_HITS==1 && $AI_CLEAR_MARGIN_MM!=0} {error "Legacy one-frame release requires CLEAR_MARGIN_MM=0; use CLEAR_HITS=3 for inset release"}
    add_files -fileset sim_1 [file join $root sim ${sim_top}.sv]
    set_property top $sim_top [get_filesets sim_1]
    set_property generic {} [get_filesets sim_1]
    update_compile_order -fileset sources_1
    puts "AI project mode: $AI_OUTPUT_MODE; top: $top"
    return [dict create root $root mode $AI_OUTPUT_MODE directory $out project [file join $out ${project_name}.xpr] top $top]
}
set ai_project [create_ai_project_impl]
rename create_ai_project_impl {}
set root [dict get $ai_project root]
