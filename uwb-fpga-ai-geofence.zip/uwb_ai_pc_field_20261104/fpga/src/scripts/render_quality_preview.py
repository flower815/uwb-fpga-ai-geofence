"""Render explicitly synthetic fault and known-point statistics UI previews."""
import math
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from pathlib import Path
import sys
from PySide6.QtWidgets import QApplication
ROOT=Path(__file__).resolve().parents[1]
PC=ROOT/'shangweiji/pc_upper'
sys.path.insert(0,str(PC))
from uwb_pc.window import MainWindow
from uwb_pc.protocol import Measurement,encode_measurement
from uwb_pc.known_point_dialog import KnownPointDialog
from uwb_pc.geofence import SITE_ANCHORS_MM
from uwb_pc.ui_fonts import configure_font


def main():
    app=QApplication([]);configure_font(app);window=MainWindow();window.resize(1480,940)
    window.scenario_box.setCurrentIndex(window.scenario_box.findData('normal'))
    window.mode='demo';window.set_controls();window.hex_check.setChecked(False)
    window.source_label.setText('离线质量/失效状态演示 · 人工构造数据 · 非实物测量')
    fault=Measurement(16,0,1,2,(0,0,0),(0,0,0),(65535,)*3,0,32)
    window.receive_bytes(encode_measurement(fault));window.refresh_health();window.show();app.processEvents()
    window.map_panel.canvas.fit_map();app.processEvents()
    assert not window.map_panel.positions and not window.map_panel.alarm_tags
    if not window.grab().save(str(PC/'preview_quality.png')):raise RuntimeError('Fault preview failed')
    session=window.known_points;session.start((1500,866,0),2)
    for i in range(30):
        xy=(1500+int(40*math.sin(i)),866+int(30*math.cos(i)))
        ranges=tuple(round(math.dist((1500,866,0),a))+((i%5)-2)*8 for a in SITE_ANCHORS_MM)
        value=Measurement(0,7,i,2,ranges,(*xy,0),(65535,)*3,0,1)
        session.add(value,'unverified','demo',received_unix=1793282400+i*.1,received_monotonic=1+i*.1)
    session.active=False
    sample=PC/'examples/known_point_demo.csv';session.export_csv(sample)
    dialog=KnownPointDialog(window);dialog.resize(900,590)
    for box,v in zip(dialog.coordinates,(1500,866,0)):box.setValue(v)
    dialog.message.setText('离线合成统计示例：30条人工构造样本，source=demo，不能作为现场定位精度。')
    dialog.refresh();dialog.show();app.processEvents()
    assert session.summary()['simulated_count']==30
    if not dialog.grab().save(str(PC/'preview_calibration.png')):raise RuntimeError('Known-point preview failed')
    dialog.close();window.close();app.shutdown()
    print('PASS fault and known-point Qt previews; synthetic CSV explicitly marked demo')


if __name__=='__main__':main()
