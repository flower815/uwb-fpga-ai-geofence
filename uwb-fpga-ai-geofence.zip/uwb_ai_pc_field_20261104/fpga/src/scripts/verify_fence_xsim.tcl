set root [file normalize [file join [file dirname [info script]] ..]]
set fence_mode [expr {[llength $argv] ? [string toupper [lindex $argv 0]] : "USB"}]
set project_dir [file join $root build vivado_fence_[string tolower $fence_mode]_check]
set project_name [expr {$fence_mode eq "WIFI" ? "mini5_fpga_wifi" : "mini5_fpga"}]
open_project [file join $project_dir ${project_name}.xpr]
set sim_generics {ENABLE_ANGLES=1 ENABLE_FENCE=1}
if {$fence_mode eq "WIFI"} {lappend sim_generics LEGACY_CUR=1}
set_property generic [join $sim_generics " "] [get_filesets sim_1]
set_property xsim.simulate.runtime all [get_filesets sim_1]
launch_simulation -mode behavioral
close_sim
set passed 0
set token [expr {$fence_mode eq "WIFI" ? "PASS tb_wifi:" : "PASS tb_system:"}]
foreach log_file [glob -nocomplain [file join $project_dir ${project_name}.sim sim_1 behav xsim *.log]] {
    set f [open $log_file r];set content [read $f];close $f
    if {[string first $token $content]>=0} {set passed 1}
}
if {!$passed} {error "Geofence $fence_mode XSim did not report PASS"}
puts "PASS GEOFENCE $fence_mode VIVADO 2020.2 XSIM"
close_project
exit
