"""Preview original-speed CSV fault and fence states, without live hardware."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from pathlib import Path
import sys
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.window import MainWindow
from uwb_pc.ui_fonts import configure_font


def main():
    app=QApplication([]);configure_font(app)
    fault=MainWindow();fault.resize(1580,960);fault.show();fault.toggle_demo()
    fence=MainWindow();fence.resize(1580,960)
    fence.scenario_box.setCurrentIndex(fence.scenario_box.findData('field3'));fence.show();fence.toggle_demo()
    def save_fence():
        fence.replay.stop()
        fence.source_label.setText(fence.source_label.text()+' · 预览暂停')
        fence.refresh_health();fence.ai_panel.refresh();app.processEvents()
        assert fence.map_panel.alarm_tags=={2} and fence.mode=='replay'
        assert not fence.ai.enabled and fence.decoder.bytes_received==0
        assert fence.grab().save(str(ROOT/'shangweiji/pc_upper/preview_csv_fence.png'))
        fence.close()
    def save_fault():
        fault.replay.stop()
        fault.source_label.setText(fault.source_label.text()+' · 预览暂停')
        fault.refresh_health();fault.ai_panel.refresh();app.processEvents()
        assert fault.tags[2][0].position_fault and fault.mode=='replay'
        assert fault.map_panel.positions[2]!=(0,0) and fault.decoder.bytes_received==0
        assert fault.grab().save(str(ROOT/'shangweiji/pc_upper/preview_csv_fault.png'))
        fault.close();app.quit()
    QTimer.singleShot(5850,save_fence);QTimer.singleShot(8850,save_fault)
    app.exec();app.shutdown();print('PASS original-speed CSV fault/fence Qt previews; no UART bytes or hardware commands fabricated')


if __name__=='__main__':main()
