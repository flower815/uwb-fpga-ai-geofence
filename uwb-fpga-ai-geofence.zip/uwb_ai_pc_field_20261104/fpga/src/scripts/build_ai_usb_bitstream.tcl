set AI_BUILD_MODE USB
set ai_build_rc [catch {source [file join [file dirname [info script]] build_ai_bitstream.tcl]} ai_build_result ai_build_options]
unset AI_BUILD_MODE
if {$ai_build_rc} {return -options $ai_build_options $ai_build_result}
