# Build both current policies without touching historical Vivado project directories.
set root [file normalize [file join [file dirname [info script]] ..]]
foreach mode {USB WIFI} {
    set AI_BUILD_MODE $mode
    set lower_mode [string tolower $mode]
    set AI_REPORT_PREFIX [file join $root build reliability ai_${lower_mode}]
    set AI_BIT_OUTPUT [file join $root build uwb_ai_${lower_mode}_return_clear.bit]
    source [file join $root scripts build_ai_bitstream.tcl]
    close_project
}
unset AI_BUILD_MODE AI_REPORT_PREFIX AI_BIT_OUTPUT
foreach mode {usb wifi} {
    set built [file join $root build uwb_ai_${mode}_return_clear.bit]
    file copy -force $built [file join $root build uwb_ai_${mode}_quality.bit]
    set alias [expr {$mode eq "usb" ? "uwb_ai_top.bit" : "uwb_ai_wifi_top.bit"}]
    file copy -force $built [file join $root build $alias]
}
puts "PASS return-clear v5.2 USB/WIFI build, timing and default bit aliases"
exit
