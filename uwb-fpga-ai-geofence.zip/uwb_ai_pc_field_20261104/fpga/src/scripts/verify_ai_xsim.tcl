set root [file normalize [file join [file dirname [info script]] ..]]
source [file join $root config ai.tcl]
set ai_usb_dir vivado_ai_usb
if {[info exists AI_USB_PROJECT_DIR]} {set ai_usb_dir $AI_USB_PROJECT_DIR}
open_project [file join $root build $ai_usb_dir mini5_fpga.xpr]
set_property xsim.simulate.runtime all [get_filesets sim_1]
launch_simulation -mode behavioral
close_sim
set f [open [file join $root build $ai_usb_dir mini5_fpga.sim sim_1 behav xsim simulate.log] r]
set log_content [read $f];close $f
if {[string first "PASS tb_ai_system:" $log_content]<0} {error "AI XSim did not pass"}
puts "PASS AI USB VIVADO 2020.2 XSIM"
close_project
exit
