"""Independent Decimal reference for actual FPGA transmit-coordinate rounding."""
from pathlib import Path
from decimal import Decimal,ROUND_HALF_UP
import os,random,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
def main():
    rng=random.Random(20261101)
    values=[0,1,-1,49,-49,50,-50,51,-51,1249,-1249,1250,-1250,1251,-1251,2147483647,-2147483648]
    values += list(range(-150,151))+[rng.randint(-30000,30000) for _ in range(400)]
    rows=[f'{v} {int((Decimal(v)/100).quantize(Decimal(1),rounding=ROUND_HALF_UP))*100}\n' for v in values]
    (ROOT/'sim/telemetry_round_vectors.txt').write_text(''.join(rows),encoding='ascii')
    env=os.environ.copy();env['PATH']=str(ROOT/'.tools/mingw64/bin')+os.pathsep+env['PATH']
    cc=shutil.which('iverilog',path=env['PATH']);vvp=shutil.which('vvp',path=env['PATH'])
    out=ROOT/'build/reliability/tb_telemetry_round.vvp'
    subprocess.run([cc,'-g2012','-s','tb_telemetry_round','-o',str(out),str(ROOT/'rtl/telemetry_coordinate_round.sv'),str(ROOT/'sim/tb_telemetry_round.sv')],env=env,cwd=ROOT,check=True)
    subprocess.run([vvp,str(out)],env=env,cwd=ROOT,check=True,timeout=60)
if __name__=='__main__':main()
