set BUILD_OUTPUT_MODE WIFI
set wifi_build_rc [catch {
    source [file join [file dirname [info script]] build_bitstream.tcl]
} wifi_build_result wifi_build_options]
unset BUILD_OUTPUT_MODE
if {$wifi_build_rc} {return -options $wifi_build_options $wifi_build_result}
