"""Offline filter checks, including original UART ranges and conservative alarm flags."""
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.protocol import Measurement,encode_measurement,FrameDecoder


def main():
    out=ROOT/'build/filter';out.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env['PATH']=str(ROOT/'.tools/mingw64/bin')+os.pathsep+env['PATH']
    compiler=shutil.which('iverilog',path=env['PATH']);runtime=shutil.which('vvp',path=env['PATH'])
    if not compiler or not runtime:raise SystemExit('Icarus Verilog required')
    for top,angles in [('tb_range_median3',1),('tb_filtered_core',0),('tb_filtered_core',1)]:
        binary=out/f'{top}_{angles}.vvp'
        options=[] if top=='tb_range_median3' else [f'-Ptb_filtered_core.ANGLES={angles}']
        subprocess.run([compiler,'-g2012','-s',top,*options,'-o',str(binary),*[str(p) for p in sorted((ROOT/'rtl').glob('*.sv'))],str(ROOT/f'sim/{top}.sv')],check=True,env=env,cwd=ROOT)
        subprocess.run([runtime,str(binary),f'+CAPTURE={(out/"filtered_records.hex").as_posix()}'],check=True,env=env,cwd=ROOT,timeout=120)
    decoder=FrameDecoder();records=[]
    for row in (out/'filtered_records.hex').read_text().splitlines():
        data=int(row,16).to_bytes(36,'little')
        u=lambda i:int.from_bytes(data[i:i+4],'little',signed=i>=16)
        value=Measurement(data[0],data[1],data[2],data[3],tuple(u(i) for i in (4,8,12)),tuple(u(i) for i in (16,20,24)),
                          tuple(int.from_bytes(data[i:i+2],'little') for i in (30,32,34)),data[28],data[29])
        records+=decoder.feed(encode_measurement(value))
    assert len(records)==9 and records[3].fence_flags==4 and records[3].has_position and records[3].fence_alarm
    assert records[3].distances_mm[0]==5000 and records[3].position_mm==(1500,867,0)
    assert records[5].outside_fence and records[7].fence_alarm and records[8].fence_flags==1
    print('PASS filtered RTL records -> current V3 PC decoder, raw spike and unknown retained alarm')


if __name__=='__main__':main()
