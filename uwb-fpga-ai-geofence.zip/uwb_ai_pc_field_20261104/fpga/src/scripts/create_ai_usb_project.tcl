set AI_BUILD_MODE USB
set ai_create_rc [catch {source [file join [file dirname [info script]] create_ai_project.tcl]} ai_create_result ai_create_options]
unset AI_BUILD_MODE
if {$ai_create_rc} {return -options $ai_create_options $ai_create_result}
