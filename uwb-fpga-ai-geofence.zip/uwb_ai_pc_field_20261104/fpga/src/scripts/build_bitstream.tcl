# Vivado: vivado -mode batch -source scripts/build_bitstream.tcl
set root [file normalize [file join [file dirname [info script]] ..]]
source [file join $root config board.tcl]
if {!$BOARD_PINS_VERIFIED} {
    error "Hardware build needs verified pins in config/board.tcl. See README.md."
}
source [file join $root scripts create_project.tcl]
launch_runs synth_1 -jobs 4
wait_on_run synth_1
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {error "Synthesis failed"}
launch_runs impl_1 -to_step route_design -jobs 4
wait_on_run impl_1
if {[get_property PROGRESS [get_runs impl_1]] ne "100%"} {error "Implementation failed"}
open_run impl_1
report_utilization -file [file join $root build utilization.rpt]
report_timing_summary -file [file join $root build timing_summary.rpt]
report_drc -file [file join $root build drc.rpt]
check_timing -verbose -file [file join $root build check_timing.rpt]
foreach delay_type {max min} {
    set timing_paths [get_timing_paths -delay_type $delay_type -max_paths 1]
    if {[llength $timing_paths] == 0} {error "No $delay_type timing paths; check clock constraints"}
    foreach path $timing_paths {
        if {[get_property SLACK $path] < 0} {error "$delay_type timing failed; inspect build/timing_summary.rpt"}
    }
}
set bit_name [expr {$OUTPUT_MODE eq "WIFI" ? "uwb_wifi_top.bit" : "uwb_top.bit"}]
write_bitstream -force [file join $root build $bit_name]
puts "Bitstream: [file join $root build $bit_name]"
