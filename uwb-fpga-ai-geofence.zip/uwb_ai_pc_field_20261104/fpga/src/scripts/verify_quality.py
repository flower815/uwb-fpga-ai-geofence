"""Independent raw range consistency/inset references and fault/hysteresis RTL tests."""
import math
import os
from pathlib import Path
import random
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[1]


def vectors():
    anchors=((0,0,1000),(3000,0,1000),(1500,2600,1000));rng=random.Random(20261029)
    points=[(1500,866,0),(1500,50,0),(1500,149,0),(1500,150,0),(1500,151,0),(0,0,0),(3100,300,0),(-30000,30000,-30000)]
    points += [(rng.randint(-30000,30000),rng.randint(-30000,30000),rng.randint(-30000,30000)) for _ in range(120)]
    rows=[]
    for point in points:
        exact=[sum((p-a)**2 for p,a in zip(point,anchor)) for anchor in anchors]
        truth=[round(math.sqrt(v)) for v in exact]
        for perturb in (0,199,-199,201,-201,1000):
            ranges=[max(1,d+perturb) for d in truth]
            status=0x80 if perturb==199 else 0;mask=7
            good=int(all(0<d<=60000 and max(d-200,0)**2<=norm<=(d+200)**2 for d,norm in zip(ranges,exact)))
            crosses=[]
            for a,b in zip(anchors,anchors[1:]+anchors[:1]):
                cross=(b[0]-a[0])*(point[1]-a[1])-(b[1]-a[1])*(point[0]-a[0])
                edge2=(b[0]-a[0])**2+(b[1]-a[1])**2
                crosses.append(cross>=0 and cross*cross>=150**2*edge2)
            deep=int(all(crosses))
            rows.append((*point,*ranges,status,mask,good,deep))
    rows += [(1500,866,0,2000,2000,2000,1,7,0,0),(1500,866,0,2000,2000,2000,0,1,0,0),
             (1500,866,0,0,2000,2000,0,7,0,1),(1500,866,0,0xffffffff,2000,2000,0,7,0,1)]
    (ROOT/'sim/quality_vectors.txt').write_text(''.join(' '.join(map(str,row))+'\n' for row in rows),encoding='ascii')


def main():
    vectors();out=ROOT/'build/quality';out.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env['PATH']=str(ROOT/'.tools/mingw64/bin')+os.pathsep+env['PATH']
    compiler=shutil.which('iverilog',path=env['PATH']);runtime=shutil.which('vvp',path=env['PATH'])
    if not compiler or not runtime:raise SystemExit('Icarus Verilog required')
    for top in ('tb_quality_metrics','tb_clear_hysteresis','tb_position_watchdog','tb_quality_core'):
        binary=out/f'{top}.vvp'
        subprocess.run([compiler,'-g2012','-s',top,'-o',str(binary),*[str(p) for p in sorted((ROOT/'rtl').glob('*.sv'))],str(ROOT/f'sim/{top}.sv')],check=True,env=env,cwd=ROOT)
        subprocess.run([runtime,str(binary)],check=True,env=env,cwd=ROOT,timeout=120)
    print('PASS raw consistency / physical inset / independent failure watchdog / integrated core')


if __name__=='__main__':main()
