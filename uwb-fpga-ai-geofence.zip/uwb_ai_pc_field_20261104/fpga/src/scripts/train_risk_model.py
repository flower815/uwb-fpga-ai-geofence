"""Reproducible synthetic prototype, or explicitly labeled real feature CSV. Needs NumPy."""
import argparse
import csv
import json
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "shangweiji/pc_upper"))
from uwb_pc.ai_model import risk_features
from uwb_pc.geofence import SITE_ANCHORS_MM,SITE_TAG_Z_MM,AI_MARGIN_SCALE_M,AI_POSITION_BOUNDS_M,AI_MAX_VELOCITY_MPS,AI_HORIZON_S


def dataset(seed, count):
    rng = np.random.default_rng(seed)
    xmin,xmax,ymin,ymax=AI_POSITION_BOUNDS_M;speed=AI_MAX_VELOCITY_MPS
    poses = rng.uniform([xmin, ymin, -speed, -speed], [xmax, ymax, speed, speed], (count, 4))
    x = np.array([risk_features(*p) for p in poses], dtype=np.float64)
    # Label means current outside OR constant-velocity trajectory exits in configured horizon.
    future = [risk_features(p[0]+AI_HORIZON_S*p[2], p[1]+AI_HORIZON_S*p[3], 0, 0) for p in poses]
    y = ((x[:, ::2].min(axis=1) < 0) | (np.array(future)[:, ::2].min(axis=1) < 0)).astype(float)[:, None]
    return x, y


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, help="f0..f5,label,split (train/test); labels need independent truth")
    parser.add_argument("--output", type=Path, default=ROOT/"shangweiji/pc_upper/model/risk_mlp.json")
    parser.add_argument("--epochs", type=int, default=100)
    args = parser.parse_args()
    source = "synthetic_constant_velocity"
    if args.csv:
        rows = list(csv.DictReader(args.csv.open(encoding="utf-8-sig")))
        groups = {}
        for split in ("train", "test"):
            selected = [r for r in rows if r["split"] == split]
            if not selected: raise ValueError("Separate train and test rows required")
            groups[split] = (np.array([[float(r[f'f{i}']) for i in range(6)] for r in selected]),
                             np.array([[int(r['label'])] for r in selected]))
        (x, y), (xt, yt) = groups["train"], groups["test"]
        source = "user_labeled_csv_unverified"
    else:
        x, y = dataset(20261027, 16000); xt, yt = dataset(20261028, 4000)
    if not np.isfinite(x).all() or not np.isfinite(xt).all() or not np.isin(y,[0,1]).all() or not np.isin(yt,[0,1]).all():
        raise ValueError("Finite features and binary labels required")
    rng = np.random.default_rng(42)
    sizes = [6,24,12,1]
    weights = [rng.normal(0, np.sqrt(1/a), (a,b)) for a,b in zip(sizes,sizes[1:])]
    biases = [np.zeros((1,b)) for b in sizes[1:]]
    params = weights + biases; m = [np.zeros_like(p) for p in params]; v = [p.copy() for p in m]
    step = 0
    for epoch in range(args.epochs):
        order = rng.permutation(len(x))
        for start in range(0, len(x), 256):
            ids = order[start:start+256]; a0=x[ids]; a1=np.tanh(a0@weights[0]+biases[0]);a2=np.tanh(a1@weights[1]+biases[1])
            pred=1/(1+np.exp(-np.clip(a2@weights[2]+biases[2],-60,60)))
            d3=(pred-y[ids])/len(ids);d2=(d3@weights[2].T)*(1-a2*a2);d1=(d2@weights[1].T)*(1-a1*a1)
            grads=[a0.T@d1,a1.T@d2,a2.T@d3,d1.sum(0,keepdims=True),d2.sum(0,keepdims=True),d3.sum(0,keepdims=True)]
            step+=1
            for i,(p,g) in enumerate(zip(params,grads)):
                m[i]=.9*m[i]+.1*g;v[i]=.999*v[i]+.001*g*g
                p-=.003*(m[i]/(1-.9**step))/(np.sqrt(v[i]/(1-.999**step))+1e-8)
    a=np.tanh(xt@weights[0]+biases[0]);a=np.tanh(a@weights[1]+biases[1]);p=1/(1+np.exp(-np.clip(a@weights[2]+biases[2],-60,60)))
    yp=p[:,0]>=.5;truth=yt[:,0].astype(bool)
    tp=int((yp&truth).sum());fp=int((yp&~truth).sum());fn=int((~yp&truth).sum());tn=int((~yp&~truth).sum())
    f1=lambda t,f,n:2*t/max(1,2*t+f+n)
    report={"accuracy":float((yp==truth).mean()),"macro_f1":(f1(tp,fp,fn)+f1(tn,fn,fp))/2,
            "tp":tp,"fp":fp,"fn":fn,"tn":tn,"train_samples":len(x),"test_samples":len(xt),"physical_validation":False}
    model={"version":"risk_mlp_20261101_site_dm_horizon07_v5","architecture":sizes,"horizon_s":AI_HORIZON_S,"training_source":source,
           "training_seed":20261027,"test_seed":20261028,"epochs":args.epochs,"features":"edge_signed_margin_m/1.5,edge_normal_velocity_mps/2, CCW A0-A1-A2",
           "feature_margin_scale_m":AI_MARGIN_SCALE_M,"position_bounds_m":AI_POSITION_BOUNDS_M,
           "anchors_mm":[list(p) for p in SITE_ANCHORS_MM],"tag_z_mm":SITE_TAG_Z_MM,"report":report,
           "layers":[{"weights":w.T.tolist(),"bias":b[0].tolist()} for w,b in zip(weights,biases)]}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(model,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2));print(args.output)


if __name__ == "__main__": main()
