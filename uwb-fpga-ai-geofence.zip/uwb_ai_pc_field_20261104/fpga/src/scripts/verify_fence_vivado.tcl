# Offline implementation. USB exports a separate bit; WIFI uses fictitious credentials.
set root [file normalize [file join [file dirname [info script]] ..]]
set fence_mode [expr {[llength $argv] ? [string toupper [lindex $argv 0]] : "USB"}]
if {$fence_mode ni {USB WIFI}} {error "Expected USB or WIFI"}
set BUILD_OUTPUT_MODE $fence_mode
set BUILD_OUTPUT_DIR [file join $root build vivado_fence_[string tolower $fence_mode]_check]
if {$fence_mode eq "WIFI"} {
    set WIFI_CONFIG_FILE [file join $root build fence_wifi_test_only.tcl]
    file mkdir [file dirname $WIFI_CONFIG_FILE]
    set f [open $WIFI_CONFIG_FILE w]
    puts $f {set WIFI_SSID {lab}}
    puts $f {set WIFI_PASSWORD {secret123}}
    puts $f {set WIFI_PC_IP {192.168.10.26}}
    puts $f {set WIFI_PC_PORT 9000}
    puts $f {set WIFI_AT_PROFILE legacy_cur}
    puts $f {set WIFI_TCP_KEEPALIVE 5}
    close $f
}
source [file join $root scripts create_project.tcl]
if {!$ENABLE_FENCE} {error "ENABLE_FENCE=1 required"}
launch_runs synth_1 -jobs 4
wait_on_run synth_1
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {error "Fence synthesis failed"}
launch_runs impl_1 -to_step route_design -jobs 4
wait_on_run impl_1
if {[get_property PROGRESS [get_runs impl_1]] ne "100%"} {error "Fence implementation failed"}
open_run impl_1
set fence_prefix [file join $root build fence_[string tolower $fence_mode]]
report_timing_summary -file ${fence_prefix}_timing.rpt
report_utilization -file ${fence_prefix}_utilization.rpt
report_drc -file ${fence_prefix}_drc.rpt
foreach delay_type {max min} {
    set paths [get_timing_paths -delay_type $delay_type -max_paths 1]
    if {[llength $paths]==0} {error "Missing fence timing paths"}
    foreach path $paths {if {[get_property SLACK $path]<0} {error "Fence timing failed: $delay_type"}}
}
if {[llength [get_drc_violations -filter {SEVERITY == "Error"}]]>0} {error "Fence DRC errors"}
if {$fence_mode eq "USB"} {write_bitstream -force [file join $root build uwb_top_fence.bit]}
puts "PASS GEOFENCE $fence_mode SYNTHESIS / ROUTE / TIMING"
close_project
exit
