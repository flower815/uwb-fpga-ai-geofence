"""Run portable RTL and host checks. Requires Icarus Verilog 12+ on PATH.
If .tools/mingw64 exists in this workspace it is used without global installation.
"""
import ast
import argparse
import math
import os
from pathlib import Path
import random
import shutil
import subprocess
import sys
from fractions import Fraction

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)


def trunc_div(n, d):
    return (abs(n)//abs(d)) * (-1 if (n < 0) != (d < 0) else 1) if d else 0


def generate_vectors():
    rng = random.Random(20261021)
    pairs = [(0,1),(1,0),(-1,1),(1,-1),(-1,-1),(-(1<<63),1),(-(1<<63),2),
             ((1<<63)-1,1),((1<<63)-1,-1),(1,1<<62),(-(1<<63),-(1<<63))]
    pairs += [(rng.randrange(-(1<<60),1<<60),rng.randrange(-(1<<50),1<<50) or 1) for _ in range(200)]
    (ROOT/"sim/division_vectors.txt").write_text("".join(f"{n} {d} {trunc_div(n,d)}\n" for n,d in pairs))
    anchors = [(500,-1000,1700),(-2500,6500,1400),(5500,1000,2400)]
    rows=[]
    for _ in range(150):
        xyz = (rng.randint(-6000,12000),rng.randint(-6000,12000),900)
        r=[round(math.dist(xyz,p)) for p in anchors]
        x0,y0,z0=anchors[0];x1,y1,z1=anchors[1];x2,y2,z2=anchors[2]
        a,b,c,d=2*(x1-x0),2*(y1-y0),2*(x2-x0),2*(y2-y0)
        e=r[0]**2-r[1]**2+x1*x1+y1*y1+(z1-900)**2-x0*x0-y0*y0-(z0-900)**2
        f=r[0]**2-r[2]**2+x2*x2+y2*y2+(z2-900)**2-x0*x0-y0*y0-(z0-900)**2
        det=a*d-b*c
        x,y=trunc_div(e*d-b*f,det),trunc_div(a*f-e*c,det)
        assert abs(x-xyz[0]) < 10 and abs(y-xyz[1]) < 10
        rows.append(f"{r[0]} {r[1]} {r[2]} {x} {y}\n")
    (ROOT/"sim/solver_vectors.txt").write_text("".join(rows))
    # Independent floating-point reference, including all axes and 32-bit limits.
    directions=[(0,0),(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,1),(-1,-1),(1,-1)]
    directions += [(x,y) for x in (-(1<<31),-60000,-1,0,1,60000,(1<<31)-1)
                   for y in (-(1<<31),-60000,-1,0,1,60000,(1<<31)-1)]
    directions += [(rng.randint(-60000,60000),rng.randint(-60000,60000)) for _ in range(500)]
    directions += [(rng.randint(-(1<<31),(1<<31)-1),rng.randint(-(1<<31),(1<<31)-1)) for _ in range(100)]
    (ROOT/"sim/atan_vectors.txt").write_text("".join(
        f"{x} {y} {round(math.degrees(math.atan2(y,x))*100)} {int(x!=0 or y!=0)}\n"
        for x,y in directions))
    angle_anchors=[(-500,1000),(6000,-2000),(-7000,-4000)]
    points=angle_anchors+[(0,0),(3000,4000)]+[(rng.randint(-30000,30000),rng.randint(-30000,30000)) for _ in range(150)]
    rows=[]
    for x,y in points:
        valid=sum((1<<i) for i,(ax,ay) in enumerate(angle_anchors) if (x,y)!=(ax,ay))
        angles=[round(math.degrees(math.atan2(y-ay,x-ax))*100)%36000 if (x,y)!=(ax,ay) else 65535
                for ax,ay in angle_anchors]
        rows.append(f"{x} {y} {valid} {' '.join(map(str,angles))}\n")
    (ROOT/"sim/bearing_vectors.txt").write_text("".join(rows))
    def fence_flag(x,y):
        # Exact barycentric reference, separate from the RTL's three cross signs.
        u=Fraction(x*2600-y*1500,3000*2600)
        v=Fraction(y,2600)
        return 1 if u>=0 and v>=0 and u+v<=1 else 3
    points=[(0,0),(3000,0),(1500,2600),(750,1300),(2250,1300),(1500,0),
            (1500,850),(1500,2000),(-1,0),(0,1),(3001,0),(1500,2601),(750,1298),(750,1300),
            (2250,1298),(2250,1300),(-(1<<31),0),((1<<31)-1,0),(0,-(1<<31)),(0,(1<<31)-1)]
    points += [(rng.randint(-30000,30000),rng.randint(-30000,30000)) for _ in range(600)]
    (ROOT/"sim/fence_vectors.txt").write_text("".join(f"{x} {y} {fence_flag(x,y)}\n" for x,y in points))
    anchors=[(0,0,1000),(3000,0,1000),(1500,2600,1000)]
    points=[(1500,850),(2500,1500),(-500,1000),(1500,-500),(1500,3000),
            (1500,0),(750,1300),(2250,1300),(1500,850),(3250,500)]
    rows=[]
    for x,y in points:
        r=[round(math.dist((x,y,0),a)) for a in anchors]
        e=r[0]**2-r[1]**2+3000**2
        f=r[0]**2-r[2]**2+1500**2+2600**2
        px=trunc_div(e*5200,6000*5200)
        py=trunc_div(6000*f-3000*e,6000*5200)
        angles=[round(math.degrees(math.atan2(py-a[1],px-a[0]))*100)%36000 for a in anchors]
        rows.append(" ".join(map(str,[*r,px,py,fence_flag(px,py),*angles]))+"\n")
    (ROOT/"sim/fence_system_vectors.txt").write_text("".join(rows))


def run(command, env=None):
    print("RUN", " ".join(map(str,command)), flush=True)
    subprocess.run(command, check=True, env=env, timeout=120)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gui", action="store_true", help="Also run the new PySide6 upper computer checks")
    args = parser.parse_args()
    for directory in ["host", "scripts", "tests"]:
        for file in (ROOT/directory).glob("*.py"):
            ast.parse(file.read_text(encoding="utf-8"),filename=str(file))
    run([sys.executable,"-m","unittest","discover","-s","tests","-v"])
    generate_vectors()
    local_bin=ROOT/".tools/mingw64/bin"
    env=os.environ.copy()
    # Use a workspace temp directory so Qt and Python share the same writable path.
    temp_dir=ROOT/"build/test_tmp"
    temp_dir.mkdir(parents=True,exist_ok=True)
    env.update(TEMP=str(temp_dir),TMP=str(temp_dir),PYTHONIOENCODING="utf-8")
    if local_bin.is_dir():
        env["PATH"]=str(local_bin)+os.pathsep+env["PATH"]
    iverilog=shutil.which("iverilog",path=env["PATH"])
    vvp=shutil.which("vvp",path=env["PATH"])
    if not iverilog or not vvp:
        sys.exit("Host tests passed. RTL tests NOT run: install Icarus Verilog and rerun.")
    (ROOT/"build").mkdir(exist_ok=True)
    rtl=sorted((ROOT/"rtl").glob("*.sv"))
    captures=[]
    for top in ["tb_numeric","tb_fifo","tb_angles","tb_geofence","tb_system"]:
        out=ROOT/"build"/(top+".vvp")
        run([iverilog,"-g2012","-Wall","-s",top,"-o",str(out),*map(str,rtl),str(ROOT/"sim"/(top+".sv"))],env)
        command=[vvp,str(out)]
        if top=="tb_system":
            capture=ROOT/"build/uart_fast.hex"
            captures.append(capture)
            command.append("+CAPTURE="+capture.as_posix())
        run(command,env)
    out=ROOT/"build/tb_system_50m.vvp"
    run([iverilog,"-g2012","-Wall","-s","tb_system","-Ptb_system.CLK_HZ=50000000",
         "-Ptb_system.BAUD=115200","-o",str(out),*map(str,rtl),str(ROOT/"sim/tb_system.sv")],env)
    capture=ROOT/"build/uart_50m.hex"
    captures.append(capture)
    run([vvp,str(out),"+CAPTURE="+capture.as_posix()],env)
    fence_captures=[]
    for hz,baud,label in ((2_000_000,100000,"fast"),(50_000_000,115200,"50m")):
        out=ROOT/"build"/f"tb_fence_system_{label}.vvp"
        capture=ROOT/"build"/f"uart_fence_{label}.hex"
        run([iverilog,"-g2012","-Wall","-s","tb_fence_system",f"-Ptb_fence_system.CLK_HZ={hz}",
             f"-Ptb_fence_system.BAUD={baud}","-o",str(out),*map(str,rtl),str(ROOT/"sim/tb_fence_system.sv")],env)
        run([vvp,str(out),"+CAPTURE="+capture.as_posix()],env)
        fence_captures.extend(["--capture",str(capture)])
    run([sys.executable,str(ROOT/"scripts/check_fence_capture.py"),*fence_captures],env)
    # The fence-only V3 mode must also work when angle calculation is disabled.
    out=ROOT/"build/tb_fence_only.vvp"
    run([iverilog,"-g2012","-Wall","-s","tb_system","-Ptb_system.ENABLE_FENCE=1",
         "-o",str(out),*map(str,rtl),str(ROOT/"sim/tb_system.sv")],env)
    capture=ROOT/"build/uart_fence_only.hex"
    captures.append(capture)
    run([vvp,str(out),"+CAPTURE="+capture.as_posix()],env)
    out=ROOT/"build/tb_system_angles_50m.vvp"
    run([iverilog,"-g2012","-Wall","-s","tb_system","-Ptb_system.CLK_HZ=50000000",
         "-Ptb_system.BAUD=115200","-Ptb_system.ENABLE_ANGLES=1","-o",str(out),
         *map(str,rtl),str(ROOT/"sim/tb_system.sv")],env)
    capture=ROOT/"build/uart_angles_50m.hex"
    captures.append(capture)
    run([vvp,str(out),"+CAPTURE="+capture.as_posix()],env)
    wifi_captures=[]
    for profile in (0,1):
        out=ROOT/"build"/f"tb_wifi_{profile}.vvp"
        capture=ROOT/"build"/f"wifi_{profile}.hex"
        run([iverilog,"-g2012","-Wall","-s","tb_wifi",f"-Ptb_wifi.LEGACY_CUR={profile}",
             "-o",str(out),*map(str,rtl),str(ROOT/"sim/tb_wifi.sv")],env)
        run([vvp,str(out),"+CAPTURE="+capture.as_posix()],env)
        wifi_captures.extend(["--capture",str(capture)])
    out=ROOT/"build/tb_wifi_angles.vvp"
    capture=ROOT/"build/wifi_angles.hex"
    run([iverilog,"-g2012","-Wall","-s","tb_wifi","-Ptb_wifi.LEGACY_CUR=1","-Ptb_wifi.ENABLE_ANGLES=1",
         "-o",str(out),*map(str,rtl),str(ROOT/"sim/tb_wifi.sv")],env)
    run([vvp,str(out),"+CAPTURE="+capture.as_posix()],env)
    wifi_captures.extend(["--capture",str(capture)])
    out=ROOT/"build/tb_wifi_fence.vvp"
    capture=ROOT/"build/wifi_fence.hex"
    run([iverilog,"-g2012","-Wall","-s","tb_wifi","-Ptb_wifi.LEGACY_CUR=1","-Ptb_wifi.ENABLE_ANGLES=1",
         "-Ptb_wifi.ENABLE_FENCE=1","-o",str(out),*map(str,rtl),str(ROOT/"sim/tb_wifi.sv")],env)
    run([vvp,str(out),"+CAPTURE="+capture.as_posix()],env)
    wifi_captures.extend(["--capture",str(capture)])
    run([sys.executable,str(ROOT/"scripts/check_wifi_capture.py"),*wifi_captures],env)
    check=[sys.executable,str(ROOT/"scripts/check_new_host.py")]
    for capture in captures:
        check.extend(["--capture",str(capture)])
    run(check,env)
    if args.gui:
        pc_root=ROOT/"shangweiji/pc_upper"
        qt_python=pc_root/".venv/Scripts/python.exe"
        if not qt_python.is_file():
            qt_python=Path(sys.executable)
        run([str(qt_python),str(pc_root/"check.py")],env)
        run([str(qt_python),*check[1:],"--gui"],env)
        run([str(qt_python),str(ROOT/"scripts/check_wifi_capture.py"),*wifi_captures,"--gui"],env)
        run([str(qt_python),str(ROOT/"scripts/check_fence_capture.py"),*fence_captures,"--gui"],env)
    print("ALL REQUESTED RTL AND NEW-HOST CHECKS PASSED",flush=True)
