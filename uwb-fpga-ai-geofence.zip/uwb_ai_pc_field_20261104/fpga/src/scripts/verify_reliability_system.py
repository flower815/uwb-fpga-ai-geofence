"""Full new AI USB top -> actual UART bytes -> current PC protocol decoder."""
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))


def main():
    out=ROOT/'build/reliability';out.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env['PATH']=str(ROOT/'.tools/mingw64/bin')+os.pathsep+env['PATH']
    cc=shutil.which('iverilog',path=env['PATH']);vvp=shutil.which('vvp',path=env['PATH'])
    if not cc or not vvp:raise SystemExit('Icarus Verilog required')
    binary=out/'tb_reliability_system.vvp';capture=out/'reliability_uart.hex'
    subprocess.run([cc,'-g2012','-s','tb_reliability_system','-o',str(binary),
                    *[str(p) for p in sorted((ROOT/'rtl').glob('*.sv'))],str(ROOT/'sim/tb_reliability_system.sv')],env=env,cwd=ROOT,check=True)
    subprocess.run([vvp,str(binary),f'+CAPTURE={capture.as_posix()}'],env=env,cwd=ROOT,check=True,timeout=180)
    from uwb_pc.protocol import FrameDecoder
    decoder=FrameDecoder();records=[]
    for row in capture.read_text().splitlines():
        packet=bytes.fromhex(row)
        for i in range(0,len(packet),7):records+=decoder.feed(packet[i:i+7])
    assert decoder.crc_errors==0 and decoder.format_errors==0
    assert any(v.fence_flags==32 for v in records) and any(v.fence_flags==36 for v in records)
    assert any(v.status&16 for v in records)
    assert any(any(c%10!=0 for c in v.position_mm) for v in records if v.has_position)
    edge=[v for v in records if v.sequence==68 and v.mask==7][-1]
    assert -10 < edge.position_mm[1] < 0 and edge.fence_alarm and edge.has_position
    assert edge.distances_mm==(1803,1803,2791)
    query=list(decoder.acknowledgements)
    assert len(query)==1 and query[0].opcode==3 and query[0].fpga_tick==0x55574235
    print('PASS full silent-fault/first-inside/profile AI UART -> PC decoder:',len(records),'telemetry')


if __name__=='__main__':main()
