# Parse and validate local configuration before replacing any Vivado project.
# Only writes command bytes to generics; never prints SSID/password.
proc wifi_generics {root} {
    global WIFI_CONFIG_FILE
    set local_file [file join $root config wifi.local.tcl]
    if {[info exists WIFI_CONFIG_FILE]} {set local_file $WIFI_CONFIG_FILE}
    if {![file isfile $local_file]} {
        error "Copy config/wifi.example.tcl to config/wifi.local.tcl and fill your network settings first."
    }
    source $local_file
    foreach name {WIFI_SSID WIFI_PASSWORD WIFI_PC_IP WIFI_PC_PORT WIFI_AT_PROFILE WIFI_TCP_KEEPALIVE} {
        if {![info exists $name]} {error "Missing Wi-Fi configuration field: $name"}
    }
    foreach name {WIFI_SSID WIFI_PASSWORD} {
        set value [set $name]
        if {[regexp {[\x00-\x1f\x7f]} $value]} {error "$name contains control characters"}
        set bytes [encoding convertto utf-8 $value]
        set size [string length $bytes]
        if {($name eq "WIFI_SSID" && ($size<1 || $size>32 || $value eq "YOUR_2G_WIFI")) ||
            ($name eq "WIFI_PASSWORD" && ($size>64 || $value eq "YOUR_PASSWORD"))} {
            error "Fill $name with a valid value (SSID: 1-32 UTF-8 bytes; password: at most 64 bytes)."
        }
    }
    if {![regexp {^([0-9]+)\.([0-9]+)\.([0-9]+)\.([0-9]+)$} $WIFI_PC_IP -> a b c d]} {
        error "WIFI_PC_IP must be the PC's LAN IPv4 address"
    }
    foreach octet [list $a $b $c $d] {
        if {[string length $octet]>3 || [scan $octet %d number]!=1 || $number>255} {error "Invalid WIFI_PC_IP"}
    }
    if {[scan $a %d first]!=1 || $first==0 || $first==127 || $first>=224} {
        error "WIFI_PC_IP must be a unicast LAN address, not a loopback/listen address"
    }
    foreach name {WIFI_PC_PORT WIFI_TCP_KEEPALIVE} {
        if {![string is integer -strict [set $name]]} {error "$name must be an integer"}
    }
    if {$WIFI_PC_PORT<1 || $WIFI_PC_PORT>65535 || $WIFI_TCP_KEEPALIVE<0 || $WIFI_TCP_KEEPALIVE>7200} {
        error "Invalid Wi-Fi port or keepalive"
    }
    if {$WIFI_AT_PROFILE ni {modern legacy_cur}} {error "WIFI_AT_PROFILE must be modern or legacy_cur"}
    set legacy [expr {$WIFI_AT_PROFILE eq "legacy_cur"}]
    # ESP AT quoted arguments escape backslash, quotation mark, and comma.
    set ssid [string map [list \\ \\\\ \" \\\" , \\,] $WIFI_SSID]
    set password [string map [list \\ \\\\ \" \\\" , \\,] $WIFI_PASSWORD]
    set join_name [expr {$legacy ? "AT+CWJAP_CUR" : "AT+CWJAP"}]
    set join_command "${join_name}=\"$ssid\",\"$password\"\r\n"
    set tcp_command "AT+CIPSTART=\"TCP\",\"$WIFI_PC_IP\",$WIFI_PC_PORT,$WIFI_TCP_KEEPALIVE\r\n"
    binary scan [encoding convertto utf-8 $join_command] H* join_hex
    binary scan [encoding convertto utf-8 $tcp_command] H* tcp_hex
    set join_len [expr {[string length $join_hex]/2}]
    set tcp_len [expr {[string length $tcp_hex]/2}]
    if {$join_len>256 || $tcp_len>128} {error "Wi-Fi command exceeds hardware ROM capacity"}
    return [list LEGACY_CUR=$legacy JOIN_LEN=$join_len TCP_LEN=$tcp_len \
        JOIN_COMMAND=2048'h$join_hex TCP_COMMAND=1024'h$tcp_hex]
}
