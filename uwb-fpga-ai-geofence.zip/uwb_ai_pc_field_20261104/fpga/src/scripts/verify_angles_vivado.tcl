# USB-angle implementation using current board geometry; no hardware access.
set root [file normalize [file join [file dirname [info script]] ..]]
set BUILD_OUTPUT_MODE USB
set BUILD_OUTPUT_DIR [file join $root build vivado_angles_check]
source [file join $root scripts create_project.tcl]
if {!$ENABLE_ANGLES} {error "Angle check requires ENABLE_ANGLES=1"}
launch_runs synth_1 -jobs 4
wait_on_run synth_1
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {error "Angle synthesis failed"}
launch_runs impl_1 -to_step route_design -jobs 4
wait_on_run impl_1
if {[get_property PROGRESS [get_runs impl_1]] ne "100%"} {error "Angle implementation failed"}
open_run impl_1
report_utilization -file [file join $root build angles_utilization.rpt]
report_timing_summary -file [file join $root build angles_timing.rpt]
report_drc -file [file join $root build angles_drc.rpt]
foreach delay_type {max min} {
    set paths [get_timing_paths -delay_type $delay_type -max_paths 1]
    if {[llength $paths]==0} {error "Missing angle timing paths"}
    foreach path $paths {
        if {[get_property SLACK $path]<0} {error "Angle timing failed: $delay_type"}
    }
}
if {[llength [get_drc_violations -filter {SEVERITY == "Error"}]]>0} {error "Angle DRC errors"}
write_bitstream -force [file join $root build uwb_top_angles.bit]
puts "PASS USB ANGLES VIVADO: generated build/uwb_top_angles.bit with current board geometry"
close_project
exit
