# Vivado GUI: source scripts/create_project.tcl
# Vivado batch: vivado -mode batch -source scripts/create_project.tcl
set root [file normalize [file join [file dirname [info script]] ..]]
source [file join $root config board.tcl]
if {[info exists BUILD_OUTPUT_MODE]} {set OUTPUT_MODE $BUILD_OUTPUT_MODE}
if {$OUTPUT_MODE ni {USB WIFI}} {error "OUTPUT_MODE must be USB or WIFI"}
if {$ENABLE_ANGLES ni {0 1}} {error "ENABLE_ANGLES must be 0 or 1"}
foreach flag {ENABLE_FENCE ENABLE_BUZZER} {
    if {[set $flag] ni {0 1}} {error "$flag must be 0 or 1"}
}
set extra_generics {}
if {$OUTPUT_MODE eq "WIFI"} {
    source [file join $root scripts wifi_config.tcl]
    set extra_generics [wifi_generics $root]
    if {$CLK_HZ/double($PC_BAUD)<16} {error "ESP UART RX needs at least 16 clocks per bit"}
}
# Reject invalid user configuration before overwriting a generated project.
foreach name {CLK_HZ UWB_BAUD PC_BAUD TAG_Z_MM} {
    if {![string is integer -strict [set $name]]} {error "$name must be an integer"}
}
if {$CLK_HZ < 1000 || $UWB_BAUD <= 0 || $PC_BAUD <= 0 ||
    $CLK_HZ/double($UWB_BAUD) < 16 || $CLK_HZ/double($PC_BAUD) < 2} {
    error "Invalid clock/baud: UART RX requires at least 16 clocks per bit"
}
if {[llength $ANCHORS_MM] != 3 || abs($TAG_Z_MM) > 30000} {
    error "Three anchors and a known tag height within +/-30000mm are required"
}
foreach anchor $ANCHORS_MM {
    if {[llength $anchor] != 3} {error "Each anchor requires X Y Z in integer millimeters"}
    foreach coordinate $anchor {
        if {![string is integer -strict $coordinate] || abs($coordinate) > 30000} {
            error "Anchor coordinates must be integer millimeters within +/-30000"
        }
    }
}
set project_name mini5_fpga
set top_name uwb_top
set out [file join $root build vivado]
if {$OUTPUT_MODE eq "WIFI"} {
    set project_name mini5_fpga_wifi
    set top_name uwb_wifi_top
    set out [file join $root build vivado_wifi]
}
if {[info exists BUILD_OUTPUT_DIR]} {set out [file normalize $BUILD_OUTPUT_DIR]}
file mkdir $out
create_project -force $project_name $out -part $FPGA_PART
set_property target_language Verilog [current_project]
add_files [glob [file join $root rtl *.sv]]
set_property top $top_name [get_filesets sources_1]
set generics [list CLK_HZ=$CLK_HZ UWB_BAUD=$UWB_BAUD PC_BAUD=$PC_BAUD TAG_Z=$TAG_Z_MM ENABLE_ANGLES=$ENABLE_ANGLES ENABLE_FENCE=$ENABLE_FENCE ENABLE_BUZZER=$ENABLE_BUZZER]
for {set i 0} {$i < 3} {incr i} {
    lassign [lindex $ANCHORS_MM $i] x y z
    lappend generics X${i}=$x Y${i}=$y Z${i}=$z
}
set generics [concat $generics $extra_generics]
set_property generic [join $generics " "] [get_filesets sources_1]
set sim_top [expr {$OUTPUT_MODE eq "WIFI" ? "tb_wifi" : "tb_system"}]
add_files -fileset sim_1 [file join $root sim ${sim_top}.sv]
set_property top $sim_top [get_filesets sim_1]
set sim_generics [list ENABLE_ANGLES=$ENABLE_ANGLES ENABLE_FENCE=$ENABLE_FENCE]
if {$OUTPUT_MODE eq "WIFI"} {lappend sim_generics [lsearch -inline $extra_generics LEGACY_CUR=*]}
set_property generic [join $sim_generics " "] [get_filesets sim_1]
set_property xsim.simulate.runtime all [get_filesets sim_1]
if {$BOARD_PINS_VERIFIED} {
    set pins [list $PIN_SYS_CLK $PIN_SYS_RST_N $PIN_UWB_RX $PIN_PC_TX]
    set ports [list sys_clk sys_rst_n uwb_rx pc_tx]
    if {$OUTPUT_MODE eq "WIFI"} {
        set pins [concat $pins [list $PIN_ESP_RX $PIN_ESP_RST_N]]
        set ports [list sys_clk sys_rst_n uwb_rx esp_tx esp_rx esp_rst_n]
    }
    lappend pins $PIN_BEEP
    lappend ports beep
    if {[llength [lsort -unique $pins]] != [llength $pins] || "" in $pins} {
        error "Distinct verified package pins are required."
    }
    set xdc [file join $out board.xdc]
    set fd [open $xdc w]
    foreach port $ports pin $pins {
        puts $fd [format {set_property -dict {PACKAGE_PIN %s IOSTANDARD LVCMOS33} [get_ports %s]} $pin $port]
    }
    puts $fd [format {create_clock -name sys_clk -period %.6f [get_ports sys_clk]} [expr {1.0e9/$CLK_HZ}]]
    puts $fd {set_property PULLUP TRUE [get_ports uwb_rx]}
    # Cut only asynchronous paths into the first synchronization stages.
    puts $fd {set_false_path -from [get_ports uwb_rx] -to [get_cells -hier -filter {NAME =~ */rx_meta_reg}]}
    puts $fd {set_false_path -from [get_ports sys_rst_n]}
    puts $fd {set_false_path -to [get_ports beep]}
    # PC UART is asynchronous to the FPGA system clock.
    if {$OUTPUT_MODE eq "WIFI"} {
        puts $fd {set_property PULLUP TRUE [get_ports esp_rx]}
        puts $fd {set_false_path -from [get_ports esp_rx] -to [get_cells -hier -filter {NAME =~ */rx_meta_reg}]}
        puts $fd {set_false_path -to [get_ports {esp_tx esp_rst_n}]}
    } else {
        puts $fd {set_false_path -to [get_ports pc_tx]}
    }
    close $fd
    add_files -fileset constrs_1 $xdc
} else {
    puts "WARNING: Simulation project created. Hardware pin constraints are not verified."
}
update_compile_order -fileset sources_1
puts "Project: [file join $out ${project_name}.xpr]"
puts "Output mode: $OUTPUT_MODE"
puts "PC protocol: [expr {($ENABLE_ANGLES || $ENABLE_FENCE) ? 42 : 34}] bytes, version=[expr {$ENABLE_FENCE ? 3 : $ENABLE_ANGLES ? 2 : 1}], baud=$PC_BAUD"
puts "PC application: [file join $root shangweiji pc_upper main.py]"
