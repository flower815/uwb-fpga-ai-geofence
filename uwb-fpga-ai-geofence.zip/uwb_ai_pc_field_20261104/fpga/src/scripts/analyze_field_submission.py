"""Recompute seven-column metrics from the supplied field files, without rewriting them."""
from pathlib import Path
import csv
import json
import math
import statistics
import sys


def percentile(values, q):
    if not values:
        return None
    a = sorted(values);x = (len(a)-1)*q;i = int(x)
    return a[i] + (a[min(i+1,len(a)-1)]-a[i])*(x-i)


def analyze(root):
    root = Path(root).resolve()
    sys.path.insert(0, str(root/'host/app'))
    from uwb_pc.protocol import FrameDecoder
    metrics = [];points = [];sessions = [];pooled = []
    def add(name, category, value, unit, conditions, count, evidence):
        if value is not None:
            metrics.append([name,category,value,unit,conditions,count,evidence])
    def errors_summary(records):
        es=[math.hypot(dx,dy) for dx,dy in records]
        return dict(valid=len(es),rmse_mm=math.sqrt(statistics.mean(e*e for e in es)) if es else None,
                    mean_error_mm=statistics.mean(es) if es else None,p95_mm=percentile(es,.95),
                    p99_mm=percentile(es,.99),max_mm=max(es) if es else None,
                    x_bias_mm=statistics.mean(dx for dx,dy in records) if records else None,
                    y_bias_mm=statistics.mean(dy for dx,dy in records) if records else None)
    for p in sorted((root/'metrics/logs/known_points').glob('*.csv')):
        rows=list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
        if not rows:
            raise ValueError('Empty known point file: '+p.name)
        if any(r['source'] not in ('serial','tcp') for r in rows):
            raise ValueError('Non-live known point data: '+p.name)
        unverified=sum(r['profile_state']!='verified' for r in rows)
        truth=sorted(set(tuple(float(r[k]) for k in ('truth_x_mm','truth_y_mm','truth_z_mm')) for r in rows))
        real=[r for r in rows if r['kind']=='measurement'];pairs=[];biases=[[],[],[]]
        for r in real:
            t=tuple(float(r[k]) for k in ('truth_x_mm','truth_y_mm','truth_z_mm'))
            if int(r['status'])&0x7f==0 and int(r['mask'])&7==7 and int(r['fence_flags']) not in (32,36):
                pairs.append((float(r['x_mm'])-t[0],float(r['y_mm'])-t[1]))
            for i,a in enumerate(json.loads(r['anchors_json'])):
                if int(r['mask'])&(1<<i) and 0<float(r[f'd{i}_mm'])<=60000:
                    biases[i].append(float(r[f'd{i}_mm'])-math.dist(t,a))
        times=[float(r['received_monotonic_s']) for r in rows]
        if times!=sorted(times):raise ValueError('Nonmonotonic capture: '+p.name)
        summary=dict(file=p.name,rows=len(rows),measurements=len(real),unverified=unverified,truth_mm=truth,
                     elapsed_s=times[-1]-times[0],**errors_summary(pairs))
        points.append(summary);pooled.extend(pairs)
        cond=f"Mini5 T2;Zynq7020;TCP;50MHz为软件配置;真值{truth}mm人工填写;未核对固件{unverified}/{len(rows)};文件名标记LOS;天线实测高度/遮挡/功耗模式无独立记录"
        evidence='logs/known_points/'+p.name
        for key,unit in [('rows','帧'),('measurements','帧'),('valid','帧'),('elapsed_s','s'),('rmse_mm','mm'),
                         ('mean_error_mm','mm'),('p95_mm','mm'),('p99_mm','mm'),('max_mm','mm'),('x_bias_mm','mm'),('y_bias_mm','mm')]:
            add(p.stem+'_'+key,'已知点实测（参数未核对）',summary[key],unit,cond,len(real),evidence)
        add(p.stem+'_有效率','已知点实测（参数未核对）',len(pairs)/len(real)*100 if real else None,'%',cond,len(real),evidence)
        for i,b in enumerate(biases):
            add(p.stem+f'_d{i}_平均测距偏差','已知点实测（参数未核对）',statistics.mean(b) if b else None,'mm',cond,len(b),evidence)
            add(p.stem+f'_d{i}_测距标准差','已知点实测（参数未核对）',statistics.pstdev(b) if b else None,'mm',cond,len(b),evidence)
    aggregate=errors_summary(pooled)
    aggregate.update(rows=sum(p['rows'] for p in points),files=len(points),unique_truths=len(set(tuple(t) for p in points for t in p['truth_mm'])))
    for key in ('rmse_mm','mean_error_mm','p95_mm','p99_mm','max_mm','x_bias_mm','y_bias_mm'):
        add('五次采集合并_'+key,'已知点实测（参数未核对）',aggregate[key],'mm',
            '按有效帧数加权合并;人工填写真值;全部未核对固件;不是五个独立位置;P4/P5同真值;非测点等权平均',len(pooled),'logs/known_points/;field_summary.json')
    for folder in sorted((root/'metrics/logs/sessions').iterdir()):
        if not folder.is_dir():continue
        env=json.loads((folder/'environment.json').read_text(encoding='utf-8'))
        if env.get('source') not in ('tcp','serial'):raise ValueError('Non-live session: '+folder.name)
        events=[json.loads(s) for s in (folder/'events.jsonl').read_text(encoding='utf-8').splitlines() if s.strip()]
        stamps=[int(e['pc_ns']) for e in events]
        if stamps!=sorted(stamps):raise ValueError('Nonmonotonic events')
        actual=[e for e in events if e['event']=='inference' and e.get('probability') is not None]
        decoder=FrameDecoder();frames=[];received=0
        for e in events:
            if e['event']=='receive':
                data=bytes.fromhex(e['bytes_hex']);received+=len(data);frames.extend(decoder.feed(data))
        status_bad=sum(not v.has_position for v in frames)
        result=dict(session=folder.name,source=env['source'],events=len(events),receive_bytes=received,
                    telemetry_frames=len(frames),invalid_position_frames=status_bad,crc_errors=decoder.crc_errors,
                    format_errors=decoder.format_errors,ack_frames=len(decoder.acknowledgements),
                    unknown_inference=sum(e['event']=='inference' and e.get('probability') is None for e in events),
                    timed_inference=len(actual),event_coverage_s=(stamps[-1]-stamps[0])/1e9 if stamps else 0,
                    trial_events=sum(e['event']=='trial' for e in events),outside_report_frames=sum(v.fence_alarm for v in frames))
        result['latency']={}
        evidence='logs/sessions/'+folder.name+'/events.jsonl'
        cond=f"source={env['source']};Intel Ultra7 255HX;{env['backend']};{env['precision']};batch1;6维;Python{env['python']};model={env['model_version']};50MHz为软件配置;PC monotonic_ns;功耗模式未记录"
        for key,unit in [('receive_bytes','bytes'),('telemetry_frames','帧'),('invalid_position_frames','帧'),
                         ('crc_errors','帧'),('format_errors','次'),('unknown_inference','帧'),
                         ('event_coverage_s','s'),('outside_report_frames','帧')]:
            add(folder.name+'_'+key,'现场TCP日志统计',result[key],unit,cond,len(frames),evidence)
        for key in ('preprocess_ms','inference_ms','postprocess_ms','total_ms'):
            values=[float(e[key]) for e in actual]
            if any(not math.isfinite(v) or v<0 for v in values):raise ValueError('Invalid recorded duration')
            stats={q:percentile(values,f) for q,f in [('p50',.5),('p95',.95),('p99',.99)]}
            stats['max']=max(values) if values else None
            result['latency'][key]=stats
            for q,v in stats.items():add(folder.name+'_'+key+'_'+q,'现场PC软件处理耗时',v,'ms',cond+';只统计实际产出评分的调用;不含传感器到执行器时间',len(values),evidence)
        sessions.append(result)
    # Existing routed report values are independent of the new field CSVs.
    import re
    for mode in ('usb','wifi'):
        util=(root/f'fpga/report/ai_{mode}_utilization.rpt').read_text()
        for name,key in [('LUT','Slice LUTs'),('FF','Slice Registers'),('BRAM','Block RAM Tile'),('DSP','DSPs')]:
            m=re.search(r'\|\s*'+re.escape(key)+r'\s*\|\s*([\d.]+)',util)
            if m:add(mode+'_'+name,'既有FPGA综合实现',float(m[1]),'Tile' if name=='BRAM' else '个','xc7z020clg400-2;Vivado2020.2;Routed;50MHz;固件5.6;2026-11-01构建;功耗模式未记录','1次构建',f'../fpga/report/ai_{mode}_utilization.rpt')
        summary=json.loads((root/'fpga/report/verified_build.json').read_text(encoding='utf-8'))
        timing=next(p for p in summary['projects'] if p['mode']==mode)
        for key in ('wns_ns','whs_ns'):
            add(mode+'_'+key,'既有FPGA静态时序',timing[key],'ns','xc7z020clg400-2;50MHz;Vivado2020.2;非实板处理延迟','1次构建',f'../fpga/report/ai_{mode}_timing.rpt')
    missing=['物理端到端延迟P99：没有传感器与实际执行器同步起止记录',
             '任务闭环成功率：没有操作员任务成功/失败记录，trials.csv仅有表头',
             '现场AI准确率：没有独立且与预测时刻对齐的真实越界标签',
             'FPGA实板流水延迟：没有板内周期计数或ILA测量',
             '持续稳定运行指标：仅能报告事件覆盖时长，没有约定目标时长和完整运行起止/故障观察',
             '命令RTT/控制应答超时率：两个会话均无控制命令/ACK样本',
             '功耗/功耗模式：没有记录',
             '波形/示波器截图、XSA/HWH：未提供']
    report=dict(known_points=points,pooled=aggregate,sessions=sessions,missing=missing,
                method='线性插值分位数；总体标准差；有效XY条件与KnownPointSession一致；无效帧不删除')
    (root/'metrics/field_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    with (root/'metrics/metrics.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['指标名称','类别','数值','单位','测量条件','测试次数/时长','证据文件']);w.writerows(metrics)
    return report


if __name__=='__main__':
    result=analyze(Path(__file__).resolve().parents[2])
    print(json.dumps(result,ensure_ascii=False,indent=2))
