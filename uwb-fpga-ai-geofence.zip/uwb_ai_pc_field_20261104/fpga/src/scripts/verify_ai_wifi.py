"""Offline duplex Wi-Fi RTL checks; fictitious credentials and independent UART samples."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.protocol import FrameDecoder


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target-clock',action='store_true');parser.add_argument('--modern',action='store_true');args=parser.parse_args()
    out=ROOT/'build/ai_wifi';out.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();local_bin=ROOT/'.tools/mingw64/bin'
    if local_bin.exists():env['PATH']=str(local_bin)+os.pathsep+env['PATH']
    compiler=shutil.which('iverilog',path=env['PATH']);runtime=shutil.which('vvp',path=env['PATH'])
    if not compiler or not runtime:raise SystemExit('Icarus Verilog 12+ required')
    label='modern' if args.modern else 'legacy';label+='_50m' if args.target_clock else '_fast'
    for top in ('tb_ipd_demux','tb_ai_wifi_system'):
        compiled=out/f'{top}_{label}.vvp';capture=out/f'wifi_duplex_{label}.hex'
        cmd=[compiler,'-g2012','-s',top,'-o',str(compiled)]
        if top=='tb_ai_wifi_system':
            if args.target_clock:cmd+=['-Ptb_ai_wifi_system.CLK_HZ=50000000','-Ptb_ai_wifi_system.BAUD=115200']
            cmd+=[f'-Ptb_ai_wifi_system.LEGACY_CUR={0 if args.modern else 1}']
        cmd += [str(p) for p in sorted((ROOT/'rtl').glob('*.sv'))]+[str(ROOT/f'sim/{top}.sv')]
        subprocess.run(cmd,cwd=ROOT,env=env,check=True)
        subprocess.run([runtime,str(compiled),f'+CAPTURE={capture.as_posix()}'],cwd=ROOT,env=env,check=True)
    decoder=FrameDecoder();frames=[]
    for line in capture.read_text().splitlines():
        packet=bytes.fromhex(line)
        for i in range(0,len(packet),7):frames+=decoder.feed(packet[i:i+7])
    acks=list(decoder.acknowledgements);index={a.sequence:a for a in acks}
    assert len(frames)==3 and len(acks)==14 and decoder.crc_errors==0
    assert [v.fence_flags for v in frames]==[1,3,1]
    assert index[4].state&17==17 and index[5].state&17==16 and index[6].state&2
    assert index[8].state&4 and index[9].state&4 and index[11].state&2
    assert not index[6].state&8 and not index[11].state&8,'Wi-Fi/control faults must not drive beep'
    assert 14 not in index and index[15].state&19==0
    report={'source':'simulated_ESP_and_actual_RTL_UART','physical_network_test':False,'telemetry':len(frames),'acks':len(acks),
            'clock_hz':50000000 if args.target_clock else 2000000,'profile':label,'ip':'172.20.10.4','port':9000}
    capture.with_suffix('.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('PASS duplex Wi-Fi RTL payload -> current PC decoder:',label)


if __name__=='__main__':main()
