"""Actual learned model commands -> RTL UART -> ACK decoder, offline only."""
import argparse
import json
import os
import shutil
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.ai_model import RiskModel,risk_features
from uwb_pc.ai_control import command_packet
from uwb_pc.protocol import FrameDecoder


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--target-clock',action='store_true');args=parser.parse_args()
    out=ROOT/'build/competition_2026';out.mkdir(parents=True,exist_ok=True)
    model=RiskModel();warn=model.predict(risk_features(1.5,.15,0,-.5));safe=model.predict(risk_features(1.5,1,0,0))
    assert warn>.5 and safe<.5
    commands=command_packet(1,2,warn>=.5,0x12340002)+command_packet(1,5,safe>=.5,0x12340005)
    vector=out/'model_commands.hex';vector.write_text('\n'.join(f'{b:02x}' for b in commands),encoding='ascii')
    bin_path=ROOT/'.tools/mingw64/bin';env=os.environ.copy()
    if bin_path.exists():env['PATH']=str(bin_path)+os.pathsep+env['PATH']
    compiler=shutil.which('iverilog',path=env['PATH']);runtime=shutil.which('vvp',path=env['PATH'])
    if not compiler or not runtime:raise SystemExit('Install Icarus Verilog 12+ on PATH, or use .tools/mingw64/bin on Windows')
    image=out/('tb_ai_50m.vvp' if args.target_clock else 'tb_ai.vvp');capture=image.with_suffix('.hex')
    cmd=[compiler,'-g2012','-s','tb_ai_system','-o',str(image)]
    if args.target_clock:cmd+=['-Ptb_ai_system.CLK_HZ=50000000','-Ptb_ai_system.BAUD=115200']
    cmd += [str(p) for p in sorted((ROOT/'rtl').glob('*.sv'))]+[str(ROOT/'sim/tb_ai_system.sv')]
    subprocess.run(cmd,cwd=ROOT,env=env,check=True)
    subprocess.run([runtime,str(image),f'+CAPTURE={capture.as_posix()}',f'+MODEL_COMMANDS={vector.as_posix()}'],cwd=ROOT,env=env,check=True)
    packets=[bytes.fromhex(s) for s in capture.read_text().splitlines()]
    decoder=FrameDecoder();measurements=[]
    for packet in packets:
        for b in packet:measurements+=decoder.feed(bytes([b]))
    assert len(measurements)==3 and [m.fence_flags for m in measurements]==[1,3,1]
    acks=list(decoder.acknowledgements);assert len(acks)==11 and decoder.crc_errors==0
    index={a.sequence:a for a in acks}
    assert index[2].state&17==17 and index[5].state&17==16
    assert index[6].state&2 and index[8].state&4 and index[9].state&4
    assert not index[6].state&8,'Communication fault must not drive beep'
    assert index[4].result==1 and index[12].result==2
    report={'source':'learned_synthetic_model_to_real_rtl_simulation','physical_validation':False,
            'clock_hz':50000000 if args.target_clock else 2000000,'model_sha256':model.sha256,
            'risk_score':warn,'safe_score':safe,'telemetry_packets':len(measurements),'ack_packets':len(acks)}
    capture.with_suffix('.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('PASS learned model -> command UART -> FPGA RTL buzzer logic -> mixed ACK/V3 -> current PC decoder')


if __name__=='__main__':main()
