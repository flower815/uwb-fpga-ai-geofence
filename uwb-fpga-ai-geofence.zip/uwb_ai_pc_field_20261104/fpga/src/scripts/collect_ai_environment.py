"""Read hardware/runtime metadata. No driver installation and no automatic compliance claim."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import platform
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.ai_model import RiskModel


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--backend',choices=['native_cpu','torch_cpu','torch_rocm'],default='native_cpu')
    parser.add_argument('--rocm-package-version',help='Actual distribution/package version, not torch.version.hip')
    parser.add_argument('--require-amd',action='store_true')
    parser.add_argument('--output',type=Path,default=ROOT/'shangweiji/pc_upper/deploy/platform.local.json')
    args=parser.parse_args();model=RiskModel(args.backend)
    data={'recorded_utc':datetime.now(timezone.utc).isoformat(),'runtime':model.environment(),
          'rocm_package_version_declared':args.rocm_package_version,'rocm_version_source':'operator declaration; verify package/driver evidence',
          'competition_validation_complete':False}
    if platform.system()=='Windows':
        command="$p=Get-CimInstance Win32_Processor;$c=Get-CimInstance Win32_ComputerSystem;$g=Get-CimInstance Win32_VideoController;[ordered]@{processor=$p.Name;manufacturer=$c.Manufacturer;model=$c.Model;memory_bytes=$c.TotalPhysicalMemory;video=@($g|Select-Object Name,DriverVersion)}|ConvertTo-Json -Depth 4 -Compress"
        try:
            run=subprocess.run(['powershell','-NoProfile','-NonInteractive','-Command',command],capture_output=True,text=True,timeout=15,check=True)
            data['hardware']=json.loads(run.stdout)
        except (subprocess.SubprocessError,ValueError,OSError) as exc:data['hardware_probe_error']=str(exc)
    else:
        cpu=platform.processor()
        cpu_info=Path('/proc/cpuinfo')
        if cpu_info.exists():
            for line in cpu_info.read_text().splitlines():
                if line.startswith('model name'):
                    cpu=line.split(':',1)[1].strip();break
        data['hardware']={'processor':cpu,'memory_model_drivers':'complete from target hardware and ROCm tools'}
    if args.require_amd:
        cpu=data.get('hardware',{}).get('processor','').lower()
        if not ('amd' in cpu and 'ryzen' in cpu and 'ai' in cpu):raise SystemExit('AMD Ryzen AI PC must be verified on target hardware')
        if args.backend!='torch_rocm':raise SystemExit('Select actual ROCm backend for migration validation')
        match=re.match(r'^(\d+)\.(\d+)\.(\d+)',args.rocm_package_version or '')
        if not match or tuple(map(int,match.groups()))<(7,14,0):raise SystemExit('Guide requires declared ROCm distribution >=7.14.0; verify actual installation evidence')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    # Avoid recursively embedding the previous manifest into the next one.
    data['runtime'].pop('hardware_manifest',None)
    args.output.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print(args.output)


if __name__=='__main__':main()
