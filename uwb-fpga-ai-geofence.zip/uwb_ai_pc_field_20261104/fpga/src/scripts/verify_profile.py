"""Offline register-query UART checks. Profile frames never contain private network data."""
import binascii
import os
from pathlib import Path
import shutil
import struct
import subprocess

ROOT=Path(__file__).resolve().parents[1]


def main():
    out=ROOT/'build/reliability';out.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env['PATH']=str(ROOT/'.tools/mingw64/bin')+os.pathsep+env['PATH']
    compiler=shutil.which('iverilog',path=env['PATH']);runtime=shutil.which('vvp',path=env['PATH'])
    if not compiler or not runtime:raise SystemExit('Icarus Verilog required')
    binary=out/'tb_profile_query.vvp';capture=out/'profile_uart.hex'
    subprocess.run([compiler,'-g2012','-s','tb_profile_query','-o',str(binary),str(ROOT/'rtl/uart_rx.sv'),str(ROOT/'rtl/uart_tx.sv'),
                    str(ROOT/'rtl/ai_usb_link.sv'),str(ROOT/'rtl/uwb_profile.sv'),str(ROOT/'sim/tb_profile_query.sv')],env=env,cwd=ROOT,check=True)
    subprocess.run([runtime,str(binary),f'+CAPTURE={capture.as_posix()}'],env=env,cwd=ROOT,check=True,timeout=60)
    replies={}
    for row in capture.read_text().splitlines():
        packet=bytes.fromhex(row)
        assert len(packet)==18 and binascii.crc_hqx(packet[:16],0xffff)==int.from_bytes(packet[16:],'little')
        magic,version,opcode,sequence,state,result,token,value=struct.unpack('<2sBBHBBII',packet[:16])
        assert magic==b'\x55\xaa' and version==0x11 and token==0xabc00000+sequence
        replies[sequence]=(opcode,state,result,value)
    assert len(replies)==35 and 27 not in replies
    assert replies[1][3]==0x55574235 and replies[2][3]==0x00050006
    assert struct.unpack('<i',struct.pack('<I',replies[3][3]))[0]==-250
    assert struct.unpack('<i',struct.pack('<I',replies[9][3]))[0]==-1500
    assert replies[24][2:]==(3,0) and replies[25][2]==2 and replies[26][2]==1
    assert replies[34][1]&2 and replies[36][1]==0
    print('PASS captured 18-byte profile ACKs / independent CRC / signed values / errors / watchdog state')


if __name__=='__main__':main()
