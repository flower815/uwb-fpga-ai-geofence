"""Feed simulated ESP UART payloads through the existing PC TCP receive path."""
import argparse
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "shangweiji/pc_upper"))
from uwb_pc.protocol import FrameDecoder, Measurement, encode_measurement


def check_capture(path):
    packets = [bytes.fromhex(line) for line in path.read_text(encoding="ascii").splitlines() if line.strip()]
    expected = [Measurement(0, 7, seq, 2, (5000, 5000, 5000), (3000, 4000, 0))
                for seq in (10, 12, 13, 14, 15, 16)]
    if packets and packets[0][2] in (2,3):
        from dataclasses import replace
        expected=[replace(record,azimuth_cdeg=(5313,12687,30687),angle_valid_mask=7) for record in expected]
        if packets[0][2]==3:expected=[replace(record,fence_flags=1) for record in expected]
    assert packets == [encode_measurement(record) for record in expected]
    decoder = FrameDecoder()
    wire = b"".join(packets)
    actual = []
    for i in range(0, len(wire), 7):
        actual.extend(decoder.feed(wire[i:i + 7]))
    assert actual == expected and decoder.crc_errors == 0
    print(f"PASS Wi-Fi payload/new-host protocol: {path}, {len(actual)} packets", flush=True)
    return packets


def check_gui(packets):
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QCoreApplication, QEvent
    from uwb_pc.window import MainWindow
    app = QApplication.instance() or QApplication([])
    window = MainWindow()
    try:
        # Reuse exactly the TCP receiver signal connected by the real window.
        # Local TCP socket transport itself is separately covered by test_tcp.py.
        window.mode = "tcp"
        window.set_controls()
        for packet in packets:
            window.tcp.bytes_received.emit(packet[:5])
            window.tcp.bytes_received.emit(packet[5:])
        window.refresh_health()
        app.processEvents()
        row = window.rows[2]
        assert window.table.item(row, 0).text() == "T2"
        assert window.table.item(row, 6).text() == "3.0"
        assert window.table.item(row, 7).text() == "4.0"
        assert window.map_panel.positions[2] == (3000, 4000)
        assert window.decoder.frames_received == 6
        if packets[0][2] in (2,3):
            assert [window.angle_table.item(row,i).text() for i in range(1,4)] == ["53.13","126.87","306.87"]
        print("PASS Wi-Fi RTL payload -> TCP signal -> PC table/map", flush=True)
    finally:
        window.close()
        window.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        app.processEvents()
        app.shutdown()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", type=Path, action="append", required=True)
    parser.add_argument("--gui", action="store_true")
    args = parser.parse_args()
    for path in args.capture:
        packets = check_capture(path)
    if args.gui:
        check_gui(packets)
