source [file join [file dirname [info script]] create_ai_project.tcl]
set ai_mode [string tolower [dict get $ai_project mode]]
set ai_report_prefix [file join $root build ai_${ai_mode}]
if {[info exists AI_REPORT_PREFIX]} {set ai_report_prefix [file normalize $AI_REPORT_PREFIX]}
launch_runs synth_1 -jobs 4
wait_on_run synth_1
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {error "AI synthesis failed"}
launch_runs impl_1 -to_step route_design -jobs 4
wait_on_run impl_1
if {[get_property PROGRESS [get_runs impl_1]] ne "100%"} {error "AI implementation failed"}
open_run impl_1
report_timing_summary -file ${ai_report_prefix}_timing.rpt
report_utilization -file ${ai_report_prefix}_utilization.rpt
report_drc -file ${ai_report_prefix}_drc.rpt
foreach delay_type {max min} {
    set paths [get_timing_paths -delay_type $delay_type -max_paths 1]
    if {![llength $paths]} {error "Missing AI timing paths"}
    foreach path $paths {if {[get_property SLACK $path]<0} {error "AI timing failed"}}
}
if {[llength [get_drc_violations -filter {SEVERITY == "Error"}]]} {error "AI DRC error"}
set ai_bit [file join $root build [dict get $ai_project top].bit]
if {[info exists AI_BIT_OUTPUT]} {set ai_bit [file normalize $AI_BIT_OUTPUT]}
write_bitstream -force $ai_bit
puts "PASS AI [dict get $ai_project mode] SYNTHESIS / ROUTE / TIMING / BITSTREAM"
