"""Render the real Qt integrated AI dashboard with explicitly synthetic, correctly timed input."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
import math
from pathlib import Path
import sys
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.window import MainWindow
from uwb_pc.ui_fonts import configure_font
from uwb_pc.protocol import Measurement,encode_measurement
from uwb_pc.geofence import SITE_ANCHORS_MM


def main():
    app=QApplication([]);configure_font(app);window=MainWindow();window.resize(1580,960)
    window.scenario_box.setCurrentIndex(window.scenario_box.findData('normal'));window.mode='demo'
    window.source_label.setText('离线AI演示：合成小车轨迹与模拟应答，非真实Mini5/FPGA采样')
    window.set_controls();window.hex_check.setChecked(False);window.show()
    def push(index):
        position=(1500,650-250*index,0)
        distances=tuple(round(math.dist(position,a)) for a in SITE_ANCHORS_MM)
        window.receive_bytes(encode_measurement(Measurement(0,7,index+1,2,distances,position,(0xffff,)*3,0,1)))
        window.refresh_health()
    for i in range(3):QTimer.singleShot(100+500*i,lambda n=i:push(n))
    QTimer.singleShot(1200,lambda:window.ai.set_enabled(True))
    def save():
        window.ai_panel.refresh()
        assert window.ai.results[2][0].probability>.9
        assert window.ai.client.acks>0
        path=ROOT/'shangweiji/pc_upper/preview_ai_pc.png'
        if not window.grab().save(str(path)):raise RuntimeError('AI preview failed')
        window.ai.enabled=False;window.close();app.quit();print(path)
    QTimer.singleShot(1500,save);app.exec();app.shutdown()


if __name__=='__main__':main()
