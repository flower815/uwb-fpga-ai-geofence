"""Check RTL UART captures with shangweiji/pc_upper, optionally its Qt window.

python scripts/check_new_host.py --capture build/uart_50m.hex [--gui]
This checks simulated FPGA bytes; it does not claim a physical COM test.
"""
import argparse
from dataclasses import replace
import math
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
PC_ROOT = ROOT / "shangweiji" / "pc_upper"
sys.path.insert(0, str(PC_ROOT))
from uwb_pc.protocol import Measurement, FrameDecoder, encode_measurement


EXPECTED = [
    Measurement(1, 1, 1, 2, (328, 0, 0), (0, 0, 0)),
    Measurement(0, 7, 2, 2, (5000, 5000, 5000), (3000, 4000, 0)),
    Measurement(0, 7, 3, 2, (5000, 9849, 5000), (-3000, 4000, 0)),
    Measurement(0, 15, 5, 8, (5000, 5000, 5000), (3000, 4000, 0)),
    Measurement(2, 7, 6, 2, (0, 5000, 5000), (0, 0, 0)),
    Measurement(2, 7, 7, 2, (0xFFFFFFFF, 5000, 5000), (0, 0, 0)),
    Measurement(8, 7, 8, 2, (60000, 1, 1), (0, 0, 0)),
    Measurement(0, 7, 10, 2, (5000, 5000, 5000), (3000, 4000, 0)),
]


def read_capture(path):
    packets = [bytes.fromhex(line) for line in Path(path).read_text(encoding="ascii").splitlines() if line.strip()]
    if len(packets) != len(EXPECTED) or any(len(p) not in (34,42) for p in packets):
        raise AssertionError(f"{path}: expected eight complete V1/V2 UART packets")
    return packets


def chunks(data):
    sizes = (1, 3, 19, 2, 37, 5)
    offset = index = 0
    while offset < len(data):
        size = sizes[index % len(sizes)]
        yield data[offset:offset + size]
        offset += size
        index += 1


def check_protocol(path):
    packets = read_capture(path)
    expected=[]
    retained_alarms={}
    anchors=((0,0),(6000,0),(0,8000)) # Explicit geometry of tb_system, not site config.
    for packet,record in zip(packets,EXPECTED):
        if packet[2] in (2,3):
            if record.has_position and packet[32]:
                x,y,_=record.position_mm
                angles=tuple(round(math.degrees(math.atan2(y-ay,x-ax))*100)%36000
                             if (x,y)!=(ax,ay) else 65535 for ax,ay in anchors)
                mask=sum(1<<i for i,a in enumerate(angles) if a!=65535)
            else:angles=(65535,)*3; mask=0
            record=replace(record,azimuth_cdeg=angles,angle_valid_mask=mask)
            if packet[2]==3:
                x,y,_=record.position_mm
                if record.has_position:
                    fence=1 if x>=0 and y>=0 and x*8000+y*6000<=48000000 else 3
                    retained_alarms[record.tag_id]=(fence==3)
                else:fence=4 if retained_alarms.get(record.tag_id,False) else 0
                record=replace(record,fence_flags=fence)
        expected.append(record)
    decoder = FrameDecoder()
    records = []
    for chunk in chunks(b"noise\x55" + b"".join(packets)):
        records.extend(decoder.feed(chunk))
    assert records == expected, f"{path}: RTL/new-host field mismatch: {records!r}"
    assert decoder.crc_errors == 0 and decoder.format_errors == 0
    for packet, record in zip(packets, expected):
        assert packet == encode_measurement(record), "RTL encoding differs from the new upper computer"
    assert not records[0].has_position and records[2].position_mm[0] == -3000
    print(f"PASS new-host protocol: {path}, {len(records)} actual RTL UART packets", flush=True)
    return packets


def check_window(packets):
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QCoreApplication, QEvent
    from uwb_pc.window import MainWindow
    from uwb_pc.ui_fonts import configure_font

    app = QApplication.instance() or QApplication([])
    configure_font(app)
    window = MainWindow()
    try:
        # Use the real serial-byte signal -> receive slot -> decoder -> table/map.
        # No COM port is opened and the PC simulator is not used.
        window.mode = "serial"
        window.set_controls()
        def deliver(data):
            for chunk in chunks(data):
                window.serial.bytes_received.emit(chunk)
            # The current app coalesces map/table updates on its refresh timer.
            window.refresh_health()
            app.processEvents()
        def cell(column, tag=2):
            return window.table.item(window.rows[tag], column).text()

        deliver(packets[0])
        assert cell(3) == "0.3" and cell(4) == "—" and cell(6) == "—"
        assert cell(9) == "测距不完整"
        deliver(packets[1])
        assert cell(6) == "3.0" and cell(7) == "4.0"
        assert window.map_panel.positions[2] == (3000, 4000)
        if packets[1][2] in (2,3) and packets[1][32]:
            assert [window.angle_table.item(window.rows[2],i).text() for i in range(1,4)] == ["53.13","126.87","306.87"]
        deliver(packets[2])
        assert cell(6) == "-3.0" and window.map_panel.positions[2] == (-3000, 4000)
        for packet in packets[3:]:
            deliver(packet)
        assert cell(0, 8) == "T8" and cell(6, 8) == "3.0"
        assert window.decoder.frames_received == 8
        bad = bytearray(packets[1])
        bad[20] ^= 1
        deliver(bad)
        assert window.decoder.frames_received == 8 and window.decoder.crc_errors > 0
        assert window.map_panel.positions[2] == (3000, 4000)
        deliver(packets[2])
        assert cell(6) == "-3.0" and window.decoder.frames_received == 9
        print("PASS new-host Qt: RTL bytes via serial signal, missing/valid/negative XY, two tags, CRC recovery", flush=True)
    finally:
        window.close()
        window.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        app.processEvents()
        app.shutdown()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", type=Path, action="append", required=True)
    parser.add_argument("--gui", action="store_true")
    args = parser.parse_args()
    packets = None
    for path in args.capture:
        packets = check_protocol(path)
    if args.gui:
        check_window(packets)
