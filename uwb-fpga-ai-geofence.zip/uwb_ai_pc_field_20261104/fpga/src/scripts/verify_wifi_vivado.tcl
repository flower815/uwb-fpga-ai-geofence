# Offline synthesis/route checks with fictitious credentials. Never programs hardware.
set root [file normalize [file join [file dirname [info script]] ..]]
set WIFI_CONFIG_FILE [file join $root build wifi_test_only.tcl]
file mkdir [file dirname $WIFI_CONFIG_FILE]
set f [open $WIFI_CONFIG_FILE w]
puts $f {set WIFI_SSID {lab}}
puts $f {set WIFI_PASSWORD {secret123}}
puts $f {set WIFI_PC_IP {192.168.10.26}}
puts $f {set WIFI_PC_PORT 9000}
puts $f {set WIFI_AT_PROFILE legacy_cur}
puts $f {set WIFI_TCP_KEEPALIVE 5}
close $f
set BUILD_OUTPUT_DIR [file join $root build vivado_wifi_check]
source [file join $root scripts create_wifi_project.tcl]
launch_runs synth_1 -jobs 4
wait_on_run synth_1
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {error "Wi-Fi synthesis failed"}
launch_runs impl_1 -to_step route_design -jobs 4
wait_on_run impl_1
if {[get_property PROGRESS [get_runs impl_1]] ne "100%"} {error "Wi-Fi implementation failed"}
open_run impl_1
report_utilization -file [file join $root build wifi_utilization.rpt]
report_timing_summary -file [file join $root build wifi_timing.rpt]
report_drc -file [file join $root build wifi_drc.rpt]
foreach delay_type {max min} {
    set paths [get_timing_paths -delay_type $delay_type -max_paths 1]
    if {[llength $paths]==0} {error "Missing Wi-Fi timing paths"}
    foreach path $paths {
        if {[get_property SLACK $path]<0} {error "Wi-Fi timing failed: $delay_type"}
    }
}
puts "PASS WIFI VIVADO SYNTHESIS / ROUTE / TIMING (fictitious configuration, no bitstream exported)"
close_project
exit
