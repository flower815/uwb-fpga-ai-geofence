"""Render current-site Qt fence display using explicitly synthetic positions."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from pathlib import Path
import sys
from PySide6.QtWidgets import QApplication
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.window import MainWindow
from uwb_pc.ui_fonts import configure_font


def main():
    app=QApplication([]);configure_font(app);window=MainWindow();window.resize(1480,880)
    window.scenario_box.setCurrentIndex(window.scenario_box.findData('normal'))
    window.mode='demo';window.set_controls();window.simulator.scenario='fence'
    window.source_label.setText('3米基站布局 · 离线合成轨迹与围栏示例 · 非实物测量')
    window.hex_check.setChecked(False)
    for _ in range(3):window.simulator.tick()
    window.refresh_health();window.show();app.processEvents();window.map_panel.canvas.fit_map();app.processEvents()
    assert not window.map_panel.alarm_tags and window.tags[2][0].pending_count==1
    pending=ROOT/'shangweiji/pc_upper/preview_pending.png'
    if not window.grab().save(str(pending)):raise RuntimeError('Pending preview failed')
    for _ in range(2):window.simulator.tick()
    window.refresh_health();window.show();app.processEvents();window.map_panel.canvas.fit_map();app.processEvents()
    assert window.map_panel.alarm_tags=={2}
    path=ROOT/'shangweiji/pc_upper/preview_geofence.png'
    if not window.grab().save(str(path)):raise RuntimeError('Fence preview failed')
    window.close();app.shutdown();print(path)


if __name__=='__main__':main()
