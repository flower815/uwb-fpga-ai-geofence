"""Verify actual RTL V3 wire samples against independent site-layout references."""
import argparse
import os
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.protocol import Measurement,FrameDecoder,encode_measurement


def check_capture(path):
    expected=[]
    for i,line in enumerate((ROOT/'sim/fence_system_vectors.txt').read_text().splitlines()):
        r0,r1,r2,x,y,flags,a0,a1,a2=map(int,line.split())
        expected.append(Measurement(0,7,i+1,2,(r0,r1,r2),(x,y,0),(a0,a1,a2),7,flags))
    expected.append(Measurement(1,1,0x20,2,(328,0,0),(0,0,0),(65535,)*3,0,4))
    packets=[bytes.fromhex(line) for line in path.read_text().splitlines() if line.strip()]
    assert packets==[encode_measurement(value) for value in expected]
    wire=b'noise\x55'+b''.join(packets)
    decoder=FrameDecoder();actual=[]
    for i in range(0,len(wire),11):actual.extend(decoder.feed(wire[i:i+11]))
    assert actual==expected and decoder.crc_errors==0
    print(f'PASS geofence RTL -> PC protocol: {path}, {len(actual)} records',flush=True)
    return packets


def check_window(packets):
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QCoreApplication,QEvent
    from uwb_pc.window import MainWindow
    from uwb_pc.geofence import ALARM_COLOR
    app=QApplication.instance() or QApplication([])
    window=MainWindow()
    try:
        window.mode='serial';window.set_controls()
        for packet in packets:
            window.serial.bytes_received.emit(packet[:9]);window.serial.bytes_received.emit(packet[9:])
        window.refresh_health();app.processEvents()
        assert window.decoder.frames_received==11
        assert window.map_panel.alarm_tags=={2}
        assert '越界报警' in window.fence_label.text() and '保留' in window.fence_label.text()
        assert window.fence_event_count>=2
        red=[item for item in window.map_panel.canvas.scene().items() if item.data(0)=='trail_alarm']
        assert red and red[0].pen().color().name()==ALARM_COLOR
        assert len(window.map_panel.trails[2])>=8
        print('PASS geofence RTL -> serial signal -> alarm banner/red history/invalid-hold',flush=True)
    finally:
        window.close();window.deleteLater()
        QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents();app.shutdown()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture',type=Path,action='append',required=True)
    parser.add_argument('--gui',action='store_true')
    args=parser.parse_args()
    for path in args.capture:packets=check_capture(path)
    if args.gui:check_window(packets)
