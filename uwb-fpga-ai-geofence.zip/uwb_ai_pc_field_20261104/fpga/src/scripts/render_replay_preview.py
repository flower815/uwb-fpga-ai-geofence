"""Render the default historical replay after its real 3.688-second playback."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from pathlib import Path
import sys
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.window import MainWindow
from uwb_pc.ui_fonts import configure_font


def main():
    app=QApplication([]);configure_font(app);window=MainWindow();window.resize(1580,960)
    # Developer-only legacy replay preview; entry is absent from the normal menu.
    window.scenario_box.addItem('历史字节回放（开发验证）','history')
    window.scenario_box.setCurrentIndex(window.scenario_box.findData('history'))
    window.show();window.toggle_demo()
    def save():
        window.refresh_health();window.ai_panel.refresh();app.processEvents()
        assert window.replay.finished and window.decoder.frames_received==15
        assert window.mode=='replay' and window.tags[2][0].position_mm[2]==1000
        path=ROOT/'shangweiji/pc_upper/preview_replay.png'
        if not window.grab().save(str(path)):raise RuntimeError('Replay preview failed')
        window.close();app.quit();print(path)
    QTimer.singleShot(4100,save);app.exec();app.shutdown()


if __name__=='__main__':main()
