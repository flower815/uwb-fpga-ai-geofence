set root [file normalize [file join [file dirname [info script]] ..]]
set out [file join $root build confirm3 native_confirm]
create_project -force confirm_validation $out -part xc7z020clg400-2
add_files [glob [file join $root rtl *.sv]]
add_files -fileset sim_1 [file join $root sim tb_confirm_system.sv]
set_property top uwb_ai_top [get_filesets sources_1]
set_property top tb_confirm_system [get_filesets sim_1]
set_property xsim.simulate.runtime all [get_filesets sim_1]
update_compile_order -fileset sources_1
launch_simulation -mode behavioral
close_sim
set file [open [file join $out confirm_validation.sim sim_1 behav xsim simulate.log] r]
set content [read $file];close $file
if {[string first "PASS tb_confirm_system:" $content]<0} {error "Three-hit default AI XSim failed"}
puts "PASS VIVADO XSIM default FENCE_CONFIRM=3, AI_EARLY_BEEP=0, UART and watchdog"
close_project
exit
