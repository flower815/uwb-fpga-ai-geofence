"""Verify consecutive-three fence confirmation through actual UART to current PC decoding."""
import os
import shutil
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'shangweiji/pc_upper'))
from uwb_pc.protocol import FrameDecoder


def main():
    out=ROOT/'build/confirm3';out.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env['PATH']=str(ROOT/'.tools/mingw64/bin')+os.pathsep+env['PATH']
    compiler=shutil.which('iverilog',path=env['PATH']);runtime=shutil.which('vvp',path=env['PATH'])
    if not compiler or not runtime:raise SystemExit('Icarus Verilog required')
    for top in ('tb_fence_confirm','tb_confirm_system'):
        binary=out/f'{top}.vvp'
        subprocess.run([compiler,'-g2012','-s',top,'-o',str(binary),*[str(p) for p in sorted((ROOT/'rtl').glob('*.sv'))],str(ROOT/f'sim/{top}.sv')],env=env,check=True,cwd=ROOT)
        subprocess.run([runtime,str(binary),f'+CAPTURE={(out/"uart_confirm.hex").as_posix()}'],env=env,check=True,cwd=ROOT,timeout=120)
    decoder=FrameDecoder();records=[]
    for row in (out/'uart_confirm.hex').read_text().splitlines():
        for b in bytes.fromhex(row):records+=decoder.feed(bytes([b]))
    assert [v.fence_flags for v in records]==[1,1,1,8,1,8,16,3,4,1]
    assert [v.fence_alarm for v in records]==[False]*7+[True,True,False]
    assert records[3].pending_count==1 and records[6].pending_count==2
    assert len(decoder.acknowledgements)==1 and decoder.crc_errors==0
    print('PASS actual UART -> PC: pending1/3, pending2/3, third-only alarm, invalid hold and valid return')


if __name__=='__main__':main()
