# Match these to your core board marking and the schematics before hardware use.
set FPGA_PART xc7z020clg400-2
set CLK_HZ 50000000
set UWB_BAUD 115200
set PC_BAUD 115200
# USB/WIFI share the alarm output; WIFI is selected by create_wifi_project.tcl.
set OUTPUT_MODE USB
# Latest AI project transport is selected separately in config/ai.tcl.
# Angles or fence: 42 bytes. Fence selects V3; angles alone select V2.
# Both disabled: legacy V1 / 34 bytes.
set ENABLE_ANGLES 1
set ENABLE_FENCE 1
# Active-high onboard buzzer; set 0 for PC visual alarms only.
set ENABLE_BUZZER 1
set ANCHORS_MM {{0 0 1000} {3000 0 1000} {1500 2600 1000}}
set TAG_Z_MM 0

# Wiring preset: P1 UART2_RX -> UWB input; P1 UART2_TX -> wire to P5 pin3.
# Remove ALL P1 RS232/485 jumpers and ALL P5 PS/PL jumpers for this preset.
# All four pins and 50MHz are confirmed in the manufacturer's V2 data disk:
# 3_.../NAVIGATOR_ZYNQ_IO.xdc, lines 4, 8, 11, 35, 36 (2026-10-23).
# This preserves the original P1 -> P5 wire; it does NOT use UART3_TX/J15.
set PIN_SYS_CLK "U18"
set PIN_SYS_RST_N "N16"
set PIN_UWB_RX "K14"
set PIN_PC_TX "M15"
# WIFI only: ESP TXD -> P5 pin6/T19; ESP RST -> P5 pin5/J15 (open drain).
# Remove ALL P5 jumpers. Do not connect P5 pin4 to ESP RXD in auto-control mode.
set PIN_ESP_RX "T19"
set PIN_ESP_RST_N "J15"
set PIN_BEEP "M14"

# Source-level pin mapping verified; physical wiring still follows README.md.
set BOARD_PINS_VERIFIED 1
