# Latest AI project transport. No Wi-Fi credentials belong in this file.
set AI_OUTPUT_MODE WIFI
# New geometry gets an independent generated project; the old project may be open.
set AI_WIFI_PROJECT_DIR vivado_ai_wifi_tx_mm
set AI_USB_PROJECT_DIR vivado_ai_usb_tx_mm
set AI_RANGE_FILTER 1
set AI_FENCE_CONFIRM 3
set AI_EARLY_BEEP 0
# First trustworthy raw+filtered inside vote clears; faults stay telemetry-only.
set AI_CLEAR_HITS 1
set AI_CLEAR_MARGIN_MM 0
set AI_QUALITY_ENABLE 1
set AI_QUALITY_LIMIT_MM 200
set AI_FAULT_ENABLE 1
set AI_FAULT_TIMEOUT_MS 1000
set AI_FAULT_STARTUP_MS 3000
set AI_EXPECTED_TAG 2
