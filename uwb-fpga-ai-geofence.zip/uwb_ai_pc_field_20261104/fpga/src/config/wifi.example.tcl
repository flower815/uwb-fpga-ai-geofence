# Copy to wifi.local.tcl, edit locally, then source scripts/create_wifi_project.tcl.
# Braces keep ordinary Tcl $ and [] characters literal; never commit/share the copy.
set WIFI_SSID {YOUR_2G_WIFI}
set WIFI_PASSWORD {YOUR_PASSWORD}
# WLAN IPv4 observed on 2026-10-25; check ipconfig again if the network changes.
set WIFI_PC_IP {172.20.10.4}
set WIFI_PC_PORT 9000
# modern: SYSSTORE=0, CWMODE / CWJAP (ESP-AT 2.x).
# legacy_cur: CWMODE_CUR / CWJAP_CUR (old ESP8266 AT supporting *_CUR).
# Select from AT+GMR and that firmware's command manual; unsupported commands fail/retry.
# User's module: AT 1.2.0.0 / NONOS SDK 1.5.4.1 (2016), use *_CUR.
set WIFI_AT_PROFILE legacy_cur
# TCP keepalive (seconds). 0 disables it; idle AT+CIPSTATUS polling is still enabled.
set WIFI_TCP_KEEPALIVE 5
