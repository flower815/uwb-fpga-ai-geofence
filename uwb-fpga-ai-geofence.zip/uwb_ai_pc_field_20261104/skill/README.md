# 可复用Skill

`uwb-field-delivery/`用于Mini5、Zynq与PC侧AI项目的实测指标复算和工程交付整理。

将整个子目录提供给支持SKILL.md的工具；也可让助手直接阅读`uwb-field-delivery/SKILL.md`，并指定本次工程根目录和新数据目录。当前未安装到全局Skill目录。

调用示例：

> 使用uwb-field-delivery整理当前UWB项目。已知点CSV在指定目录，会话日志在指定目录。复算可支持的指标，保留原始数据和来源，按要求更新工程包。

只读校验：在工程根运行`python skill/uwb-field-delivery/scripts/validate_delivery.py --project .`。可再提供`--archive ../uwb_ai_pc_field_20261104.zip`检查ZIP与目录一致。

此Skill不包含固定成绩，不把本批次的两次成功自动套用到新数据；也不训练模型、部署到外部服务或烧录实板。
