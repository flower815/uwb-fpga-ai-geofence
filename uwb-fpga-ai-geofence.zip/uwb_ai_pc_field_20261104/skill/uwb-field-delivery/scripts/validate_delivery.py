"""Read-only checks for a UWB field delivery and optional matching archive."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import zipfile


def validate(root, archive=None):
    root=Path(root).resolve()
    def read(name):return json.loads((root/name).read_text(encoding='utf-8-sig'))
    def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
    manifest=read('docs/package_manifest.json')
    files=manifest['files']
    for name,digest in files.items():
        p=(root/name).resolve()
        if not p.is_relative_to(root) or not p.is_file() or sha(p)!=digest:
            raise ValueError('Manifest mismatch: '+name)
    def snapshot_file(p):
        relative=p.relative_to(root)
        if any(part in ('.git','.venv','__pycache__','.reproduce') for part in relative.parts):return False
        if any(part.startswith('generated_') for part in relative.parts):return False
        return p.is_file()
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if snapshot_file(p)}
    if actual != set(files)|{'docs/package_manifest.json'}:
        raise ValueError('Unlisted or missing files')
    for item in read('docs/source_manifest.json')['known_points']:
        for prefix in ('metrics/logs/known_points','host/app/examples/field_tests'):
            if sha(root/prefix/item['file'])!=item['sha256']:
                raise ValueError('Changed raw/replay data: '+item['file'])
    if sha(root/'host/model/risk_mlp.json')!=sha(root/'host/app/model/risk_mlp.json'):
        raise ValueError('Model copies differ')
    with (root/'metrics/metrics.csv').open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f)
        if reader.fieldnames!=['指标名称','类别','数值','单位','测量条件','测试次数/时长','证据文件']:
            raise ValueError('Unexpected metric schema')
        count=0
        for row in reader:
            if not math.isfinite(float(row['数值'])):raise ValueError('Non-finite metric')
            for reference in row['证据文件'].split(';'):
                p=(root/'metrics'/reference).resolve()
                if not p.is_relative_to(root) or not p.exists():
                    raise ValueError('Missing evidence: '+reference)
            count+=1
    if archive:
        with zipfile.ZipFile(archive) as z:
            if z.testzip():raise ValueError('ZIP CRC failure')
            members={n for n in z.namelist() if not n.endswith('/')}
            expected={root.name+'/'+n for n in actual}
            if members!=expected:raise ValueError('ZIP file inventory differs')
            for n in actual:
                if z.read(root.name+'/'+n)!=(root/n).read_bytes():
                    raise ValueError('ZIP bytes differ: '+n)
    print(f'PASS: {len(actual)} files, source/replay hashes, models, {count} metrics and evidence'+', archive'*(archive is not None))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project',required=True,type=Path);p.add_argument('--archive',type=Path)
    args=p.parse_args();validate(args.project,args.archive)
