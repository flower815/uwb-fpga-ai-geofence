# 项目映射与复现

交付目录：README.md；docs/系统、接口、硬件说明；fpga/src、build、report；host/model、app、deploy；metrics/metrics.csv、logs、scripts；skill/本Skill。设计报告或截图仅在有材料时添加，当前要求不建空目录。

当前工作工程的可变输入：`shangweiji/pc_upper/video/*.csv`、`metrics/logs/*/`。不要硬编码盘符或把目录中全部旧CSV自动混入新批次。

交付包将原始点位复制到`metrics/logs/known_points`，应用回放副本位于`host/app/examples/field_tests`；两者SHA相同。会话原件位于`metrics/logs/sessions`。`host/model/risk_mlp.json`与`host/app/model/risk_mlp.json`相同。

Python3.12，PySide6依赖见host/deploy/requirements.txt；默认native_cpu/float64。模型是6→24→12→1 MLP，预测时间和几何从实际JSON读取，不能从旧模型卡推断。AMD启动入口当前只是CPU回退，不能由此宣称GPU/NPU加速。

FPGA构建使用Vivado2020.2、50MHz、xc7z020clg400-2；这是当前项目条件，不是所有UWB项目通用要求。source fpga/build/create_project.tcl或build.tcl；Wi-Fi须填写本地模板，不能泄露网络凭据。

应用回归：`python host/app/check.py`。RTL回归：`python metrics/scripts/reproduce.py --check reliability`，需要PATH中有Icarus12+。重排路径后先做入口检查，不为了文档或Skill更新重复综合。旧固定数据回归与新数据回放检查应在说明中区分。

清单位于docs/package_manifest.json，点位原始文件SHA在docs/source_manifest.json。新增Skill或报告后更新清单，并保持ZIP与目录逐文件一致。当前批次结论留在结果文档，不固化成下一批的默认结论。
