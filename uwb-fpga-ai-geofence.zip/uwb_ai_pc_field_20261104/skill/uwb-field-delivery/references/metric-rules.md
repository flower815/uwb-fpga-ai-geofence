# 指标口径

## 已知点CSV

关键字段：`truth_x_mm/truth_y_mm/truth_z_mm`为人工真值；`x_mm/y_mm/z_mm`为FPGA输出；`d0_mm/d1_mm/d2_mm`为测距；`anchors_json`为该行记录几何。另有`source`、`profile_state`、`kind`、`status`、`mask`、`fence_flags`和PC单调接收时间。

当前版本KnownPointSession的XY有效条件：`kind=measurement`、`status & 0x7f == 0`、`mask & 7 == 7`，围栏标志非32/36十进制故障心跳。更换固件时核对协议后再沿用。无效measurement进入有效率分母；重复和心跳分别计数。文件缺少CRC原始字节时不补造CRC验证成绩。

`dx=X-truthX`、`dy=Y-truthY`、`e=sqrt(dx²+dy²)`；RMSE为`sqrt(mean(e²))`。P95/P99使用排序线性插值，方法写明；标准差使用总体标准差。每路测距偏差为该路距离减去真值到对应基站的三维欧氏距离，只统计该路MASK有效、值在协议允许范围的记录。单位毫米。

真值由操作者提供，不等于第三方认证。文件名LOS不能独立证明遮挡条件。Z是当前系统配置高度，不当作三基站测得的三维高度。跨度`last_received_monotonic-first_received_monotonic`是PC接收记录跨度。

## 会话日志

`environment.json`记录后端、精度、模型版本/SHA、软件版本和来源；嵌套旧硬件快照保留原日期，不能冒充当日采集。`events.jsonl`包含receive、position、inference及可能的command/trial事件。`trials.csv`为空表时，不从轨迹自动生成任务成功记录。

从receive的`bytes_hex`重新喂入当前FrameDecoder，可核对遥测帧、CRC和格式错误；丢包与采样序号策略需额外依据。推理分位数只针对`probability != null`且耗时非负有限的调用，按preprocess/inference/postprocess/total分别统计。事件首末跨度不是传感器采样时间，也不自动证明长期稳定运行验收。

人工确认应单独保存为`metrics/logs/operator_confirmations.json`：来源、日期、原话、对应会话、outcome和统计层级。确认只适用于列明的会话，不让未来新增会话自动继承成功。

## 必须另有证据的指标

物理E2E需要定义输入事件、实际执行器响应与同步时基；实板流水延迟需要对应帧板内起止周期；现场AI准确率需要独立真实位置/越界标签和时间对应；任务成功率需要试验定义和逐次或会话级结果；功耗与长期稳定性需要约定条件、测量及完整记录。WNS/WHS只是静态时序裕量。
