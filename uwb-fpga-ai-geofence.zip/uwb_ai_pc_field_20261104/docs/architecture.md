# 系统架构与数据流
```mermaid
flowchart LR
 A[Mini5 A0/A1/A2基站] <-->|UWB测距| T[Mini5 T2标签]
 T -->|115200 8N1 mc文本| P[Zynq7020 PL]
 P --> R[测距中值/二维毫米解算]
 R --> Q[质量/健康/水平角/三角围栏]
 Q --> B[板载蜂鸣器]
 Q --> U[USB串口 或 ESP01S双向TCP]
 U <--> H[PC上位机/原始记录/地图显示平滑]
 H --> M[本地MLP:未来0.7秒风险]
 M --> C[可选PC预警控制/ACK]
 C --> U
```
Mini5测距，PL承担确定性采集、解算、角度和本地安全判断；PC承担学习模型、UI与记录。PS/ARM未参与，无Linux/PYNQ/BD依赖。电脑离线不能解除已确认的本地越界状态。
PL：uart_rx、mini5解析、range_median_filter、trilateration_2d、CORDIC角度、triangle_geofence、质量和健康检测、FIFO、ai_usb_link、esp01s_at_link、buzzer（具体文件见fpga/src/rtl）。
三个基站是已知高度下的XY定位；Z是配置值，水平角来自XY推导。内部/发送/PC存储为整数毫米；地图单独α–β平滑和静止锁定，卡片为米一位小数，报警不使用显示坐标。连续收到三次新鲜有效越界测量报警，首次可信原始与滤波区内解除，故障仅提示。
PC默认native_cpu模型6→24 tanh→12 tanh→1 sigmoid，AI提前蜂鸣AI_EARLY_BEEP=0。启用PC联动不会覆盖本地围栏；检测双向链路只验证指令和ACK，释放PC预警只释放PC控制状态。
