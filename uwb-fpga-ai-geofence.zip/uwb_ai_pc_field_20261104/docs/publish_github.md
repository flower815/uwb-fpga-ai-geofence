# 发布到GitHub

按用户要求，本包现有内容全部纳入上传：源码、模型、USB bit、报告、实测CSV、原始日志和Skill。忽略规则不排除这些现有交付材料。本次未替用户创建仓库或上传。当前没有LICENSE，请项目权利人选择适合的许可证后再按该许可对外发布。依赖与第三方图片不自动获得项目代码的许可证；竞赛标志图片的使用和再分发授权需按其来源确认。

## GitHub Desktop步骤

1. 安装并登录GitHub Desktop。
2. File → New repository，名称例如uwb-zynq-ai-geofence。Local path选独立GitHub工作目录，避免在原Vivado开发目录内建公开仓库。许可证由团队选定；不要预设本包已经采用MIT等许可。
3. 打开新仓库文件夹，把本包内README.md、.gitignore、docs、fpga、host、metrics、skill复制进去。仓库根目录直接看到README，不仅提交ZIP，也不要再嵌套一层工程名目录。
4. 查看Changes，确认未出现wifi.local.tcl、platform.local.json、私有构建日志或Wi-Fi bit；.gitignore保留已提供的USB bit、报告和本次原始证据。
5. 填写提交说明并Commit to main。Publish repository，取消Keep this code private后发布公开仓库。
6. View on GitHub检查源码、模型、指标、五份新CSV和Skill可见。完整ZIP可另放Release。后续更新Commit后Push origin。

公开仓库包含原始实测CSV、会话日志以及用户人工成功确认，项目权利人应确认愿意公开。日志中的本机路径、设备与软件信息保留以解释复现条件。发布不等于证明现场精度或提供任何安全认证。

本包SHA清单反映当前交付快照；增加LICENSE或修改源码后，应在下一次打包时更新清单。GitHub生成的.git元数据、运行缓存及临时生成工程不属于交付快照。

官方参考：
- https://docs.github.com/en/desktop/overview/creating-your-first-repository-using-github-desktop
- https://docs.github.com/en/desktop/adding-and-cloning-repositories/adding-an-existing-project-to-github-using-github-desktop
- https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository
