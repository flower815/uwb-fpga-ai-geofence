"""第1课：程序入口。这里只创建Qt应用和主窗口，不处理串口协议。"""
import argparse
import sys
from PySide6.QtWidgets import QApplication
from uwb_pc.window import MainWindow
from uwb_pc.ui_fonts import configure_font


def main() -> int:
    parser = argparse.ArgumentParser(description="PySide6 UWB上位机：接收FPGA坐标、距离与标定地图显示")
    parser.add_argument("--demo", action="store_true", help="启动后自动回放第一份实测CSV")
    parser.add_argument("--ai", action="store_true", help="定位到主界面内的AI风险监测面板")
    parser.add_argument("--ai-backend", choices=["native_cpu", "torch_cpu", "torch_rocm"], default="native_cpu")
    args = parser.parse_args()
    application = QApplication(sys.argv[:1])
    configure_font(application)
    window = MainWindow()
    if args.ai_backend != "native_cpu":
        from uwb_pc.ai_model import RiskModel, RiskEngine
        try:
            window.ai.engine = RiskEngine(RiskModel(args.ai_backend))
        except (ImportError, RuntimeError, ValueError) as exc:
            print(f"AI backend unavailable: {exc}", file=sys.stderr)
            window.close(); application.shutdown(); return 2
    window.ai_panel.refresh()
    window.show()
    if args.demo:
        window.toggle_demo()
    if args.ai:
        window.show_ai()
    exit_code = application.exec()
    application.shutdown()
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
