"""Display-only alpha-beta tracking. Never feeds the AI model or fence decision."""
import math
import time
from collections import deque
from statistics import median


class DisplayTracker:
    def __init__(self, time_constant=.16, gap_s=1., jump_mm=1000.,
                 stationary_radius_mm=60., release_radius_mm=100.,
                 stationary_duration_s=.6, stationary_samples=3, release_duration_s=.15):
        self.time_constant=time_constant
        self.gap_s=gap_s
        self.jump_mm=jump_mm
        self.states={}
        self.stationary_radius_mm=stationary_radius_mm
        self.release_radius_mm=release_radius_mm
        self.stationary_duration_s=stationary_duration_s
        self.stationary_samples=stationary_samples
        self.release_duration_s=release_duration_s
        self.stationary={}
        self.windows={}
        self.release_candidates={}

    def reset(self, tag=None):
        for values in (self.states,self.stationary,self.windows,self.release_candidates):
            if tag is None:values.clear()
            else:values.pop(tag,None)

    def is_stationary(self,tag):return tag in self.stationary

    @staticmethod
    def _mean(points):
        return tuple(sum(p[i] for p in points)/len(points) for i in range(2))

    def _stationary_center(self,window):
        if len(window)<self.stationary_samples or window[-1][0]-window[0][0]<self.stationary_duration_s-1e-9:return None
        points=[p for _,p in window]
        center=tuple(median(p[i] for p in points) for i in range(2))
        if any(math.dist(p,center)>self.stationary_radius_mm for p in points):return None
        # Small spatial spread alone also describes slow travel. Reject a
        # displaced cluster and consistent recent movement before declaring rest.
        third=max(1,len(points)//3)
        if math.dist(self._mean(points[:third]),self._mean(points[-third:]))>30.:return None
        if len(window)>=4:
            tail=list(window)[-4:]
            steps=[tuple(b[i]-a[i] for i in range(2)) for (_,a),(_,b) in zip(tail,tail[1:])]
            coherent=all(math.hypot(*s)>=10 for s in steps) and all(sum(a[i]*b[i] for i in range(2))>0 for a,b in zip(steps,steps[1:]))
            duration=tail[-1][0]-tail[0][0]
            if coherent and duration>0 and math.dist(tail[0][1],tail[-1][1])/duration>=20.:return None
        return center

    def update(self, tag, point, now=None):
        now=time.monotonic() if now is None else now
        raw=tuple(float(v) for v in point)
        previous=self.states.get(tag)
        split=previous is None
        if previous:
            stamp,last_raw,position,velocity=previous
            elapsed=now-stamp
            split=elapsed<0 or elapsed>=self.gap_s or math.dist(raw,last_raw)>self.jump_mm
        if split:
            self.reset(tag)
            position=raw;velocity=(0.,0.)
        window=self.windows.setdefault(tag,deque(maxlen=128))
        window.append((now,raw))
        while window and now-window[0][0]>1.2+1e-9:window.popleft()
        held=self.stationary.get(tag)
        if held is not None:
            if math.dist(raw,held)>self.release_radius_mm:
                candidate=self.release_candidates.get(tag)
                if candidate:
                    start,first,count=candidate
                    # Opposite isolated outliers do not confirm one movement.
                    same_direction=sum((raw[i]-held[i])*(first[i]-held[i]) for i in range(2))>0
                    if not same_direction:candidate=None
                if candidate:
                    count+=1
                else:start,first,count=now,raw,1
                self.release_candidates[tag]=(start,first,count)
                if count>=2 and now-start>=self.release_duration_s-1e-9:
                    self.stationary.pop(tag,None);self.release_candidates.pop(tag,None)
                    window.clear();window.append((now,raw))
                    position=held;velocity=(0.,0.)
                else:
                    self.states[tag]=(now,raw,held,(0.,0.));return held,False
            else:
                self.release_candidates.pop(tag,None)
                self.states[tag]=(now,raw,held,(0.,0.));return held,False
        center=self._stationary_center(window)
        if center is not None:
            self.stationary[tag]=center
            position=center;velocity=(0.,0.)
        elif not split and raw==last_raw:
            # Repeated target coordinates must not coast past the target due
            # to the previous velocity estimate, even before stationary lock.
            position=raw;velocity=(0.,0.)
        elif not split:
            # Receive batching is not a sensor timestamp. Bound display-only dt.
            dt=max(.02,elapsed)
            alpha=1-math.exp(-dt/self.time_constant)
            beta=min(.2,alpha*alpha/2)
            prediction=tuple(p+v*dt for p,v in zip(position,velocity))
            residual=tuple(r-p for r,p in zip(raw,prediction))
            position=tuple(p+alpha*e for p,e in zip(prediction,residual))
            velocity=tuple(v+beta*e/dt for v,e in zip(velocity,residual))
        self.states[tag]=(now,raw,position,velocity)
        return position,split
