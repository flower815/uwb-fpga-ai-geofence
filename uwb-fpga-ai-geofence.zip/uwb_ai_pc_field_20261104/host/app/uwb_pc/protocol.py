"""第2课：先写不依赖Qt的协议层，再让串口和模拟器共用它。

FPGA帧：55 AA | version status mask seq tag reserved | d0 d1 d2 x y z | CRC。
V1共34字节；V2共42字节带角度；V3仍42字节并带FPGA围栏标志。
"""
from dataclasses import dataclass
from collections import deque
import struct

HEADER = b"\x55\xaa"
FRAME_SIZE = 34
FRAME = struct.Struct("<2s6B3I3iH")
FRAME_V2_SIZE = 42
FRAME_V3_SIZE = 42


@dataclass(frozen=True)
class ControlAck:
    opcode: int
    sequence: int
    state: int
    result: int
    token: int
    fpga_tick: int


def crc16_ccitt(data: bytes) -> int:
    """CCITT-FALSE：poly=1021，init=FFFF，无反射，xorout=0。"""
    result = 0xFFFF
    for value in data:
        result ^= value << 8
        for _ in range(8):
            if result & 0x8000:
                result = (result << 1) ^ 0x1021
            else:
                result <<= 1
            result &= 0xFFFF
    return result


@dataclass(frozen=True)
class Measurement:
    status: int
    mask: int
    sequence: int
    tag_id: int
    distances_mm: tuple[int, int, int]
    position_mm: tuple[int, int, int]
    azimuth_cdeg: tuple[int, int, int] | None = None
    angle_valid_mask: int = 0
    fence_flags: int | None = None

    @property
    def fence_known(self) -> bool:
        return self.has_position and self.fence_flags in (1, 3)

    @property
    def outside_fence(self) -> bool:
        return self.fence_known and self.fence_flags == 3

    @property
    def fence_alarm(self) -> bool:
        return self.outside_fence or self.fence_flags in (4,36)

    @property
    def position_fault(self) -> bool:
        return self.fence_flags in (32,36)

    @property
    def quality_untrusted(self) -> bool:
        return bool(self.status&0x10)

    @property
    def pending_count(self) -> int:
        return 1 if self.fence_flags==8 else 2 if self.fence_flags==16 else 0

    def has_azimuth(self, anchor: int) -> bool:
        return (0 <= anchor < 3 and self.has_position and self.azimuth_cdeg is not None
                and bool(self.angle_valid_mask & (1 << anchor))
                and 0 <= self.azimuth_cdeg[anchor] < 36000)

    @property
    def has_position(self) -> bool:
        # bit7只报告先前过载，不使当前解失效。
        return self.status & 0x7F == 0 and self.mask & 0x07 == 0x07 and not self.position_fault

    @property
    def description(self) -> str:
        messages = []
        flags = [(0x01, "测距不完整"), (0x02, "距离无效"),
                 (0x04, "基站参数或几何无效"), (0x08, "坐标超出范围"),
                 (0x10, "定位质量/可信状态不可用"), (0x80, "先前发生丢帧")]
        for flag, text in flags:
            if self.status & flag:
                messages.append(text)
        if self.status & 0x60:
            messages.append(f"未知错误位 {self.status & 0x60:02X}")
        if self.position_fault:
            messages.append("定位失效/等待可信测量恢复，非新增越界判定" if self.fence_flags==32 else "定位失效/等待恢复；保留已确认越界报警")
        if self.mask & 0x07 != 0x07 and not self.status & 0x01:
            messages.append("距离有效位不完整")
        if self.has_position and self.fence_flags is not None:
            messages.append(f"疑似越界 {self.pending_count}/3，暂不报警" if self.pending_count else
                            "越界报警" if self.outside_fence else "围栏内" if self.fence_known else
                            "原始/滤波结果待确认，保留报警" if self.fence_flags==4 else "围栏无法判断")
        return "；".join(messages) or "定位有效"


def encode_measurement(value: Measurement) -> bytes:
    """只供模拟器/测试构造帧；实时模式不在电脑上解算坐标。"""
    version = 3 if value.fence_flags is not None else 2 if value.azimuth_cdeg is not None else 1
    body = struct.pack("<2s6B3I3i", HEADER, version, value.status, value.mask,
                       value.sequence, value.tag_id, 0,
                       *value.distances_mm, *value.position_mm)
    if version in (2, 3):
        if not valid_angle_fields(value):
            raise ValueError("Invalid azimuth values/mask")
        if version == 3 and not valid_fence_fields(value):
            raise ValueError("Invalid fence flags")
        body += struct.pack("<BB3H", value.angle_valid_mask, value.fence_flags if version == 3 else 0, *value.azimuth_cdeg)
    elif value.angle_valid_mask:
        raise ValueError("Angle mask requires version-2 angle fields")
    return body + crc16_ccitt(body).to_bytes(2, "little")


def valid_angle_fields(value: Measurement) -> bool:
    angles = value.azimuth_cdeg
    if angles is None or len(angles) != 3 or value.angle_valid_mask & ~7:
        return False
    if not value.has_position and value.angle_valid_mask:
        return False
    return all((0 <= angle < 36000) if value.angle_valid_mask & (1 << i) else angle == 0xFFFF
               for i, angle in enumerate(angles))


def valid_fence_fields(value: Measurement) -> bool:
    return value.fence_flags in (0,1,3,4,8,16,32,36) and (value.fence_flags in (0,4,32,36) or value.has_position)


class FrameDecoder:
    """缓存任意长度字节片段，feed可返回0帧、1帧或多帧。"""
    def __init__(self):
        self.buffer = bytearray()
        self.bytes_received = 0
        self.frames_received = 0
        self.crc_errors = 0
        self.format_errors = 0
        self.acknowledgements = deque(maxlen=256)
        self.ack_count = 0

    def feed(self, chunk: bytes) -> list[Measurement]:
        self.bytes_received += len(chunk)
        self.buffer.extend(chunk)
        decoded = []
        while True:
            offset = self.buffer.find(HEADER)
            if offset == -1:
                # 帧头55 AA也可能被拆开：保留末尾的55。
                self.buffer[:] = b"\x55" if self.buffer[-1:] == b"\x55" else b""
                break
            if offset:
                del self.buffer[:offset]
            if len(self.buffer) < 3:
                break
            version = self.buffer[2]
            frame_size = 18 if version == 0x11 else FRAME_V2_SIZE if version in (2, 3) else FRAME_SIZE
            if len(self.buffer) < frame_size:
                break
            packet = bytes(self.buffer[:frame_size])
            if crc16_ccitt(packet[:-2]) != int.from_bytes(packet[-2:], "little"):
                self.crc_errors += 1
                # 只移一个字节，下一帧头可能还在缓存内。
                del self.buffer[0]
                continue
            if version == 0x11:
                _, _, opcode, sequence, state, result, token, tick = struct.unpack("<2sBBHBBII", packet[:16])
                if state & ~31 or result > (3 if opcode==3 else 2):
                    self.format_errors += 1
                else:
                    self.acknowledgements.append(ControlAck(opcode, sequence, state, result, token, tick))
                    self.ack_count += 1
                del self.buffer[:frame_size]
                continue
            values = struct.unpack("<2s6B3I3i", packet[:32])
            if values[1] not in (1, 2, 3) or values[6] != 0:
                self.format_errors += 1
                del self.buffer[:frame_size]
                continue
            azimuths, angle_mask, fence_flags = None, 0, None
            if version in (2, 3):
                angle_mask, reserved, *angles = struct.unpack("<BB3H", packet[32:40])
                azimuths = tuple(angles)
                fence_flags = reserved if version == 3 else None
                candidate = Measurement(values[2], values[3], values[4], values[5],
                                        tuple(values[7:10]), tuple(values[10:13]), azimuths, angle_mask, fence_flags)
                if ((version == 2 and reserved != 0) or not valid_angle_fields(candidate)
                        or (version == 3 and not valid_fence_fields(candidate))):
                    self.format_errors += 1
                    del self.buffer[:frame_size]
                    continue
            decoded.append(Measurement(values[2], values[3], values[4], values[5],
                                       tuple(values[7:10]), tuple(values[10:13]), azimuths, angle_mask, fence_flags))
            self.frames_received += 1
            del self.buffer[:frame_size]
        return decoded
