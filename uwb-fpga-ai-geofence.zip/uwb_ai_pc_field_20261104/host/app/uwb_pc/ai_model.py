"""Small learned risk model. No network access or GPU dependency on Intel CPU."""
from dataclasses import dataclass
from hashlib import sha256
import json
import math
from pathlib import Path
import platform
import time

from .geofence import FENCE_VERTICES_MM, SITE_ANCHORS_MM, SITE_TAG_Z_MM, AI_MARGIN_SCALE_M, AI_POSITION_BOUNDS_M, AI_MAX_VELOCITY_MPS,AI_HORIZON_S

MODEL_PATH = Path(__file__).resolve().parents[1] / "model" / "risk_mlp.json"


def risk_features(x_m, y_m, vx_mps, vy_mps):
    features = []
    vertices = [(x / 1000, y / 1000) for x, y in FENCE_VERTICES_MM]
    for a, b in zip(vertices, vertices[1:] + vertices[:1]):
        dx, dy = b[0]-a[0], b[1]-a[1]
        length = math.hypot(dx, dy)
        margin = (dx*(y_m-a[1])-dy*(x_m-a[0])) / length
        rate = (dx*vy_mps-dy*vx_mps) / length
        features.extend((margin/AI_MARGIN_SCALE_M, rate/AI_MAX_VELOCITY_MPS))
    return features


def sigmoid(value):
    return 1. / (1. + math.exp(-max(-60., min(60., value))))


class RiskModel:
    def __init__(self, backend="native_cpu", path=MODEL_PATH):
        raw = Path(path).read_bytes()
        self.metadata = json.loads(raw)
        self.sha256 = sha256(raw).hexdigest()
        if self.metadata["architecture"] != [6, 24, 12, 1]:
            raise ValueError("Unsupported model architecture")
        if (self.metadata.get("anchors_mm") != [list(p) for p in SITE_ANCHORS_MM]
                or self.metadata.get("tag_z_mm") != SITE_TAG_Z_MM
                or self.metadata.get("feature_margin_scale_m") != AI_MARGIN_SCALE_M):
            raise ValueError("AI model geometry differs from current 3m fence; load/retrain the matching model")
        if self.metadata.get('horizon_s')!=AI_HORIZON_S:
            raise ValueError('AI model prediction horizon differs from current configuration')
        self.layers = self.metadata["layers"]
        self.backend = backend
        self.torch = None
        self.device = "cpu"
        if backend == "native_cpu":
            self.precision = "float64"
        elif backend in ("torch_cpu", "torch_rocm"):
            import torch
            self.torch = torch
            if backend == "torch_rocm":
                if not torch.version.hip or not torch.cuda.is_available():
                    raise RuntimeError("ROCm PyTorch / supported AMD GPU is unavailable; no CPU fallback")
                self.device = "cuda:0"  # PyTorch HIP intentionally uses the cuda API.
            self.precision = "float32"
            self.tensors = [(torch.tensor(layer["weights"], dtype=torch.float32, device=self.device),
                             torch.tensor(layer["bias"], dtype=torch.float32, device=self.device))
                            for layer in self.layers]
        else:
            raise ValueError("Unknown inference backend")

    def predict(self, features):
        if len(features) != 6 or not all(math.isfinite(v) for v in features):
            raise ValueError("Six finite features required")
        if self.torch is None:
            value = list(features)
            for i, layer in enumerate(self.layers):
                value = [sum(a*b for a, b in zip(row, value)) + bias
                         for row, bias in zip(layer["weights"], layer["bias"])]
                value = [sigmoid(v) if i == 2 else math.tanh(v) for v in value]
            return value[0]
        torch = self.torch
        with torch.inference_mode():
            value = torch.tensor([features], dtype=torch.float32, device=self.device)
            for i, (weight, bias) in enumerate(self.tensors):
                value = value @ weight.T + bias
                value = torch.sigmoid(value) if i == 2 else torch.tanh(value)
            # item() waits for the HIP result; timed inference includes dispatch/copy.
            return float(value.item())

    def environment(self):
        info = {"backend": self.backend, "precision": self.precision, "device": self.device,
                "python": platform.python_version(), "os": platform.platform(),
                "processor": platform.processor(), "model_sha256": self.sha256,
                "model_version": self.metadata["version"], "training_source": self.metadata["training_source"],
                "fpga_clock_hz": 50000000, "batch_size": 1, "rocm": None,
                "physical_validation": False}
        if self.torch:
            # HIP runtime version is not the ROCm distribution/package version.
            info.update(torch=self.torch.__version__, hip_runtime=self.torch.version.hip)
            if self.device != "cpu":
                info["gpu"] = self.torch.cuda.get_device_name(0)
        manifest = Path(__file__).resolve().parents[1]/"deploy"/"platform.local.json"
        if manifest.exists():
            info["hardware_manifest"] = json.loads(manifest.read_text(encoding="utf-8-sig"))
        return info


@dataclass
class RiskResult:
    tag: int
    probability: float | None
    reason: str
    preprocess_ms: float = 0.
    inference_ms: float = 0.
    postprocess_ms: float = 0.
    total_ms: float = 0.


class RiskEngine:
    """Velocity from PC receive times, not synchronized sensor timestamps."""
    def __init__(self, model=None):
        self.model = model or RiskModel()
        self.history = {}

    def reset(self):
        self.history.clear()

    def process(self, measurement, now=None):
        start = time.perf_counter_ns()
        now = time.monotonic() if now is None else now
        tag = measurement.tag_id
        if not measurement.has_position:
            self.history.pop(tag, None)
            return RiskResult(tag, None, "定位无效，不能判断风险")
        x, y = (v/1000. for v in measurement.position_mm[:2])
        history = self.history.setdefault(tag, [])
        if history and (now-history[-1][0] > 2 or now <= history[-1][0]):
            history.clear()
        # Buffered frames lack reliable individual arrival intervals; do not invent a sample period.
        if history and now-history[-1][0] < .02:
            return RiskResult(tag, None, "接收间隔过短，缺少可靠采样时间")
        history.append((now, x, y)); del history[:-5]
        if len(history) < 3:
            return RiskResult(tag, None, "积累轨迹中（至少3个有效时刻）")
        mean_t = sum(v[0] for v in history)/len(history)
        variance = sum((v[0]-mean_t)**2 for v in history)
        vx = sum((t-mean_t)*px for t, px, py in history)/variance
        vy = sum((t-mean_t)*py for t, px, py in history)/variance
        xmin,xmax,ymin,ymax=AI_POSITION_BOUNDS_M
        if not (xmin <= x <= xmax and ymin <= y <= ymax and abs(vx) <= AI_MAX_VELOCITY_MPS and abs(vy) <= AI_MAX_VELOCITY_MPS):
            return RiskResult(tag, None, "超出原型训练范围，风险未知")
        features = risk_features(x, y, vx, vy)
        before = time.perf_counter_ns()
        probability = self.model.predict(features)
        after = time.perf_counter_ns()
        result = RiskResult(tag, probability, f"未来{AI_HORIZON_S:g}秒越界风险（合成训练原型）",
                            (before-start)/1e6, (after-before)/1e6)
        end = time.perf_counter_ns()
        result.postprocess_ms = (end-after)/1e6
        result.total_ms = (end-start)/1e6
        return result
