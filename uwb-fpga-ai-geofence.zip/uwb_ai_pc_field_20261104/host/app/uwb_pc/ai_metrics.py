"""Evidence files never substitute PC receive/ACK times for sensor-to-actuator times."""
import csv
import json
from pathlib import Path
import time


def percentile(values, q):
    if not values: return None
    ordered=sorted(values);index=(len(ordered)-1)*q;left=int(index);right=min(left+1,len(ordered)-1)
    return ordered[left]+(ordered[right]-ordered[left])*(index-left)


class SessionRecorder:
    def __init__(self, root, environment, source, client=None, decoder=None):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=False)
        self.start_ns=time.monotonic_ns();self.source=source;self.events=0;self.inferences=[];self.trials=[]
        self.baseline={"frames":decoder.frames_received if decoder else 0,"crc":decoder.crc_errors if decoder else 0,
                       "sent":client.sent if client else 0,"timeouts":client.timeouts if client else 0,
                       "rtt":len(client.rtt_ms) if client else 0}
        self.file=(self.root/"events.jsonl").open("w",encoding="utf-8")
        self.environment={**environment,"source":source,"clock":"PC monotonic_ns",
                          "clock_sync":"RTT uses PC clock only; sensor/actuator synchronization unavailable",
                          "end_to_end_physical_latency_measured":False}
        (self.root/"environment.json").write_text(json.dumps(self.environment,ensure_ascii=False,indent=2),encoding="utf-8")

    def record(self, kind, data):
        self.file.write(json.dumps({"event":kind,"pc_ns":time.monotonic_ns(),**data},ensure_ascii=False)+"\n")
        self.file.flush();self.events+=1
        if kind=="inference" and data.get("probability") is not None:self.inferences.append(data)

    def trial(self, outcome, note):
        if outcome not in ("success","failure","intervention"):raise ValueError("Invalid trial result")
        item={"outcome":outcome,"note":note,"source":self.source,"pc_ns":time.monotonic_ns(),
              "evidence":"operator_annotation_not_automatic_physical_measurement"}
        self.trials.append(item);self.record("trial",item)

    def export(self, client, decoder):
        duration=max((time.monotonic_ns()-self.start_ns)/1e9,1e-9)
        rows=[]
        def add(name,category,value,unit,conditions,evidence="events.jsonl"):
            rows.append([name,category,"" if value is None else value,unit,conditions,evidence])
        common=f"source={self.source}; backend={self.environment['backend']}; batch=1; see environment.json"
        for key in ("preprocess_ms","inference_ms","postprocess_ms","total_ms"):
            values=[r[key] for r in self.inferences]
            for suffix,q in (("p50",.5),("p95",.95),("p99",.99)):
                add(key+"_"+suffix,"ai_task",percentile(values,q),"ms",common)
            add(key+"_max","ai_task",max(values) if values else None,"ms",common)
        rtts=client.rtt_ms[self.baseline['rtt']:];sent=client.sent-self.baseline['sent']
        for suffix,q in (("p50",.5),("p95",.95),("p99",.99)):
            add("command_rtt_"+suffix,"communication",percentile(rtts,q),"ms","PC send queue -> matching CRC ACK; not physical action; "+common)
        add("command_rtt_max","communication",max(rtts) if rtts else None,"ms",common)
        add("command_timeout_ratio","communication",(client.timeouts-self.baseline['timeouts'])/sent if sent else None,"ratio",common)
        add("telemetry_payload_goodput","communication",(decoder.frames_received-self.baseline['frames'])*24/duration,"bytes/s","24 distance/XYZ bytes per valid frame; PC receive window; "+common)
        add("crc_rejected_frames","reliability",decoder.crc_errors-self.baseline['crc'],"count",common)
        add("session_duration","reliability",duration,"s",common)
        total=len(self.trials);success=sum(t["outcome"]=="success" for t in self.trials)
        add("task_closed_loop_success","task",success/total if total else None,"ratio","Manual complete trials; interference counts as non-success; "+common,"trials.csv")
        for suffix in ("p50","p95","p99","max"):
            add("sensor_to_physical_action_"+suffix,"physical_e2e",None,"ms","NOT MEASURED: needs synchronized sensor and actual actuator evidence", "physical_evidence_required")
        add("real_ai_accuracy","ai_task",None,"ratio","NOT MEASURED: independent labeled field test required")
        add("fpga_pipeline_latency","fpga_contribution",None,"cycles","NOT MEASURED ON BOARD: use logic analyzer/ILA evidence")
        for filename,header,values in (
            ("metrics.csv",["metric","category","value","unit","conditions","evidence"],rows),
            ("trials.csv",["outcome","note","source","pc_ns","evidence"],[list(t.values()) for t in self.trials])):
            with (self.root/filename).open("w",newline="",encoding="utf-8-sig") as f:
                writer=csv.writer(f);writer.writerow(header);writer.writerows(values)
        return self.root/"metrics.csv"

    def close(self):
        self.file.close()
