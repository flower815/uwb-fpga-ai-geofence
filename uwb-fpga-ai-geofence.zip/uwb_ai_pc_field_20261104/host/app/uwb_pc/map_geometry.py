"""地图标定：FPGA毫米坐标 → 图片像素；这里只做显示变换，不解算UWB位置。"""
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class MapTransform:
    # u = a*x + b*y + tx；v = b*x - a*y + ty。
    # 图片v向下，实际y向上；允许地图旋转，两个方向采用相同比例。
    a: float
    b: float
    tx: float
    ty: float

    def __post_init__(self):
        if not all(math.isfinite(v) for v in (self.a, self.b, self.tx, self.ty)):
            raise ValueError("标定参数必须是有限数值")
        if not 1e-9 <= math.hypot(self.a, self.b) <= 1000:
            raise ValueError("地图比例超出可用范围")

    @classmethod
    def from_points(cls, pixel0, pixel1, world0, world1):
        values = (*pixel0, *pixel1, *world0, *world1)
        if len(values) != 8 or not all(math.isfinite(v) for v in values):
            raise ValueError("每个标定点必须包含有限的X、Y坐标")
        dx, dy = world1[0] - world0[0], world1[1] - world0[1]
        du, dv = pixel1[0] - pixel0[0], pixel1[1] - pixel0[1]
        length2 = dx * dx + dy * dy
        if length2 < 1:  # 两个实际参考点至少相距1毫米。
            raise ValueError("两个实际参考点距离过近，请选择不同位置")
        if math.hypot(du, dv) < 2:
            raise ValueError("两个图片参考点至少相距2像素")
        a = (du * dx - dv * dy) / length2
        b = (du * dy + dv * dx) / length2
        return cls(a, b, pixel0[0] - a * world0[0] - b * world0[1],
                   pixel0[1] - b * world0[0] + a * world0[1])

    def world_to_pixel(self, x_mm, y_mm):
        return (self.a * x_mm + self.b * y_mm + self.tx,
                self.b * x_mm - self.a * y_mm + self.ty)

    def pixel_to_world(self, u, v):
        du, dv = u - self.tx, v - self.ty
        scale2 = self.a * self.a + self.b * self.b
        return ((self.a * du + self.b * dv) / scale2,
                (self.b * du - self.a * dv) / scale2)

    @property
    def pixels_per_metre(self):
        return math.hypot(self.a, self.b) * 1000
