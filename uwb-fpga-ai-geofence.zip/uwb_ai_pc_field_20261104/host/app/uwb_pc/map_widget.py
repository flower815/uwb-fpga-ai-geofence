"""地图、标定、基站标记、有限长度轨迹和JSON配置。"""
from collections import deque
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path

from PySide6.QtCore import Qt, Signal, QPointF, QRectF
from PySide6.QtGui import (QColor, QImage, QImageReader, QPainter, QPainterPath,
                          QPen, QPixmap, QPolygonF, QFont)
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QGraphicsView,
    QGraphicsScene, QGraphicsItemGroup, QGraphicsItem, QFileDialog, QMessageBox,
    QDialog, QDialogButtonBox, QGridLayout, QDoubleSpinBox, QCheckBox,
)
from .map_geometry import MapTransform
from .geofence import SITE_ANCHORS_MM, FENCE_VERTICES_MM, ALARM_COLOR
from .display_filter import DisplayTracker
from .coordinate_precision import centimeter_measurement,round_coordinates_mm,format_coordinate_m

MAX_PIXELS = 24_000_000
DEFAULT_ANCHORS = SITE_ANCHORS_MM
TAG_COLORS = ("#176ddb", "#bc3b81", "#008b7f", "#b9770e")
DEMO_SIZE = 250
DEMO_PIXELS_PER_METRE = 50
DEMO_GRID_MM = 100


def demo_transform(size=DEMO_SIZE):
    """Five-meter-wide template; one logical image pixel is 20 mm by default."""
    return MapTransform(size/5000.,0.,size*.1,size*.9)


def demo_image(size=DEMO_SIZE):
    """Plain square grid, 50px/m and 0.1m minor cells; preserve old scaling."""
    image = QImage(size, size, QImage.Format.Format_RGB32)
    image.fill(QColor("#f7fafc"))
    p = QPainter(image)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
    # Scale the grid and calibration together to preserve world coordinates.
    factor=size/1000.
    p.scale(factor,factor)
    # 20 drawing units = 5 image pixels = 0.1m at the default size.
    # Anchor-origin grid has one darker line each physical meter.
    for value in range(0,1001,20):
        major=(value-100)%200==0
        p.setPen(QPen(QColor('#bfcede' if major else '#e0e7ef'),2 if major else 1))
        p.drawLine(value,0,value,1000);p.drawLine(0,value,1000,value)
    p.end()
    return image


def read_map(path):
    reader = QImageReader(str(path))
    reader.setAutoTransform(True)  # 尊重手机照片的EXIF方向；标定使用显示后的图片。
    size = reader.size()
    if not size.isValid() or size.width() * size.height() > MAX_PIXELS:
        raise ValueError("无法读取图片尺寸，或图片超过2400万像素，请先缩小图片")
    image = reader.read()
    if image.isNull():
        raise ValueError("图片读取失败：" + reader.errorString())
    if image.width() * image.height() > MAX_PIXELS:
        raise ValueError("图片超过2400万像素，请先缩小图片")
    return image


def file_digest(path):
    result = hashlib.sha256()
    with open(path, "rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def validate_anchors(value):
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise ValueError("必须设置A0、A1、A2三个基站")
    result = []
    for point in value:
        if not isinstance(point, (list, tuple)) or len(point) != 3:
            raise ValueError("每个基站必须包含X、Y、Z")
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) or
               not math.isfinite(v) or abs(v) > 1e8 for v in point):
            raise ValueError("基站坐标无效，支持范围为正负100000米")
        result.append(tuple(float(v) for v in point))
    return tuple(result)


class MapCanvas(QGraphicsView):
    point_picked = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setScene(QGraphicsScene(self))
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setBackgroundBrush(QColor("#e8edf4"))
        self.setMinimumSize(380, 180)
        self.picking = False
        self.pick_points = []
        self.auto_fit = True
        self.image_rect = QRectF()
        self.overlay = None
        self.pick_items = []

    def set_image(self, image):
        self.scene().clear()
        self.overlay = None
        self.pick_items = []
        self.scene().addPixmap(QPixmap.fromImage(image))
        self.image_rect = QRectF(0, 0, image.width(), image.height())
        self.scene().setSceneRect(self.image_rect)
        self.fit_map()

    def fit_map(self):
        self.auto_fit = True
        self.fitInView(self.image_rect, Qt.AspectRatioMode.KeepAspectRatio)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self.auto_fit:
            self.fitInView(self.image_rect, Qt.AspectRatioMode.KeepAspectRatio)

    def wheelEvent(self, event):
        factor = 1.2 if event.angleDelta().y() > 0 else 1 / 1.2
        scale = self.transform().m11() * factor
        if 0.01 <= scale <= 40:
            self.auto_fit = False
            self.scale(factor, factor)
        event.accept()

    def set_picking(self, enabled):
        self.picking = enabled
        self.pick_points = []
        for item in self.pick_items:
            self.scene().removeItem(item)
        self.pick_items = []
        self.setDragMode(QGraphicsView.DragMode.NoDrag if enabled else
                         QGraphicsView.DragMode.ScrollHandDrag)
        self.viewport().setCursor(Qt.CursorShape.CrossCursor if enabled else
                                  Qt.CursorShape.OpenHandCursor)

    def mousePressEvent(self, event):
        if self.picking and event.button() == Qt.MouseButton.LeftButton:
            point = self.mapToScene(event.position().toPoint())
            if self.image_rect.contains(point):
                self.pick_points.append((point.x(), point.y()))
                marker = self.scene().addEllipse(-6, -6, 12, 12,
                    QPen(QColor("#ef4949"), 2), QColor("#fff4b0"))
                marker.setPos(point)
                marker.setZValue(10)
                marker.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
                self.pick_items.append(marker)
                self.point_picked.emit(self.pick_points[:])
            event.accept()
            return
        super().mousePressEvent(event)

    def new_overlay(self):
        if self.overlay is not None:
            self.scene().removeItem(self.overlay)
        self.overlay = QGraphicsItemGroup()
        self.scene().addItem(self.overlay)
        self.overlay.setZValue(2)
        return self.overlay


def coordinate_dialog(parent, title, labels, points,decimals=3):
    dialog = QDialog(parent)
    dialog.setWindowTitle(title)
    layout = QVBoxLayout(dialog)
    hint = QLabel("单位：米。坐标必须与FPGA采用的同一坐标系一致。\n"
                  "这些设置只用于电脑显示，不会写入FPGA。")
    layout.addWidget(hint)
    grid = QGridLayout()
    fields = []
    for column, text in enumerate(["参考点", "X / m", "Y / m", "Z / m"][:len(points[0])+1]):
        grid.addWidget(QLabel(text), 0, column)
    for row, (label, point) in enumerate(zip(labels, points), 1):
        grid.addWidget(QLabel(label), row, 0)
        row_fields = []
        for column, value in enumerate(point, 1):
            field = QDoubleSpinBox()
            field.setRange(-100000, 100000)
            field.setDecimals(decimals)
            field.setSingleStep(.1)
            field.setValue(value / 1000)
            grid.addWidget(field, row, column)
            row_fields.append(field)
        fields.append(row_fields)
    layout.addLayout(grid)
    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
    buttons.accepted.connect(dialog.accept)
    buttons.rejected.connect(dialog.reject)
    layout.addWidget(buttons)
    if dialog.exec() != QDialog.DialogCode.Accepted:
        return None
    return tuple(tuple(field.value()*1000 for field in row) for row in fields)


class MapPanel(QWidget):
    message = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.map_path = None
        self.map_digest = None
        self.map_size = (DEMO_SIZE, DEMO_SIZE)
        self.calibration = None
        self.anchors = DEFAULT_ANCHORS
        self.trails = {}  # {标签ID: deque[(x_mm,y_mm)]}；最多500点/标签。
        self.trail_alarms = {}  # 与轨迹点一一对应；越界历史不因返回安全区而变绿。
        self.raw_trails = {}
        self.trail_breaks = {}
        self.display_positions = {}
        self.tracker = DisplayTracker()
        self.alarm_tags = set()
        self.pending_counts = {}
        self.fault_tags = set()
        self.positions = {}
        self.history_replay = False
        self.replay_geometry_matches = False
        self.replay_anchors = None
        self.states = {}
        self.outside_tags = []
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        line = QHBoxLayout()
        self.import_button = QPushButton("导入地图")
        self.calibrate_button = QPushButton("两点标定")
        self.cancel_button = QPushButton("取消标定")
        self.cancel_button.setVisible(False)
        self.fit_button = QPushButton("适应窗口")
        for button in [self.import_button, self.calibrate_button, self.cancel_button, self.fit_button]:
            line.addWidget(button)
        layout.addLayout(line)
        second = QHBoxLayout()
        self.anchors_button = QPushButton("基站坐标")
        self.save_button = QPushButton("保存配置")
        self.load_button = QPushButton("载入配置")
        self.clear_button = QPushButton("清空轨迹")
        for button in [self.anchors_button, self.save_button, self.load_button, self.clear_button]:
            second.addWidget(button)
        layout.addLayout(second)
        filters = QHBoxLayout()
        self.restore_site_button = QPushButton("恢复当前3米布局")
        self.restore_site_button.setToolTip("恢复当前基站显示坐标并清空轨迹，不解除报警。示例图恢复3米标定；自定义地图保留标定，需按现场尺寸核对。此按钮不修改开发板。")
        self.smooth_check = QCheckBox("显示平滑（α–β）")
        self.smooth_check.setChecked(True)
        self.smooth_check.setToolTip("地图平滑包含静止锁定：至少3点、持续0.6秒，在约6厘米范围内且无明显移动趋势时固定显示；连续偏离锁定点超过10厘米后恢复。仅影响地图，取消可查看原始毫米接收轨迹。AI/报警不受影响。间隔≥1秒或跳变>1米时分段。")
        filters.addWidget(self.restore_site_button)
        filters.addWidget(self.smooth_check)
        self.smooth_check.hide()
        filters.addStretch()
        layout.addLayout(filters)
        self.restore_site_button.clicked.connect(self.restore_site)
        self.smooth_check.toggled.connect(self.redraw)
        self.info = QLabel()
        self.info.setWordWrap(True)
        layout.addWidget(self.info)
        self.canvas = MapCanvas()
        layout.addWidget(self.canvas, 1)
        self.hint = QLabel("绿色三角形为安全区域 · 红色轨迹为报警段 · 显示平滑不参与报警/AI · 间隔≥1秒或跳变>1米时分段 · 滚轮缩放/拖动平移")
        self.live_hint = self.hint.text()
        self.hint.setWordWrap(True)
        layout.addWidget(self.hint)
        self.import_button.clicked.connect(self.choose_image)
        self.calibrate_button.clicked.connect(self.begin_calibration)
        self.cancel_button.clicked.connect(self.cancel_calibration)
        self.fit_button.clicked.connect(self.canvas.fit_map)
        self.anchors_button.clicked.connect(self.edit_anchors)
        self.save_button.clicked.connect(self.choose_save)
        self.load_button.clicked.connect(self.choose_load)
        self.clear_button.clicked.connect(self.clear_trails)
        self.canvas.point_picked.connect(self.pick_reference)
        self.canvas.set_image(demo_image())
        self.calibration = demo_transform()
        self.redraw()
        self.update_info()

    def update_info(self):
        name = Path(self.map_path).name if self.map_path else "方格地图"
        grid=' · 小格0.1米／1米10格' if not self.map_path else ''
        scale=f' · {self.calibration.pixels_per_metre:.2f} 像素/米' if self.calibration else ''
        if self.history_replay:
            geometry='CSV基站/高度匹配，显示记录围栏' if self.replay_geometry_matches else '显示CSV原基站/围栏，与当前布局不同，当前AI不重算' if self.has_replay_geometry else '原基站参数未核对'
            self.info.setText(f'{name}{scale}{grid} · 保留记录XYZ毫米值 · {geometry}')
            return
        if self.calibration:
            state = f"已标定 · {self.calibration.pixels_per_metre:.2f} 像素/米"
        else:
            state = "待标定：仅显示底图，暂不绘制标签与基站"
        outside = " · 图外标签：" + ", ".join(f"T{n}" for n in self.outside_tags) if self.outside_tags else ""
        mismatch = any(abs(a-b)>1e-6 for anchor,expected in zip(self.anchors,SITE_ANCHORS_MM)
                       for a,b in zip(anchor,expected))
        warning = " · 基站显示与本次围栏参数不一致，请核对FPGA配置" if mismatch else ""
        self.info.setText(f"{name} · {state}{grid} · 当前布局：约3米／安装坐标0.1米／基站高1米／标签高0米{outside}{warning}")

    def load_image(self, path):
        # 全部验证成功后才替换，损坏图片不影响原地图。
        path = str(Path(path).resolve())
        image = read_map(path)
        digest = file_digest(path)
        self.cancel_calibration()
        self.map_path, self.map_digest = path, digest
        self.map_size = (image.width(), image.height())
        self.calibration = None  # 新地图绝不沿用旧地图比例。
        self.canvas.set_image(image)
        self.redraw()
        self.update_info()

    def choose_image(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入平面图", "", "图片 (*.png *.jpg *.jpeg *.bmp)")
        if path:
            try:
                self.load_image(path)
                self.message.emit("地图已导入，请用两个已知位置完成标定。")
            except (OSError, ValueError) as exc:
                QMessageBox.warning(self, "地图导入失败", str(exc))

    def begin_calibration(self):
        self.canvas.set_picking(True)
        self.calibrate_button.setEnabled(False)
        self.cancel_button.setVisible(True)
        self.info.setText("标定 1/2：在地图上单击第一个已知位置（例如A0）")

    def cancel_calibration(self):
        self.canvas.set_picking(False)
        self.calibrate_button.setEnabled(True)
        self.cancel_button.setVisible(False)
        self.update_info()

    def pick_reference(self, points):
        if len(points) == 1:
            self.info.setText("标定 2/2：单击第二个已知位置（尽量选较远处，例如A1）")
            return
        # 模态对话框期间阻止第三次选择；读取完成再移除参考点。
        self.canvas.picking = False
        world = coordinate_dialog(self, "输入两个参考点的FPGA坐标", ("第1点", "第2点"),
                                  (self.anchors[0][:2], self.anchors[1][:2]))
        try:
            if world is not None:
                self.calibration = MapTransform.from_points(points[0], points[1], world[0], world[1])
                self.message.emit("地图标定完成；只变换显示坐标，不改变FPGA解算。")
        except ValueError as exc:
            QMessageBox.warning(self, "标定失败", str(exc))
        finally:
            self.cancel_calibration()
            self.redraw()

    def edit_anchors(self):
        points = coordinate_dialog(self, "基站坐标（米，一位小数；只用于显示）", ("A0", "A1", "A2"), self.anchors,decimals=1)
        if points is not None:
            self.anchors = validate_anchors(points)
            self.redraw()

    def restore_site(self):
        self.anchors = SITE_ANCHORS_MM
        if not self.map_path:
            self.canvas.set_image(demo_image())
            self.map_size = (DEMO_SIZE,DEMO_SIZE)
            self.calibration = demo_transform()
        self.clear_trails()

    def accept_measurement(self, measurement, redraw=True):
        measurement=centimeter_measurement(measurement)
        tag = measurement.tag_id
        if measurement.position_fault:self.fault_tags.add(tag)
        else:self.fault_tags.discard(tag)
        if measurement.pending_count:self.pending_counts[tag]=measurement.pending_count
        else:self.pending_counts.pop(tag,None)
        was_alarm = tag in self.alarm_tags
        self.states[tag] = "valid" if measurement.has_position else "invalid"
        if measurement.fence_alarm:
            self.alarm_tags.add(tag)
        elif measurement.fence_known:
            self.alarm_tags.discard(tag)
        if was_alarm != (tag in self.alarm_tags):self.tracker.reset(tag)
        if measurement.has_position:
            position = tuple(measurement.position_mm[:2])
            self.positions[tag] = position
            display,split = self.tracker.update(tag,position)
            display=round_coordinates_mm(display)
            self.display_positions[tag] = display
            trail = self.trails.setdefault(tag, deque(maxlen=500))
            raw = self.raw_trails.setdefault(tag, deque(maxlen=500))
            breaks = self.trail_breaks.setdefault(tag, deque(maxlen=500))
            alarms = self.trail_alarms.setdefault(tag, deque(maxlen=500))
            alarm = tag in self.alarm_tags
            if not raw or raw[-1] != position or trail[-1] != display or alarms[-1] != alarm or split:
                trail.append(display)
                raw.append(position)
                breaks.append(split)
                alarms.append(alarm)
        else:
            self.tracker.reset(tag)
        if redraw:
            self.redraw()

    @property
    def has_replay_geometry(self):
        return self.replay_geometry_matches or self.replay_anchors is not None

    @property
    def display_anchors(self):
        if self.history_replay and self.replay_anchors is not None:return self.replay_anchors
        return SITE_ANCHORS_MM if self.history_replay and self.replay_geometry_matches else self.anchors

    def set_stale(self, tag, stale, valid, redraw=True):
        if stale or not valid:self.tracker.reset(tag)
        state = "stale" if stale else ("valid" if valid else "invalid")
        if self.states.get(tag) != state:
            self.states[tag] = state
            if redraw:
                self.redraw()
            return True
        return False

    def clear_session(self):
        self.fault_tags.clear()
        self.pending_counts.clear()
        self.trails.clear()
        self.trail_alarms.clear()
        self.raw_trails.clear()
        self.trail_breaks.clear()
        self.display_positions.clear()
        self.tracker.reset()
        self.alarm_tags.clear()
        self.positions.clear()
        self.states.clear()
        self.redraw()

    def clear_trails(self):
        self.trails.clear()
        self.trail_alarms.clear()
        self.raw_trails.clear()
        self.trail_breaks.clear()
        self.tracker.reset()
        self.redraw()

    def redraw(self):
        group = self.canvas.new_overlay()
        self.outside_tags = []
        transform = self.calibration
        if transform is None:
            if not self.canvas.picking:
                self.update_info()
            return
        scene = self.canvas.scene()

        def label(text, x, y, color):
            item = scene.addSimpleText(text, QFont("Microsoft YaHei UI", 10))
            item.setBrush(QColor(color))
            item.setPos(x+12, y-24)
            item.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
            group.addToGroup(item)

        if not self.history_replay or self.has_replay_geometry:
            vertices=tuple(p[:2] for p in self.display_anchors) if self.history_replay else FENCE_VERTICES_MM
            polygon = QPolygonF([QPointF(*transform.world_to_pixel(*p)) for p in vertices])
            fence_pen = QPen(QColor("#258b65"), 2)
            fence_pen.setCosmetic(True)
            fence_item = scene.addPolygon(polygon, fence_pen, QColor(37,139,101,24))
            fence_item.setData(0,"geofence")
            coordinates="、".join(f"A{i}({format_coordinate_m(x)},{format_coordinate_m(y)})" for i,(x,y) in enumerate(vertices))
            fence_item.setToolTip(f"安全区域：{coordinates}米；边界视为安全。报警状态由FPGA上报。")
            group.addToGroup(fence_item)

        origin = transform.world_to_pixel(0, 0)
        for name, point in [("+X", (1000, 0)), ("+Y", (0, 1000))]:
            end = transform.world_to_pixel(*point)
            if all(self.canvas.image_rect.contains(QPointF(*p)) for p in (origin, end)):
                pen = QPen(QColor("#7086a8"), 1)
                pen.setCosmetic(True)
                item = scene.addLine(*origin, *end, pen)
                group.addToGroup(item)
                label(name, *end, "#617b9e")
        for index, (x, y, _) in enumerate(() if self.history_replay and not self.has_replay_geometry else self.display_anchors):
            u, v = transform.world_to_pixel(x, y)
            if not self.canvas.image_rect.contains(QPointF(u, v)):
                continue
            triangle = scene.addPolygon(QPolygonF([QPointF(0, -9), QPointF(-8, 7), QPointF(8, 7)]),
                QPen(QColor("#bd6716")), QColor("#ed9c3a"))
            triangle.setPos(u, v)
            triangle.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
            group.addToGroup(triangle)
            label(f"A{index}", u, v, "#9d5618")
        for tag, position in self.positions.items():
            if self.smooth_check.isChecked():position=self.display_positions.get(tag,position)
            normal_color = TAG_COLORS[tag % len(TAG_COLORS)] if self.states.get(tag) == "valid" else "#8d98a5"
            color = ALARM_COLOR if tag in self.alarm_tags else "#c66a00" if tag in self.fault_tags else "#b7791f" if tag in self.pending_counts else normal_color
            points = list((self.trails if self.smooth_check.isChecked() else self.raw_trails).get(tag, ()))
            breaks = list(self.trail_breaks.get(tag, ()))
            alarms = list(self.trail_alarms.get(tag, ()))
            if points:
                paths = [QPainterPath(),QPainterPath()]
                # Keep isolated history points visible without drawing a false bridge.
                for i,point in enumerate(points):
                    if i==0 or breaks[i]:
                        x,y=transform.world_to_pixel(*point)
                        path=paths[int(alarms[i])]
                        path.moveTo(x,y);path.lineTo(x+.01,y)
                for i in range(1,len(points)):
                    if breaks[i]:continue
                    alarm_segment = bool(alarms[i-1] or alarms[i])
                    path = paths[int(alarm_segment)]
                    path.moveTo(*transform.world_to_pixel(*points[i-1]))
                    path.lineTo(*transform.world_to_pixel(*points[i]))
                for index,path in enumerate(paths):
                    if path.isEmpty():continue
                    pen = QPen(QColor(ALARM_COLOR if index else normal_color), 3 if index else 2)
                    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
                    pen.setCosmetic(True)
                    item = scene.addPath(path, pen)
                    item.setData(0,"trail_alarm" if index else "trail_normal")
                    group.addToGroup(item)
            u, v = transform.world_to_pixel(*position)
            if not self.canvas.image_rect.contains(QPointF(u, v)):
                self.outside_tags.append(tag)
                continue  # 不把超出地图的点钳制到边缘伪造位置。
            marker = scene.addEllipse(-7, -7, 14, 14, QPen(QColor("white"), 2), QColor(color))
            marker.setPos(u, v)
            marker.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
            raw=self.positions[tag]
            display_state='静止锁定（仅显示）' if self.smooth_check.isChecked() and self.tracker.is_stationary(tag) else '运动平滑' if self.smooth_check.isChecked() else '接收坐标'
            marker.setToolTip(f"T{tag} 显示：X={format_coordinate_m(position[0])}m，Y={format_coordinate_m(position[1])}m；接收坐标：X={format_coordinate_m(raw[0])}m，Y={format_coordinate_m(raw[1])}m；{display_state}。报警使用FPGA内部毫米坐标判定后的状态。")
            group.addToGroup(marker)
            suffix = "" if self.states.get(tag) == "valid" else " 最后有效"
            if self.smooth_check.isChecked() and self.tracker.is_stationary(tag):suffix+=' 显示锁定'
            if tag in self.alarm_tags:suffix += " 越界报警"
            elif tag in self.fault_tags:suffix += " 定位失效（最后有效位置）"
            elif tag in self.pending_counts:suffix += f" 疑似越界{self.pending_counts[tag]}/3"
            label(f"T{tag}{suffix}", u, v, color)
        if not self.canvas.picking:
            self.update_info()

    def save_config(self, path):
        if self.canvas.picking:
            raise ValueError("请先完成或取消标定")
        if self.calibration is None:
            raise ValueError("请先完成地图标定，再保存配置")
        target = Path(path).resolve()
        image_path = None
        if self.map_path:
            if file_digest(self.map_path) != self.map_digest:
                raise ValueError("底图文件已改变，请重新导入并标定")
            try:
                image_path = os.path.relpath(self.map_path, target.parent)
            except ValueError:  # 跨盘使用绝对路径。
                image_path = self.map_path
        data = {"version": 1, "image": image_path, "sha256": self.map_digest,
                "image_size": list(self.map_size), "transform": asdict(self.calibration),
                "anchors_mm": self.anchors}
        # 原子替换，写入失败不会截断已有配置。
        temporary = target.with_name(target.name + ".tmp")
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(target)

    def load_config(self, path):
        source = Path(path).resolve()
        if source.stat().st_size > 100_000:
            raise ValueError("配置文件过大")
        data = json.loads(source.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or data.get("version") != 1:
            raise ValueError("不支持的配置格式")
        transform = data.get("transform")
        if not isinstance(transform, dict) or set(transform) != {"a", "b", "tx", "ty"}:
            raise ValueError("缺少地图标定参数")
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) for v in transform.values()):
            raise ValueError("标定参数必须是数值")
        calibration = MapTransform(**transform)
        anchors = validate_anchors(data.get("anchors_mm"))
        name = data.get("image")
        if name is None:
            # Old built-in templates were 1000px with a 200px/m calibration.
            # Keep their geometry when an old saved configuration is loaded.
            size=1000 if data.get('image_size')==[1000,1000] else DEMO_SIZE
            image, map_path, digest = demo_image(size), None, None
        elif isinstance(name, str) and name:
            map_path = str((source.parent / name).resolve())
            digest = file_digest(map_path)
            if digest != data.get("sha256"):
                raise ValueError("地图文件已变动，不能套用旧标定；请重新导入并标定")
            image = read_map(map_path)
        else:
            raise ValueError("配置中的地图路径无效")
        size = (image.width(), image.height())
        if list(size) != data.get("image_size"):
            raise ValueError("图片尺寸与标定配置不一致")
        # 到此全部验证完成，再一次性提交；错误配置不改变当前地图。
        self.cancel_calibration()
        self.map_path, self.map_digest, self.map_size = map_path, digest, size
        self.calibration, self.anchors = calibration, anchors
        self.canvas.set_image(image)
        self.redraw()

    def choose_save(self):
        path, _ = QFileDialog.getSaveFileName(self, "保存地图配置", "map_config.json", "配置 (*.json)")
        if path:
            try:
                self.save_config(path)
                self.message.emit("地图路径、标定和基站坐标已保存：" + path)
            except (OSError, ValueError) as exc:
                QMessageBox.warning(self, "保存失败", str(exc))

    def choose_load(self):
        path, _ = QFileDialog.getOpenFileName(self, "载入地图配置", "", "配置 (*.json)")
        if path:
            try:
                self.load_config(path)
                self.message.emit("地图配置已载入：" + path)
            except (OSError, ValueError, TypeError, OverflowError) as exc:
                QMessageBox.warning(self, "载入失败", str(exc))
