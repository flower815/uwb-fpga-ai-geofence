"""Single-window Qt dashboard: map tools, positioning, and local AI supervision."""
import time
from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap,QPainter,QColor
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QComboBox, QGroupBox, QTableWidget, QHeaderView, QPlainTextEdit,
    QSplitter, QCheckBox, QSpinBox, QScrollArea, QToolButton, QSizePolicy,
)
from .map_widget import MapPanel
from .coordinate_precision import format_coordinate_m
from .history_replay import FIELD_DATASETS


class DashboardBackground(QWidget):
    """Paint the competition mark into the shared window background."""
    def __init__(self):
        super().__init__()
        self.watermark=QPixmap(str(Path(__file__).resolve().parents[1]/'assets/competition_watermark.png'))

    def paintEvent(self,event):
        painter=QPainter(self)
        painter.fillRect(self.rect(),QColor('#f1f6fc'))
        if not self.watermark.isNull():
            mark=self.watermark.scaled(max(1,self.width()-24),92,Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            # Multiply blends the original white paper into the blue background.
            # The mark is part of this widget's paint, with no image child/card.
            painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_Multiply)
            painter.setOpacity(.85)
            painter.drawPixmap((self.width()-mark.width())//2,6,mark)
        painter.end()


def card(title):
    box=QGroupBox(title)
    layout=QVBoxLayout(box);layout.setContentsMargins(12,20,12,12);layout.setSpacing(8)
    return box,layout


def scroll(widget):
    area=QScrollArea();area.setWidgetResizable(True);area.setFrameShape(QScrollArea.Shape.NoFrame)
    area.setWidget(widget);area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    return area


def table(headers):
    result=QTableWidget(0,len(headers));result.setHorizontalHeaderLabels(headers)
    result.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    result.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
    result.verticalHeader().setVisible(False);result.setAlternatingRowColors(True)
    result.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    result.horizontalHeader().setMinimumSectionSize(45)
    return result


def build_dashboard(w):
    root=DashboardBackground();layout=QVBoxLayout(root);layout.setContentsMargins(12,106,12,6);layout.setSpacing(8)
    heading=QHBoxLayout()
    title=QLabel('●  UWB 定位上位机');title.setObjectName('title');heading.addWidget(title)
    heading.addStretch()
    w.source_label=QLabel('未连接 · 等待数据源');w.source_label.setObjectName('source')
    w.source_label.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Preferred)
    heading.addWidget(w.source_label,1)
    layout.addLayout(heading)

    connection=QWidget();connection.setObjectName('connectionBar');line=QHBoxLayout(connection)
    line.setContentsMargins(10,6,10,6);line.setSpacing(7)
    line.addWidget(QLabel('串口'))
    w.port_box=QComboBox();w.port_box.setMinimumWidth(150);w.port_box.setMaximumWidth(215)
    line.addWidget(w.port_box,1)
    w.baud_box=QComboBox()
    for baud in (115200,230400,460800):w.baud_box.addItem(str(baud),baud)
    line.addWidget(w.baud_box)
    w.refresh_button=QPushButton('刷新');w.refresh_button.clicked.connect(w.refresh_ports);line.addWidget(w.refresh_button)
    w.connect_button=QPushButton('连接串口');w.connect_button.setObjectName('primary')
    w.connect_button.clicked.connect(w.toggle_serial);line.addWidget(w.connect_button)
    line.addSpacing(10);line.addWidget(QLabel('Wi-Fi / TCP'))
    w.tcp_port=QSpinBox();w.tcp_port.setRange(1,65535);w.tcp_port.setValue(9000);line.addWidget(w.tcp_port)
    w.tcp_button=QPushButton('开始TCP监听');w.tcp_button.clicked.connect(w.toggle_tcp);line.addWidget(w.tcp_button)
    line.addStretch()
    w.demo_button=QPushButton('启动测试');w.demo_button.clicked.connect(w.toggle_demo);line.addWidget(w.demo_button)
    w.scenario_box=QComboBox();w.scenario_box.setMaximumWidth(220);w.scenario_box.view().setMinimumWidth(350)
    w.scenario_box.addItem('实测数据a','normal')
    for i,(key,path) in enumerate(FIELD_DATASETS.items(),1):
        w.scenario_box.addItem(f'实测数据{i}',key)
        w.scenario_box.setItemData(w.scenario_box.count()-1,str(path),Qt.ItemDataRole.ToolTipRole)
    w.scenario_box.setCurrentIndex(w.scenario_box.findData('field0'))
    w.scenario_box.currentIndexChanged.connect(w.change_scenario);line.addWidget(w.scenario_box)
    layout.addWidget(connection)

    w.main_splitter=QSplitter(Qt.Orientation.Vertical)
    w.workspace_splitter=QSplitter(Qt.Orientation.Horizontal)
    w.map_panel=MapPanel();w.map_panel.message.connect(w.write_log)
    # Reuse the real calibration / map actions; move their widgets out of the
    # old horizontal toolbar into a narrow sidebar without duplicating state.
    left=QWidget();left_layout=QVBoxLayout(left);left_layout.setContentsMargins(0,0,0,0);left_layout.setSpacing(8)
    controls,tools=card('地图与标定')
    for _ in range(3):
        item=w.map_panel.layout().takeAt(0)
        old=item.layout()
        while old.count():old.takeAt(0)
        old.deleteLater()
    grid=QGridLayout()
    buttons=[w.map_panel.import_button,w.map_panel.calibrate_button,w.map_panel.save_button,
             w.map_panel.load_button,w.map_panel.fit_button,w.map_panel.clear_button]
    for i,button in enumerate(buttons):grid.addWidget(button,i//2,i%2)
    w.map_panel.import_button.setObjectName('primary')
    tools.addLayout(grid);tools.addWidget(w.map_panel.cancel_button)
    hint=QLabel('两点建立实际坐标系\n右为 +X，上为 +Y；长度单位：米\n默认50像素/米 · 小格0.1米 · 每米10格')
    hint.setObjectName('muted');hint.setWordWrap(True);tools.addWidget(hint)
    w.map_panel.smooth_check.hide()
    zoom=QHBoxLayout()
    for text,factor in [('放大',1.2),('缩小',1/1.2)]:
        button=QPushButton(text)
        button.clicked.connect(lambda checked=False,f=factor:zoom_map(w,f));zoom.addWidget(button)
    tools.addLayout(zoom);left_layout.addWidget(controls)

    anchors,anchor_layout=card('基站坐标 / m')
    w.anchor_labels=[]
    for i in range(3):
        label=QLabel();label.setObjectName('anchorRow');w.anchor_labels.append(label);anchor_layout.addWidget(label)
    anchor_layout.addWidget(w.map_panel.anchors_button);anchor_layout.addWidget(w.map_panel.restore_site_button)
    known=QPushButton('已知点误差统计 / CSV回放');known.clicked.connect(w.show_known_points)
    anchor_layout.addWidget(known);left_layout.addWidget(anchors)

    quality,quality_layout=card('开发板与定位质量')
    w.profile_label=QLabel('开发板参数尚未核对；接收监测继续，AI控制未授权');w.profile_label.setWordWrap(True)
    quality_layout.addWidget(w.profile_label)
    w.profile_button=QPushButton('核对开发板参数');w.profile_button.clicked.connect(w.check_profile)
    quality_layout.addWidget(w.profile_button)
    w.quality_label=QLabel('定位质量：等待可信测量。');w.quality_label.setWordWrap(True);quality_layout.addWidget(w.quality_label)
    refresh=QHBoxLayout();refresh.addWidget(QLabel('显示刷新'))
    w.refresh_box=QComboBox()
    for interval in (200,500,1000):w.refresh_box.addItem(f'{interval/1000:.1f} 秒',interval)
    w.refresh_box.setCurrentIndex(1);w.refresh_box.currentIndexChanged.connect(w.change_refresh_interval)
    refresh.addWidget(w.refresh_box);quality_layout.addLayout(refresh)
    left_layout.addWidget(quality);left_layout.addStretch()
    w.left_scroll=scroll(left);w.left_scroll.setMinimumWidth(245)
    w.workspace_splitter.addWidget(w.left_scroll)

    map_box,map_layout=card('定位地图 / XY 平面')
    w.fence_label=QLabel('围栏未就绪：等待FPGA上报有效定位。');w.fence_label.setWordWrap(True)
    w.fence_label.setStyleSheet('background:#fff5df;color:#935b00;padding:8px;border-radius:6px;')
    map_layout.addWidget(w.fence_label)
    map_layout.addWidget(w.map_panel,1);w.workspace_splitter.addWidget(map_box)

    right=QWidget();right_layout=QVBoxLayout(right);right_layout.setContentsMargins(0,0,0,0);right_layout.setSpacing(8)
    result,result_layout=card('FPGA 解算结果')
    result_layout.setSpacing(5)
    tag_row=QHBoxLayout();tag_row.addWidget(QLabel('当前标签'))
    w.tag_selector=QComboBox();w.tag_selector.setMinimumWidth(70);tag_row.addWidget(w.tag_selector)
    w.position_badge=QLabel('等待定位');w.position_badge.setObjectName('badge');tag_row.addWidget(w.position_badge,1)
    result_layout.addLayout(tag_row)
    coordinates=QGridLayout();w.coordinate_labels=[]
    for i,axis in enumerate(('X','Y','Z')):
        name=QLabel(axis+('（已知）' if i==2 else ''));name.setObjectName('muted')
        label=QLabel('—');label.setObjectName('coordinate' if i<2 else 'knownHeight')
        if i<2:
            coordinates.addWidget(name,0,i*2);coordinates.addWidget(label,1,i*2)
            coordinates.addWidget(QLabel('m'),1,i*2+1)
        else:
            coordinates.addWidget(name,2,0);coordinates.addWidget(label,2,2);coordinates.addWidget(QLabel('m'),2,3)
        w.coordinate_labels.append(label)
    result_layout.addLayout(coordinates)
    ranges=QGridLayout();w.distance_labels=[];w.angle_labels=[]
    for col in range(3):
        anchor=QLabel(f'▲ A{col}');anchor.setStyleSheet('color:#b26c14;font-weight:600;')
        ranges.addWidget(anchor,0,col)
        distance=QLabel('— m');distance.setObjectName('rangeValue');ranges.addWidget(distance,1,col)
        angle=QLabel('— °');angle.setObjectName('muted');ranges.addWidget(angle,2,col)
        w.distance_labels.append(distance);w.angle_labels.append(angle)
    result_layout.addLayout(ranges)
    description=QLabel('原始斜距 / 水平角（+X=0°，逆时针）');description.setObjectName('muted')
    description.setWordWrap(True);result_layout.addWidget(description)
    right_layout.addWidget(result)
    ai_box,w.ai_layout=card('AI PC 风险监测')
    right_layout.addWidget(ai_box);right_layout.addStretch()
    w.right_scroll=scroll(right);w.right_scroll.setMinimumWidth(330)
    w.workspace_splitter.addWidget(w.right_scroll)
    w.workspace_splitter.setSizes([270,700,365]);w.workspace_splitter.setStretchFactor(1,1)
    w.main_splitter.addWidget(w.workspace_splitter)

    data,data_layout=card('实时数据 / FPGA 输出')
    data_layout.setContentsMargins(10,17,10,8)
    w.table=table(['标签','MASK','序号','距离 A0 / m','距离 A1 / m','距离 A2 / m','X / m','Y / m','Z已知 / m','状态'])
    w.table.horizontalHeader().setSectionResizeMode(9,QHeaderView.ResizeMode.Fixed);w.table.setColumnWidth(9,220)
    w.table.setMinimumHeight(75);data_layout.addWidget(w.table)
    diagnostics_button=QToolButton();diagnostics_button.setText('展开水平角与接收诊断');diagnostics_button.setCheckable(True)
    data_layout.addWidget(diagnostics_button)
    w.diagnostics=QWidget();diagnostics=QVBoxLayout(w.diagnostics);diagnostics.setContentsMargins(0,0,0,0)
    w.angle_table=table(['标签','A0 → 标签 / °','A1 → 标签 / °','A2 → 标签 / °'])
    w.angle_table.setMinimumHeight(70);w.angle_table.setMaximumHeight(110);diagnostics.addWidget(w.angle_table)
    log_controls=QHBoxLayout();w.hex_check=QCheckBox('显示接收十六进制');w.hex_check.setChecked(False)
    log_controls.addWidget(w.hex_check);log_controls.addStretch()
    clear=QPushButton('清空日志');clear.clicked.connect(lambda:w.log.clear());log_controls.addWidget(clear)
    diagnostics.addLayout(log_controls)
    w.log=QPlainTextEdit();w.log.setReadOnly(True);w.log.setMaximumBlockCount(500)
    w.log.setMinimumHeight(80);w.log.setMaximumHeight(160)
    w.log.setPlaceholderText('通过CRC校验后才更新数据；此处显示连接、报警及原始字节诊断。')
    diagnostics.addWidget(w.log);data_layout.addWidget(w.diagnostics);w.diagnostics.hide()
    def toggle_diagnostics(shown):
        w.diagnostics.setVisible(shown)
        diagnostics_button.setText('收起水平角与接收诊断' if shown else '展开水平角与接收诊断')
        total=max(w.main_splitter.height(),600)
        bottom=min(365,total//2) if shown else 145
        w.main_splitter.setSizes([total-bottom,bottom])
    diagnostics_button.toggled.connect(toggle_diagnostics)
    w.main_splitter.addWidget(data);w.main_splitter.setSizes([650,145]);w.main_splitter.setStretchFactor(0,1)
    layout.addWidget(w.main_splitter,1)
    footer=QHBoxLayout();w.statistics=QLabel('有效帧 0    接收字节 0    CRC错误 0    格式错误 0')
    footer.addWidget(w.statistics,1)
    layout.addLayout(footer)
    w.tag_selector.currentIndexChanged.connect(lambda:refresh_dashboard(w))
    w.setCentralWidget(root)
    w.setStyleSheet(STYLE)
    w.statusBar().showMessage('就绪 · AI风险与定位同屏显示 · 未连接硬件')
    refresh_dashboard(w)


def zoom_map(w,factor):
    canvas=w.map_panel.canvas
    scale=canvas.transform().m11()*factor
    if .01<=scale<=40:
        canvas.auto_fit=False;canvas.scale(factor,factor)


def refresh_dashboard(w):
    """Read-only presentation; never smooth values or emit hardware commands."""
    for i,label in enumerate(w.anchor_labels):
        x,y,z=w.map_panel.display_anchors[i]
        label.setText(f'▲ A{i}     历史基站坐标未核对' if w.map_panel.history_replay and not w.map_panel.has_replay_geometry else f'▲ A{i}     {format_coordinate_m(x)}   {format_coordinate_m(y)}   {format_coordinate_m(z)}')
        label.setToolTip((f'CSV记录的原基站坐标：{x:g}, {y:g}, {z:g} mm' if w.map_panel.has_replay_geometry else '当前配置，非历史记录基站参数') if w.map_panel.history_replay else '当前基站显示坐标 / m；实际安装参数步长0.1米')
    current=w.tag_selector.currentData()
    for tag in sorted(w.tags):
        if w.tag_selector.findData(tag)<0:
            w.tag_selector.blockSignals(True);w.tag_selector.addItem(f'T{tag:02d}',tag);w.tag_selector.blockSignals(False)
    if current is not None:w.tag_selector.setCurrentIndex(w.tag_selector.findData(current))
    tag=w.tag_selector.currentData()
    if tag not in w.tags:
        for label in w.coordinate_labels:label.setText('—')
        for label in w.distance_labels:label.setText('— m')
        for label in w.angle_labels:label.setText('— °')
        w.position_badge.setText('等待定位');return
    value,seen=w.tags[tag];stale=w.mode=='idle' or time.monotonic()-seen>2
    valid=value.has_position and not stale
    for label,mm in zip(w.coordinate_labels,value.position_mm):label.setText(format_coordinate_m(mm) if valid else '—')
    for i,label in enumerate(w.distance_labels):
        label.setText(f'{format_coordinate_m(value.distances_mm[i])} m' if not stale and value.mask&(1<<i) else '— m')
    for i,label in enumerate(w.angle_labels):
        label.setText(f'{value.azimuth_cdeg[i]/100:.2f} °' if valid and value.has_azimuth(i) else '— °')
    if stale:state,color='未连接 / 超时','#8490a2'
    elif value.position_fault:state,color=('定位失效 / 越界保留' if tag in w.map_panel.alarm_tags else '定位失效'),'#b26c14'
    elif tag in w.map_panel.alarm_tags:state,color='越界报警','#d92d20'
    elif value.pending_count:state,color=f'疑似越界 {value.pending_count}/3','#b26c14'
    elif value.quality_untrusted:state,color='质量可疑','#b26c14'
    elif not value.has_position:state,color='定位无效','#b26c14'
    else:state,color='定位有效','#008579'
    if w.mode=='demo':state='模拟 · '+state
    elif w.map_panel.history_replay:state='回放 · '+('已停止' if w.mode=='idle' else state)
    w.position_badge.setText(state);w.position_badge.setStyleSheet(f'color:{color};font-weight:700;')
    for label in w.coordinate_labels:label.setStyleSheet(f'color:{color if not valid or tag in w.map_panel.alarm_tags else "#1765ef"};')


STYLE='''
QMainWindow, QWidget {background:#f1f6fc;color:#172e52;font-size:12px;font-family:"Microsoft YaHei UI";}
QLabel {background:transparent;}
QLabel#title {font-size:21px;font-weight:700;color:#15355c;}
QLabel#muted {color:#738299;font-size:11px;}
QLabel#source {color:#315f9b;}
QWidget#connectionBar {background:#ffffff;border:1px solid #dce6f2;border-radius:7px;}
QGroupBox {background:#ffffff;border:1px solid #dce6f2;border-radius:7px;margin-top:9px;padding-top:7px;font-weight:600;font-size:14px;}
QGroupBox::title {subcontrol-origin:margin;left:13px;padding:0 5px;color:#163b70;}
QGroupBox QWidget {background:transparent;}
QPushButton,QComboBox,QSpinBox,QLineEdit,QDoubleSpinBox {background:white;border:1px solid #cddcef;border-radius:5px;padding:6px 8px;min-height:19px;}
QPushButton:hover {background:#eaf2ff;border-color:#8db2f5;}
QPushButton:disabled,QComboBox:disabled {color:#9aa7b8;}
QPushButton#primary {background:#1765ef;color:white;border-color:#1765ef;}
QPushButton#primary:hover {background:#0f55d2;}
QToolButton {border:0;background:#edf4ff;color:#2164c8;border-radius:4px;padding:6px;text-align:left;}
QLabel#coordinate {font-size:30px;font-weight:700;color:#1765ef;}
QLabel#knownHeight {font-size:18px;color:#738299;}
QLabel#rangeValue {font-size:15px;font-weight:600;color:#008579;}
QLabel#anchorRow {font-size:12px;background:#f4f8fd;border-radius:4px;padding:6px;}
QTableWidget,QPlainTextEdit {background:white;alternate-background-color:#f5f9ff;border:1px solid #e0e9f4;gridline-color:#e7edf6;selection-background-color:#dceaff;selection-color:#123b6b;}
QHeaderView::section {background:#f0f5fc;color:#435e81;padding:5px;border:0;font-size:11px;}
QScrollArea {border:0;background:transparent;}
QScrollBar:vertical {width:7px;background:#f1f5fa;}
QScrollBar::handle:vertical {background:#c3d3e8;min-height:24px;border-radius:3px;}
QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical {height:0;}
QSplitter::handle {background:#edf3fb;}
QProgressBar {border:0;border-radius:3px;background:#e8eff8;}
QStatusBar {color:#6c7f98;font-size:11px;}
'''
