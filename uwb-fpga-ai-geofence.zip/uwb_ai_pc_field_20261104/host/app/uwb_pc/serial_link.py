"""第3课：Qt串口只负责接收字节，不解析数据、不改变控件。"""
from PySide6.QtCore import QObject, Signal, QIODevice
from PySide6.QtSerialPort import QSerialPort, QSerialPortInfo


class SerialLink(QObject):
    bytes_received = Signal(bytes)
    connection_lost = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.port = QSerialPort(self)
        self.port.setReadBufferSize(65536)
        self.port.readyRead.connect(self._read_available)
        self.port.errorOccurred.connect(self._handle_error)
        self._closing = False

    @staticmethod
    def available_ports() -> list[tuple[str, str]]:
        return sorted((p.portName(), p.description())
                      for p in QSerialPortInfo.availablePorts())

    def open_port(self, name: str, baud: int):
        if not name:
            raise ValueError("请先选择串口。")
        if self.port.isOpen():
            raise RuntimeError("串口已连接，请先断开。")
        # 打开时的错误用异常一次性报告；运行中的拔线用Qt信号报告。
        self.port.blockSignals(True)
        try:
            self.port.setPortName(name)
            configured = all([
                self.port.setBaudRate(baud),
                self.port.setDataBits(QSerialPort.DataBits.Data8),
                self.port.setParity(QSerialPort.Parity.NoParity),
                self.port.setStopBits(QSerialPort.StopBits.OneStop),
                self.port.setFlowControl(QSerialPort.FlowControl.NoFlowControl),
            ])
            if not configured or not self.port.open(QIODevice.OpenModeFlag.ReadWrite):
                raise RuntimeError(self.port.errorString())
        finally:
            self.port.blockSignals(False)
        # readyRead可能已在打开期间到达，主动读取一次现有缓存。
        self._read_available()

    def close_port(self):
        self._closing = True
        try:
            if self.port.isOpen():
                self.port.close()
        finally:
            self._closing = False

    def send_bytes(self, data: bytes):
        if not self.port.isOpen():
            raise RuntimeError("串口未连接，不能发送控制指令")
        if self.port.write(data) != len(data):
            raise RuntimeError("串口发送缓冲未接受完整指令")

    def _read_available(self):
        data = bytes(self.port.readAll()) if self.port.isOpen() else b""
        if data:
            self.bytes_received.emit(data)

    def _handle_error(self, error):
        if self._closing or error == QSerialPort.SerialPortError.NoError:
            return
        if self.port.isOpen():
            message = self.port.errorString()
            self.close_port()
            self.connection_lost.emit(message)
