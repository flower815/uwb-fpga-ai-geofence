"""Replay recorded receive bytes once, using their original relative PC times."""
from dataclasses import dataclass
import json
from pathlib import Path
import time
from decimal import Decimal,ROUND_HALF_UP
from collections import Counter
from PySide6.QtCore import QObject,QTimer,Signal,Qt
from .protocol import FrameDecoder,Measurement,valid_fence_fields
from .known_point import KnownPointSession
from .geofence import SITE_ANCHORS_MM,SITE_TAG_Z_MM

DEFAULT_HISTORY=Path(__file__).resolve().parents[1]/'examples/unused_legacy_history.jsonl'
FIELD_DATASETS={f'field{i}':DEFAULT_HISTORY.parent/'field_tests'/name for i,name in enumerate(
    ('p1_los_run1.csv', 'p1_los_run2.csv', 'p1_los_run3.csv', 'p1_los_run4.csv', 'p1_los_run5.csv'))}


def replay_path_for(scenario):
    return FIELD_DATASETS.get(scenario)


@dataclass(frozen=True)
class ReceiveEvent:
    offset_ns:int
    data:bytes


@dataclass(frozen=True)
class CsvEvent:
    offset_ns:int
    measurement:Measurement
    row:dict


def read_csv_history(path):
    """Read recorded application rows, without inventing UART CRCs or angles."""
    path=Path(path)
    if path.stat().st_size>8_000_000:raise ValueError('CSV超过8MB回放限制')
    session=KnownPointSession();session.load_csv(path)
    if not session.rows:raise ValueError('CSV没有可回放的数据行')
    events=[];first=None;previous=None;geometry_matches=True;recorded_anchors=None;uniform_anchors=True
    for index,row in enumerate(session.rows,1):
        stamp=Decimal(str(row['received_monotonic_s']))
        if stamp<0 or (previous is not None and stamp<previous):raise ValueError(f'CSV第{index}行接收时间倒退，不能按原速回放')
        if first is None:first=stamp
        offset=int(((stamp-first)*1_000_000_000).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
        flags=int(row['fence_flags'])
        value=Measurement(int(row['status']),int(row['mask']),int(row['sequence']),int(row['tag_id']),
                          tuple(int(row[f'd{i}_mm']) for i in range(3)),tuple(int(row[k]) for k in ('x_mm','y_mm','z_mm')),
                          fence_flags=None if flags==-1 else flags)
        if flags!=-1 and not valid_fence_fields(value):raise ValueError(f'CSV第{index}行围栏标志与定位状态矛盾')
        anchors=json.loads(row['anchors_json'])
        anchors=tuple(tuple(float(v) for v in p) for p in anchors)
        if recorded_anchors is None:recorded_anchors=anchors
        else:uniform_anchors &= anchors==recorded_anchors
        geometry_matches &= all(abs(a-b)<=1e-6 for actual,expected in zip(anchors,SITE_ANCHORS_MM) for a,b in zip(actual,expected))
        geometry_matches &= value.position_mm[2]==SITE_TAG_Z_MM
        events.append(CsvEvent(offset,value,row));previous=stamp
    a,b,c=recorded_anchors
    usable_anchors=uniform_anchors and (b[0]-a[0])*(c[1]-a[1])!=(b[1]-a[1])*(c[0]-a[0])
    metadata={'format':'known_point_csv','name':path.name,'rows':len(events),
              'recorded_anchors_mm':recorded_anchors if usable_anchors else None,
              'geometry_matches_current':bool(geometry_matches),
              'valid_positions':sum(e.measurement.has_position for e in events),
              'position_faults':sum(e.measurement.position_fault for e in events),
              'fault_heartbeats':sum(e.row['kind']=='fault_heartbeat' for e in events),
              'recorded_sources':dict(Counter(e.row['source'] for e in events)),
              'recorded_profile_states':dict(Counter(e.row['profile_state'] for e in events)),
              'angles_recorded':False,'original_uart_bytes_available':False,
              'truth_changes':len({tuple(e.row[k] for k in ('truth_x_mm','truth_y_mm','truth_z_mm')) for e in events})>1}
    return tuple(events),len(events),metadata


def read_history(path):
    path=Path(path)
    if path.stat().st_size>8_000_000:raise ValueError('历史记录超过8MB回放限制')
    events=[];first=None;previous=None;decoder=FrameDecoder();count=0
    with path.open(encoding='utf-8-sig') as file:
        for line in file:
            if not line.strip():continue
            row=json.loads(line)
            if row.get('event')!='receive':continue
            stamp=row.get('pc_ns')
            if type(stamp) is not int or stamp<0 or (previous is not None and stamp<previous):
                raise ValueError('历史接收时间必须是递增的整数纳秒')
            raw=row.get('bytes_hex')
            if not isinstance(raw,str):raise ValueError('历史记录缺少接收字节')
            data=bytes.fromhex(raw)
            if not data:raise ValueError('历史接收字节为空')
            if first is None:first=stamp
            events.append(ReceiveEvent(stamp-first,data));previous=stamp
            count+=len(decoder.feed(data))
            if len(events)>100000:raise ValueError('历史接收条数超限')
    if not events or not count:raise ValueError('历史记录中没有可识别的定位帧')
    if decoder.crc_errors or decoder.format_errors or decoder.buffer:
        raise ValueError('这份回放文件含错误或不完整报文，请检查原始记录')
    return tuple(events),count


class HistoryReplay(QObject):
    bytes_received=Signal(bytes)
    progress=Signal(int,int)
    completed=Signal()
    sample_received=Signal(object)

    def __init__(self,parent=None,path=DEFAULT_HISTORY,clock=time.monotonic_ns):
        super().__init__(parent);self.path=Path(path);self.clock=clock
        self.timer=QTimer(self);self.timer.setSingleShot(True);self.timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.timer.timeout.connect(self.pump)
        self.events=();self.frame_count=0;self.index=0;self.started_ns=0
        self.running=False;self.finished=False
        self.source_kind='jsonl';self.metadata={}

    @property
    def duration_seconds(self):return self.events[-1].offset_ns/1e9 if self.events else 0.

    def prepare(self):
        self.stop()
        if self.path.suffix.lower()=='.csv':
            events,count,metadata=read_csv_history(self.path);kind='csv'
        else:
            events,count=read_history(self.path);metadata={'geometry_matches_current':False};kind='jsonl'
        self.events=events;self.frame_count=count;self.index=0;self.finished=False
        self.source_kind=kind;self.metadata=metadata

    def start(self,prepared=False):
        if not prepared:self.prepare()
        else:self.stop()
        self.started_ns=self.clock();self.running=True;self.pump()

    def stop(self):
        self.timer.stop();self.running=False

    def pump(self):
        if not self.running:return
        self.timer.stop()
        elapsed=self.clock()-self.started_ns
        while self.index<len(self.events) and self.events[self.index].offset_ns<=elapsed:
            event=self.events[self.index];self.index+=1
            if isinstance(event,CsvEvent):self.sample_received.emit(event)
            else:self.bytes_received.emit(event.data)
            self.progress.emit(self.index,len(self.events))
            if not self.running:return
        if self.index==len(self.events):
            self.running=False;self.finished=True;self.completed.emit();return
        remaining=self.events[self.index].offset_ns-(self.clock()-self.started_ns)
        self.timer.start(max(1,min(2_147_483_647,(remaining+999999)//1000000)))
