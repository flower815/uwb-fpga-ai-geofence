"""设置中文字体；无屏幕测试环境缺少系统字体枚举时显式加载Windows字体。"""
import os
from pathlib import Path
from PySide6.QtGui import QFont, QFontDatabase


def configure_font(application):
    if os.name == "nt" and not QFontDatabase.families():
        font_folder = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
        for name in ["msyh.ttc", "segoeui.ttf"]:
            path = font_folder / name
            if path.exists():
                QFontDatabase.addApplicationFont(str(path))
    application.setFont(QFont("Microsoft YaHei UI", 10))
