"""独立的 Python/PySide6 上位机教学项目。"""
