"""Local AI risk monitoring and optional USB / Wi-Fi alarm closed loops."""
from dataclasses import asdict
import json
from pathlib import Path
import struct
import time
from PySide6.QtCore import QObject, QTimer, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,QPushButton,
                              QCheckBox,QTableWidget,QTableWidgetItem,QLineEdit,QHeaderView,
                              QProgressBar,QToolButton)
from .ai_model import RiskModel,RiskEngine,RiskResult
from .ai_control import ControlClient
from .ai_metrics import SessionRecorder
from .protocol import ControlAck
from .coordinate_precision import COORDINATE_STEP_MM,COORDINATE_ROUNDING,TELEMETRY_COORDINATE_STEP_MM


class AiSupervisor(QObject):
    changed=Signal()
    def __init__(self, window):
        super().__init__(window)
        self.window=window;self.engine=RiskEngine();self.results={};self.enabled=False
        self.recorder=None;self.message="本地模型就绪；联动未启用";self.last_send=0;self.release_requested=False
        self.client=ControlClient(self._send,self.record)
        self.timer=QTimer(self);self.timer.setInterval(100);self.timer.timeout.connect(self.tick);self.timer.start()

    def record(self,kind,data):
        if self.recorder:self.recorder.record(kind,data)

    def _send(self,data):
        if self.window.mode=='replay':raise RuntimeError('历史回放只读，不发送开发板控制指令')
        if self.window.mode=="serial":self.window.serial.send_bytes(data)
        elif self.window.mode=="tcp":self.window.tcp.send_bytes(data)
        elif self.window.mode=="demo":
            _,_,opcode,sequence,flags,_,token,_=struct.unpack("<2sBBHBBII",data[:16])
            local=bool(self.window.map_panel.alarm_tags)
            state=(16 | int(bool(flags)) if opcode==1 else 0 if opcode==2 else self.client.last_state or 0)
            state|=4 if local else 0
            ack=ControlAck(opcode,sequence,state,0,token,int(time.monotonic()*50e6)&0xffffffff)
            QTimer.singleShot(10,lambda:self.accept(ack))
        else:raise RuntimeError("请连接USB串口、Wi-Fi TCP，或启动明确标注的模拟执行器")

    def accept(self,ack):
        if self.client.accept(ack):self.changed.emit()

    def process(self,measurement):
        compatible_replay=self.window.replay.source_kind=='csv' and self.window.replay.metadata.get('geometry_matches_current',False)
        if self.window.mode=='replay' and not compatible_replay:
            result=RiskResult(measurement.tag_id,None,'历史布局与当前不同或未核对，不套用当前AI模型')
        else:result=self.engine.process(measurement)
        self.results[measurement.tag_id]=(result,time.monotonic())
        self.record("inference",{**asdict(result),"sequence":measurement.sequence,"status":measurement.status,
                     "position_mm":measurement.position_mm,"distances_mm":measurement.distances_mm,
                     "fence_flags":measurement.fence_flags,"model_version":self.engine.model.metadata["version"]})
        self.changed.emit()

    def warning(self):
        now=time.monotonic()
        # Unknown/stale positions do not constitute a safe AI decision.
        return not self.results or any(r.probability is None or now-seen>2 or r.probability>=.5
                                       for r,seen in self.results.values()) or bool(self.window.map_panel.alarm_tags)

    def tick(self):
        self.client.expire()
        if self.release_requested and self.client.pending is None:
            try:
                self.client.request(2);self.release_requested=False
            except RuntimeError as exc:self.message=str(exc);self.release_requested=False
        if self.enabled and time.monotonic()-self.last_send>=.25 and self.client.pending is None:
            try:
                if self.client.request(1,self.warning()):self.last_send=time.monotonic()
            except RuntimeError as exc:self.message=str(exc)
        self.changed.emit()

    def set_enabled(self,enabled):
        if self.window.mode=='replay':raise RuntimeError('历史回放只读，不启用或下发开发板联动指令')
        if enabled and self.window.mode not in ("serial","tcp","demo"):
            raise RuntimeError("请先连接USB串口、Wi-Fi TCP，或启动模拟")
        if enabled and self.window.mode in ('serial','tcp') and not self.window.profile.verified:
            raise RuntimeError('请先核对开发板参数；未核对或不匹配时只允许监测，不授权AI控制')
        if enabled and self.window.mode=="tcp" and (self.client.last_state is None or self.client.last_result!=0):
            raise RuntimeError("请先检测FPGA双向链路，确认使用新版AI Wi-Fi固件")
        if enabled and self.client.pending:raise RuntimeError("等待当前指令应答或超时后再启用")
        if enabled:
            self.client.request(1,self.warning());self.enabled=True;self.last_send=time.monotonic()
            self.message="AI联动已请求：未知/超时也预警；本地越界保护始终独立"
        else:
            self.enabled=False;self.release_requested=True
            self.message="已请求释放PC预警，需应答确认；本地越界保护不受影响"
            self.tick()
        self.changed.emit()

    def transport_lost(self):
        self.enabled=False;self.release_requested=False;self.client.pending=None
        self.client.last_state=None;self.client.last_reply_ns=None
        self.client.last_result=None
        self.engine.reset();self.results.clear()
        self.message="连接已变化：需重新检测链路；若此前启用联动，FPGA看门狗会在超时后保留预警"
        self.changed.emit()

    def stop(self):
        if self.enabled and self.client.pending is None:
            try:self.client.request(2)
            except RuntimeError:pass
        self.enabled=False;self.timer.stop()

    def reset(self):
        if self.recorder:
            self.recorder.export(self.client,self.window.decoder);self.recorder.close();self.recorder=None
        self.enabled=False;self.release_requested=False;self.engine.reset();self.results.clear()
        self.client=ControlClient(self._send,self.record)
        self.message="新会话；控制未启用";self.changed.emit()

    def start_recording(self):
        if self.recorder:
            path=self.export();self.recorder.close();self.recorder=None
            self.message="已结束记录："+str(path);self.changed.emit();return
        if self.client.pending:raise RuntimeError("请等待当前指令应答/超时后开始记录，避免跨记录窗口统计")
        base=Path(__file__).resolve().parents[3]/"metrics"/"logs"
        path=base/(time.strftime("session_%Y%m%d_%H%M%S_")+str(time.monotonic_ns()%1000000))
        environment=self.engine.model.environment()
        environment.update(coordinate_step_mm=COORDINATE_STEP_MM,coordinate_rounding=COORDINATE_ROUNDING,
                           current_firmware_internal_step_mm=1,current_firmware_telemetry_step_mm=TELEMETRY_COORDINATE_STEP_MM,
                           coordinate_units='mm; v5.6 FPGA and application XYZ retain original integer millimeters; labels use one decimal metre',raw_receive_bytes='original protocol diagnostics, not application coordinate samples')
        if self.window.mode=='replay':environment['history_replay']={'file':self.window.replay.path.name,'new_field_measurement':False,
                                  'current_geometry_verified':False,'csv_geometry_matches_model':self.window.replay.source_kind=='csv' and self.window.replay.metadata.get('geometry_matches_current',False)}
        self.recorder=SessionRecorder(path,environment,self.window.mode,
                                      client=self.client,decoder=self.window.decoder)
        self.message="正在记录："+str(path);self.changed.emit()

    def export(self):
        if not self.recorder:raise RuntimeError("请先开始记录")
        path=self.recorder.export(self.client,self.window.decoder)
        self.message="已导出："+str(path);self.changed.emit();return path


class AiPanel(QWidget):
    """Always embedded in the dashboard; advanced controls expand in place."""
    def __init__(self, supervisor):
        super().__init__(supervisor.window)
        self.s=supervisor
        layout=QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0);layout.setSpacing(6)
        self.risk_label=QLabel('风险未知 · 等待连续有效定位')
        self.risk_label.setObjectName('riskHeadline');self.risk_label.setWordWrap(True)
        layout.addWidget(self.risk_label)
        self.risk_bar=QProgressBar();self.risk_bar.setRange(0,100);self.risk_bar.setValue(0)
        self.risk_bar.setTextVisible(False);self.risk_bar.setFixedHeight(7);layout.addWidget(self.risk_bar)
        self.summary=QLabel('预测未来0.7秒越界风险')
        self.summary.setWordWrap(True);self.summary.setObjectName('muted');layout.addWidget(self.summary)
        self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(["标签","评分","判断","推理ms","处理ms"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setVisible(False)
        for column in (0,1,3,4):
            self.table.horizontalHeader().setSectionResizeMode(column,QHeaderView.ResizeMode.ResizeToContents)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setFixedHeight(58)
        layout.addWidget(self.table)
        self.control=QCheckBox("启用AI预警联动（默认关闭）")
        self.control.setToolTip('先核对开发板参数并检测双向应答；本地越界保护独立运行。')
        self.control.clicked.connect(self.control_changed);layout.addWidget(self.control)
        actions=QHBoxLayout()
        ping=QPushButton("检测双向链路");ping.clicked.connect(lambda:self.attempt(self.ping))
        release=QPushButton("释放PC预警");release.clicked.connect(lambda:self.attempt(lambda:self.s.set_enabled(False)))
        actions.addWidget(ping);actions.addWidget(release);layout.addLayout(actions)
        self.status=QLabel();self.status.setWordWrap(True);self.status.setObjectName('muted');layout.addWidget(self.status)
        self.message=QLabel();self.message.setWordWrap(True);layout.addWidget(self.message)
        self.advanced_button=QToolButton();self.advanced_button.setText('展开 AI 后端与测试记录')
        self.advanced_button.setCheckable(True);self.advanced_button.toggled.connect(self.toggle_advanced)
        layout.addWidget(self.advanced_button)
        self.advanced=QWidget();advanced=QVBoxLayout(self.advanced);advanced.setContentsMargins(0,0,0,0)
        note=QLabel("合成数据训练原型，尚未现场验收。默认固件连续3次越界才报警，首次可信区内解除；定位/通信故障只提示不单独蜂鸣。AI提前蜂鸣需另行配置。")
        note.setWordWrap(True);note.setObjectName('muted');advanced.addWidget(note)
        row=QHBoxLayout();self.backend=QComboBox()
        for label,value in (("Intel / 通用CPU（无需额外AI依赖）","native_cpu"),("PyTorch CPU（可选）","torch_cpu"),("AMD ROCm / HIP（迁移后）","torch_rocm")):
            self.backend.addItem(label,value)
        switch=QPushButton("切换后端");switch.clicked.connect(self.switch_backend)
        row.addWidget(self.backend,1);row.addWidget(switch);advanced.addLayout(row)
        record_row=QHBoxLayout()
        self.start=QPushButton("开始记录本次测试");self.start.clicked.connect(lambda:self.attempt(self.s.start_recording))
        export=QPushButton("导出指标与环境");export.clicked.connect(lambda:self.attempt(self.s.export))
        record_row.addWidget(self.start);record_row.addWidget(export);advanced.addLayout(record_row)
        definition=QLabel("试验定义：测试前约定一次预警任务；操作员观察实际蜂鸣器动作后记录成功/失败。\n"
                          "应答只证明FPGA接受指令；传感器到物理发声的延迟需另附同步波形，不自动填入。")
        definition.setWordWrap(True);advanced.addWidget(definition)
        self.note=QLineEdit();self.note.setPlaceholderText("记录真实观察、测试条件或证据文件路径；不要把模拟结果标为实测")
        advanced.addWidget(self.note)
        outcomes=QHBoxLayout()
        for text,value in (("记录成功","success"),("记录失败","failure"),("记录人工干预","intervention")):
            button=QPushButton(text);button.clicked.connect(lambda checked=False,v=value:self.attempt(lambda:self.trial(v)))
            outcomes.addWidget(button)
        advanced.addLayout(outcomes)
        layout.addWidget(self.advanced);self.advanced.hide()
        self._displayed_backend=None
        self.s.changed.connect(self.refresh);self.refresh()

    def toggle_advanced(self,shown):
        self.advanced.setVisible(shown)
        self.advanced_button.setText('收起 AI 后端与测试记录' if shown else '展开 AI 后端与测试记录')

    def ping(self):
        if self.s.window.profile.active:raise RuntimeError('请等待开发板参数核对完成，再检测双向链路')
        self.s.client.request(0)

    def attempt(self,fn):
        try:fn()
        except (RuntimeError,ValueError,ImportError,OSError) as exc:self.s.message=str(exc)
        self.refresh()

    def switch_backend(self):
        def change():
            if self.s.enabled or self.s.recorder:raise RuntimeError("先结束联动和当前记录，再切换后端，避免混合测试条件")
            model=RiskModel(self.backend.currentData());self.s.engine=RiskEngine(model);self.s.results.clear()
            self.s.message="已切换为"+model.backend
        self.attempt(change)

    def control_changed(self,checked):self.attempt(lambda:self.s.set_enabled(checked))

    def trial(self,value):
        if not self.s.recorder:raise RuntimeError("请先开始记录")
        if not self.note.text().strip():raise RuntimeError("请填写本次实际观察和测试说明")
        self.s.recorder.trial(value,self.note.text().strip());self.s.message="已记录操作员试验结果"

    def refresh(self):
        self.start.setText("结束并导出本次记录" if self.s.recorder else "开始记录本次测试")
        self.control.setChecked(self.s.enabled)
        source="模拟执行器，非实板" if self.s.window.mode=="demo" else '历史回放，非实时' if self.s.window.mode=='replay' else self.s.window.mode
        reply=self.s.client.last_message.replace('FPGA','模拟执行器') if self.s.window.mode=='demo' else self.s.client.last_message
        short_reply=reply.split('；')[0].split('（')[0]
        self.status.setText(f'{self.s.engine.model.backend} · 联动'+('已启用' if self.s.enabled else '关闭')+f' · ACK {self.s.client.acks}\n'+short_reply)
        self.status.setToolTip(f'数据源：{source}\n'+reply)
        if self._displayed_backend!=self.s.engine.model.backend:
            backend_index=self.backend.findData(self.s.engine.model.backend)
            if backend_index>=0:self.backend.setCurrentIndex(backend_index)
            self._displayed_backend=self.s.engine.model.backend
        fresh=[(tag,r) for tag,(r,seen) in self.s.results.items() if time.monotonic()-seen<=2]
        unknown=self.s.window.mode=='idle' or not fresh or len(fresh)!=len(self.s.results) or any(r.probability is None for _,r in fresh)
        score=max((r.probability for _,r in fresh if r.probability is not None),default=0)
        if unknown:
            headline=('风险未知 · 回放有效数据不足' if self.s.window.replay.source_kind=='csv' and self.s.window.replay.metadata.get('geometry_matches_current') else '风险未知 · 历史布局不同或未核对') if self.s.window.mode=='replay' else '风险未知 · 等待连续可信定位';color='#b26c14'
        elif score>=.5:
            headline=f'AI 越界风险较高 · {score:.1%}';color='#d92d20'
        else:
            headline=f'AI 越界风险较低 · {score:.1%}';color='#008579'
        self.risk_label.setText(headline);self.risk_label.setStyleSheet(f'color:{color};font-size:17px;font-weight:700;')
        self.risk_bar.setValue(0 if unknown else round(score*100))
        self.risk_bar.setStyleSheet(f'QProgressBar::chunk {{background:{color};border-radius:3px;}}')
        replay_summary='CSV离线风险重算 · 非实时测量 · 硬件控制关闭' if self.s.window.replay.source_kind=='csv' and self.s.window.replay.metadata.get('geometry_matches_current') else '历史回放：保留记录XYZ毫米值，不重放旧评分或控制指令'
        self.summary.setText('预测未来0.7秒越界风险')
        self.summary.setToolTip(replay_summary if self.s.window.mode=='replay' else '合成训练原型，风险评分不替代围栏与质量状态')
        self.table.setRowCount(len(self.s.results))
        self.table.setFixedHeight(28+min(3,max(1,len(self.s.results)))*30)
        for row,(tag,(result,seen)) in enumerate(sorted(self.s.results.items())):
            stale=self.s.window.mode=='idle' or time.monotonic()-seen>2
            values=[f"T{tag}","—" if result.probability is None or stale else f"{result.probability:.3f}",
                    "数据过期，风险未知" if stale else result.reason,f"{result.inference_ms:.4f}",f"{result.total_ms:.4f}"]
            for col,text in enumerate(values):
                item=QTableWidgetItem(text);item.setToolTip(text)
                item.setForeground(QColor('#935b00' if stale or result.probability is None else '#d92d20' if result.probability>=.5 else '#1e6d46'))
                self.table.setItem(row,col,item)
        text=self.s.message
        # Keep failures visible; routine detail remains available as a tooltip.
        routine=text in ('本地模型就绪；联动未启用','新会话；控制未启用')
        self.message.setVisible(not routine)
        self.message.setText(text);self.message.setToolTip(reply)
