"""One outstanding command. RTT uses one PC clock; it is not physical action latency."""
import struct
import time
from .protocol import crc16_ccitt


def command_packet(opcode, sequence, alarm=False, token=0):
    if opcode not in (0,1,2): raise ValueError("Unknown command")
    body = struct.pack("<2sBBHBBII", b"\x55\xaa", 0x10, opcode, sequence,
                       int(bool(alarm)), 0, token, 0)
    return body + crc16_ccitt(body).to_bytes(2, "little")


class ControlClient:
    def __init__(self, send, record=lambda *args: None, clock=time.monotonic_ns):
        self.send = send; self.record = record; self.clock = clock
        self.sequence = 0; self.token = time.monotonic_ns() & 0xffffffff
        self.pending = None; self.sent = 0; self.timeouts = 0; self.acks = 0
        self.rejected = 0; self.last_state = None; self.rtt_ms = []; self.last_reply_ns = None
        self.last_message = "尚未检测双向链路"
        self.last_result = None

    def request(self, opcode=0, alarm=False):
        if self.pending is not None: return False
        self.sequence = (self.sequence+1) & 0xffff; self.token=(self.token+1)&0xffffffff
        now = self.clock()
        item = {"opcode":opcode,"sequence":self.sequence,"token":self.token,"alarm":bool(alarm),"sent_ns":now}
        self.pending = item
        try:
            self.send(command_packet(opcode,self.sequence,alarm,self.token))
        except Exception:
            self.pending = None
            raise
        self.sent += 1;self.record("command_sent", item)
        self.last_message = "等待FPGA应答"
        return True

    def accept(self, ack):
        item = self.pending
        if item is None or (ack.sequence,ack.token,ack.opcode)!=(item["sequence"],item["token"],item["opcode"]):
            return False
        now=self.clock();self.pending=None
        self.last_reply_ns=now;self.last_state=ack.state
        self.last_result=ack.result
        rtt=(now-item["sent_ns"])/1e6
        if ack.result==0:
            self.acks+=1;self.rtt_ms.append(rtt)
            self.last_message=f"FPGA已接受 · RTT {rtt:.2f}ms（非物理响应时间）"
        else:
            self.rejected+=1;self.last_message=f"FPGA拒绝指令，错误码{ack.result}"
        self.record("command_ack",{**item,"ack_ns":now,"rtt_ms":rtt,"state":ack.state,
                                   "result":ack.result,"fpga_tick":ack.fpga_tick})
        return True

    def expire(self):
        if self.pending and self.clock()-self.pending["sent_ns"]>=500_000_000:
            self.record("command_timeout",self.pending);self.pending=None;self.timeouts+=1
            self.last_message="应答超时：检查AI版bit及回传接线；不代表硬件已执行"
            return True
        return False
