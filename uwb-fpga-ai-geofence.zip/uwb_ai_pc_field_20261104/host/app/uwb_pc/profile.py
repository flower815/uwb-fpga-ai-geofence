"""Read-only board profile queries. No configuration writes or watchdog lease refresh."""
import struct
import time
from .protocol import crc16_ccitt
from .geofence import SITE_ANCHORS_MM,SITE_TAG_Z_MM

PROFILE_NAMES=('magic','firmware','X0','Y0','Z0','X1','Y1','Z1','X2','Y2','Z2','TAG_Z',
               'RANGE_FILTER','FENCE_CONFIRM','CLEAR_HITS','CLEAR_MARGIN_MM','FAULT_TIMEOUT_MS',
               'EXPECTED_TAG','QUALITY_LIMIT_MM','AI_EARLY_BEEP','CLK_HZ','UWB_BAUD','FEATURES')
EXPECTED_PROFILE=(0x55574235,0x00050006,*[int(v) for p in SITE_ANCHORS_MM for v in p],SITE_TAG_Z_MM,
                  1,3,1,0,1000,2,200,0,50000000,115200,3)


def profile_packet(index,sequence,token):
    if not 0<=index<len(PROFILE_NAMES):raise ValueError('Profile register outside supported range')
    body=struct.pack('<2sBBHBBII',b'\x55\xaa',0x10,3,sequence,index,0,token,0)
    return body+crc16_ccitt(body).to_bytes(2,'little')


class ProfileVerifier:
    def __init__(self,send,changed=lambda:None,clock=time.monotonic):
        self.send=send;self.changed=changed;self.clock=clock
        self.sequence=0x8000;self.token=time.monotonic_ns()&0xffffffff
        self.reset()

    def reset(self):
        self.active=False;self.pending=None;self.values={};self.verified=False
        self.state='unverified';self.message='开发板参数尚未核对；仍可接收监测，AI控制未授权'
        self.changed()

    def start(self):
        self.reset();self.active=True;self.state='checking';self.message='正在只读核对开发板参数'
        self.tick()

    def tick(self):
        if not self.active:return
        now=self.clock()
        if self.pending:
            if now-self.pending['sent']<.8:return
            if self.pending['attempts']>=2:
                self.fail('参数核对超时：旧固件可能不支持读取；接收监测继续，AI控制禁用');return
            self.pending['sent']=now;self.pending['attempts']+=1
        else:
            index=len(self.values)
            if index==len(PROFILE_NAMES):self.validate();return
            self.sequence=(self.sequence+1)&0xffff;self.token=(self.token+1)&0xffffffff
            self.pending=dict(index=index,sequence=self.sequence,token=self.token,sent=now,attempts=1)
        p=self.pending
        try:self.send(profile_packet(p['index'],p['sequence'],p['token']))
        except (RuntimeError,OSError) as exc:self.fail(f'参数核对未完成：{exc}')

    def accept(self,ack):
        # Consume all query ACKs before the control client, including stale replies.
        if ack.opcode!=3:return False
        p=self.pending
        if not self.active or not p or (ack.sequence,ack.token)!=(p['sequence'],p['token']):return True
        if ack.result!=0:
            self.fail(f'开发板拒绝参数读取（错误码{ack.result}）；请使用当前质量监测版固件');return True
        value=ack.fpga_tick
        if 2<=p['index']<=11 and value&0x80000000:value-=1<<32
        self.values[p['index']]=value;self.pending=None
        self.message=f'正在核对开发板参数 {len(self.values)}/{len(PROFILE_NAMES)}'
        if len(self.values)==len(PROFILE_NAMES):self.validate()
        self.changed();return True

    def validate(self):
        differences=[PROFILE_NAMES[i] for i,value in enumerate(EXPECTED_PROFILE) if self.values.get(i)!=value]
        if differences:self.fail('开发板参数不匹配：'+', '.join(differences)+'；接收继续，AI控制禁用')
        else:
            self.active=False;self.pending=None;self.verified=True;self.state='verified'
            self.message='参数已核对：内部毫米解算、标签XYZ原始毫米发送；A2=(1.5,2.6,1.0)米；允许正向跳号、越界3次、区内解除；故障不蜂鸣'
            self.changed()

    def fail(self,message):
        self.active=False;self.pending=None;self.verified=False;self.state='failed';self.message=message;self.changed()
