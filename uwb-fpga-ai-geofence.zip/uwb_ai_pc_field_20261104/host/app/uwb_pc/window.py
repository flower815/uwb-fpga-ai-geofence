"""主窗口：接收FPGA结果，显示距离、坐标、地图与轨迹。"""
import time
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QMainWindow, QTableWidgetItem
from .protocol import FrameDecoder, Measurement
from .serial_link import SerialLink
from .tcp_link import TcpReceiver
from .simulator import Simulator
from .history_replay import HistoryReplay,replay_path_for
from .coordinate_precision import centimeter_measurement,format_coordinate_m,COORDINATE_STEP_MM,COORDINATE_ROUNDING
from .geofence import ALARM_COLOR
from .ai_panel import AiSupervisor, AiPanel
from .dashboard import build_dashboard, refresh_dashboard
from .profile import ProfileVerifier
from .known_point import KnownPointSession
from .known_point_dialog import KnownPointDialog


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("UWB 定位上位机")
        screen = self.screen().availableGeometry()
        self.setMinimumSize(1100, 680)
        self.resize(min(1480, max(1100, int(screen.width() * .94))),
                    min(880, max(680, int(screen.height() * .92))))
        self.decoder = FrameDecoder()
        self.serial = SerialLink(self)
        self.tcp = TcpReceiver(self)
        self.simulator = Simulator(self)
        self.replay = HistoryReplay(self)
        self.mode = "idle"
        self.session_started = time.monotonic()
        self.tags: dict[int, tuple[Measurement, float]] = {}
        self.rows: dict[int, int] = {}
        # 每帧照常解析，只在显示定时器触发时绘制各标签的最新结果。
        self.pending_measurements: dict[int, Measurement] = {}
        self.pending_positions: dict[int, Measurement] = {}
        self.map_pending_redraw = False
        self.fence_event_count = 0
        self.known_points=KnownPointSession()
        self.known_point_dialog=None
        self.profile=None
        self._build_ui()
        self.ai = AiSupervisor(self)
        self.profile=ProfileVerifier(self.send_profile_bytes,self.update_profile_status)
        self.ai_panel = AiPanel(self.ai)
        self.ai_layout.addWidget(self.ai_panel)
        field_action=self.menuBar().addMenu('现场标定').addAction('已知点误差统计 / CSV回放')
        field_action.triggered.connect(self.show_known_points)
        self.serial.bytes_received.connect(self.receive_bytes)
        self.serial.connection_lost.connect(self.serial_failed)
        self.tcp.bytes_received.connect(self.receive_bytes)
        self.tcp.peer_connected.connect(self.tcp_connected)
        self.tcp.connection_lost.connect(self.tcp_disconnected)
        self.simulator.bytes_received.connect(self.receive_bytes)
        self.replay.bytes_received.connect(self.receive_bytes)
        self.replay.sample_received.connect(self.receive_csv_sample)
        self.replay.progress.connect(self.replay_progress)
        self.replay.completed.connect(self.replay_completed)
        self.health_timer = QTimer(self)
        self.health_timer.setInterval(self.refresh_box.currentData())
        self.health_timer.timeout.connect(self.refresh_health)
        self.health_timer.start()
        self.refresh_ports()

    def _build_ui(self):
        build_dashboard(self)

    def write_log(self, message: str):
        self.log.appendPlainText(time.strftime("%H:%M:%S") + "  " + message)

    def refresh_ports(self):
        selected = self.port_box.currentData()
        self.port_box.clear()
        for name, description in self.serial.available_ports():
            self.port_box.addItem(f"{name} · {description}" if description else name, name)
        if self.port_box.count() == 0:
            self.port_box.addItem("未发现串口", "")
        elif selected:
            index = self.port_box.findData(selected)
            if index >= 0:
                self.port_box.setCurrentIndex(index)

    def reset_session(self):
        self.replay.stop()
        self.ai.reset()
        self.profile.reset()
        self.known_points.active=False
        self.decoder = FrameDecoder()
        self.tags.clear()
        self.rows.clear()
        self.pending_measurements.clear()
        self.pending_positions.clear()
        self.map_pending_redraw = False
        self.fence_event_count = 0
        self.map_panel.history_replay=False
        self.map_panel.replay_geometry_matches=False
        self.map_panel.replay_anchors=None
        self.map_panel.hint.setText(self.map_panel.live_hint)
        self.map_panel.clear_session()
        self.table.setRowCount(0)
        self.angle_table.setRowCount(0)
        self.tag_selector.clear()
        refresh_dashboard(self)
        self.log.clear()
        self.session_started = time.monotonic()
        self.update_fence_status()

    def set_controls(self):
        replay_done=self.mode=='replay' and self.replay.finished
        idle = self.mode == "idle" or replay_done
        for widget in [self.port_box, self.baud_box, self.refresh_button]:
            widget.setEnabled(idle)
        self.connect_button.setEnabled(self.mode in ("idle", "serial") or replay_done)
        self.connect_button.setText("断开串口" if self.mode == "serial" else "连接串口")
        self.demo_button.setEnabled(self.mode in ("idle", "demo", "replay"))
        self.demo_button.setText('重新回放' if self.mode=='replay' and self.replay.finished else '停止回放' if self.mode=='replay'
                                 else '停止模拟' if self.mode=='demo' else '启动测试')
        self.scenario_box.setEnabled(self.mode in ("idle", "demo", "replay"))
        self.tcp_port.setEnabled(idle)
        self.tcp_button.setEnabled(self.mode in ("idle", "tcp") or replay_done)
        self.tcp_button.setText("停止TCP监听" if self.mode == "tcp" else "开始TCP监听")
        self.profile_button.setEnabled(self.mode!='replay')

    def toggle_serial(self):
        if self.mode=='replay' and self.replay.finished:self.mode='idle'
        if self.mode not in ("idle", "serial"):
            return
        if self.mode == "serial":
            if self.ai.enabled or self.ai.client.pending:
                self.write_log("请先在右侧AI PC面板解除联动并等待应答，再断开串口；异常断线会触发硬件看门狗。")
                self.show_ai()
                return
            self.serial.close_port()
            self.profile.reset()
            self.mode = "idle"
            self.source_label.setText("已断开串口；表格保留最后一次数据")
            self.set_controls()
            self.refresh_health()
            return
        self.reset_session()
        name = self.port_box.currentData() or ""
        self.mode = "serial"
        try:
            self.serial.open_port(name, self.baud_box.currentData())
        except (RuntimeError, ValueError) as exc:
            self.mode = "idle"
            self.source_label.setText(f"连接失败：{exc}")
            self.write_log(f"连接失败：{exc}")
        else:
            self.source_label.setText(f"实时串口 · {name} · {self.baud_box.currentText()} / 8N1 · 等待FPGA数据")
            self.write_log("串口已打开。接收V1/34字节、V2或V3/42字节，围栏报警由FPGA上报。")
        self.set_controls()

    def serial_failed(self, message: str):
        self.profile.reset()
        self.map_panel.tracker.reset()
        self.ai.transport_lost()
        self.mode = "idle"
        self.source_label.setText(f"串口中断：{message}")
        self.write_log(f"串口中断：{message}")
        self.set_controls()
        self.refresh_health()

    def toggle_demo(self):
        if self.mode not in ("idle", "demo", "replay"):
            return
        if self.mode=='replay':
            ended=self.replay.finished
            self.replay.stop();self.mode='idle'
            if not ended:
                self.source_label.setText('历史回放已停止；保留已播放轨迹，非实时数据')
                self.set_controls();self.refresh_health();return
        if self.mode == "demo":
            self.simulator.stop()
            self.mode = "idle"
            self.source_label.setText("模拟已停止；表格保留最后一次数据")
            self.set_controls()
            self.refresh_health()
            return
        self.reset_session()
        path=replay_path_for(self.scenario_box.currentData())
        if path is not None:
            self.mode='replay';self.replay.path=path
            try:
                self.replay.prepare()
                self.map_panel.history_replay=True
                self.map_panel.replay_geometry_matches=self.replay.source_kind=='csv' and self.replay.metadata['geometry_matches_current']
                self.map_panel.replay_anchors=self.replay.metadata.get('recorded_anchors_mm')
                if self.map_panel.replay_geometry_matches:
                    self.map_panel.hint.setText('CSV实测回放 · 复现原坐标、越界及故障状态 · AI离线重算 · 非实时测量，硬件控制关闭')
                elif self.map_panel.has_replay_geometry:
                    self.map_panel.hint.setText('CSV历史布局回放 · 按记录的基站/围栏显示 · 与当前安装参数不同，当前AI不重算 · 硬件控制关闭')
                else:
                    self.map_panel.hint.setText('历史XYZ保留记录毫米值 · 原基站参数未核对，不绘制当前基站/安全区 · 旧围栏状态不代表当前现场')
                self.map_panel.redraw();self.set_controls()
                self.replay.start(prepared=True)
            except (OSError,ValueError,KeyError,TypeError) as exc:
                self.mode='idle';self.source_label.setText(f'历史回放失败：{exc}');self.write_log(f'历史回放失败：{exc}');self.set_controls()
            else:
                unit='行' if self.replay.source_kind=='csv' else '帧'
                self.write_log(f'历史回放：{self.replay.path.name}，{self.replay.frame_count}{unit}，原速{self.replay.duration_seconds:.3f}秒，只读播放一次。')
                if self.replay.source_kind=='csv':
                    self.write_log('CSV保持原始位置、距离、故障/越界和时间间隔；未保存水平角或原始报文，角度显示空，CRC不作为实测证据。')
                    self.profile_label.setText('CSV回放只读；文件中的参数核对状态不授权当前开发板控制。')
                    if self.replay.metadata['truth_changes']:self.write_log('本文件人工真值发生变化：仅作轨迹/状态回放，精度统计前请核对毫米单位与真实测点。')
                else:self.write_log('记录标签高度1米，当前配置为0米；保留原始毫米坐标，不套用当前围栏、AI或已知点统计。')
            self.refresh_health();return
        self.mode = "demo"
        self.simulator.scenario = self.scenario_box.currentData()
        self.source_label.setText("模拟数据 · 电脑合成测试帧，未经实际Mini5/FPGA测量")
        self.set_controls()
        self.simulator.start()
        self.write_log("模拟已启动：每帧拆成两段字节，通过同一接收缓存和CRC解析器。")

    def replay_progress(self,index,total):
        self.source_label.setText(f'CSV回放 · {self.replay.path.name} · {index}/{total}行 · 原速 · 非实时' if self.replay.source_kind=='csv' else f'历史回放 · 2026-10-27 · {index}/{total}条 · 原速 · 旧标签Z=1m，非实时')

    def replay_completed(self):
        unit='行' if self.replay.source_kind=='csv' else '帧'
        self.source_label.setText(f'{self.replay.path.name} 回放完成 · {self.replay.frame_count}{unit} / {self.replay.duration_seconds:.3f}秒 · 可重新回放')
        self.write_log('历史记录已播放完毕，轨迹保留供查看；未循环或补造新数据。')
        self.set_controls();self.refresh_health()

    def toggle_tcp(self):
        if self.mode=='replay' and self.replay.finished:self.mode='idle'
        if self.mode == "tcp":
            if self.ai.enabled or self.ai.client.pending or self.ai.release_requested:
                self.write_log("请先在右侧AI PC面板释放预警并等待应答，再停止TCP；异常断线将触发硬件看门狗。")
                self.show_ai()
                return
            self.tcp.close()
            self.profile.reset()
            self.mode = "idle"
            self.source_label.setText("TCP监听已停止；表格保留最后一次数据")
            self.set_controls()
            self.refresh_health()
            return
        if self.mode != "idle":
            return
        self.reset_session()
        self.mode = "tcp"
        try:
            self.tcp.listen(self.tcp_port.value())
        except (RuntimeError, ValueError) as exc:
            self.mode = "idle"
            self.source_label.setText(f"TCP监听失败：{exc}")
            self.write_log(f"TCP监听失败：{exc}")
        else:
            self.source_label.setText(f"实时TCP · 监听端口 {self.tcp_port.value()} · 等待ESP-01S连接")
            self.write_log("TCP监听已启动。ESP-01S应作为TCP客户端连接电脑局域网IPv4地址。")
        self.set_controls()

    def tcp_connected(self, peer: str):
        self.profile.reset()
        self.map_panel.tracker.reset()
        # 新连接不接续上一连接的半帧，统计计数继续保留。
        self.decoder.buffer.clear()
        self.ai.transport_lost()
        self.ai.record("tcp_connected", {"peer": peer})
        self.session_started = time.monotonic()
        self.source_label.setText(f"实时TCP · 已连接 {peer} · 等待FPGA定位报文")
        self.write_log(f"TCP数据源已连接：{peer}")

    def tcp_disconnected(self, message: str):
        self.profile.reset()
        self.map_panel.tracker.reset()
        self.decoder.buffer.clear()
        self.ai.transport_lost()
        self.ai.record("tcp_disconnected", {"message": message})
        for tag, (value, _) in list(self.tags.items()):
            self.tags[tag] = (value, time.monotonic()-3)
        self.source_label.setText(f"实时TCP · {message}")
        self.write_log(message)
        self.refresh_health()

    def change_scenario(self):
        self.simulator.scenario = self.scenario_box.currentData()
        selected=replay_path_for(self.scenario_box.currentData())
        if self.mode in ('demo','replay') and ((selected is not None)!=(self.mode=='replay') or
                                                (self.mode=='replay' and selected!=self.replay.path)):
            self.simulator.stop();self.replay.stop();self.mode='idle';self.toggle_demo();return
        if self.mode == "demo":
            self.source_label.setText("模拟数据 · " + self.scenario_box.currentText() + " · 非实测")
            self.write_log("切换场景：" + self.scenario_box.currentText())

    def change_refresh_interval(self):
        interval = self.refresh_box.currentData()
        self.health_timer.setInterval(interval)
        self.simulator.timer.setInterval(interval)

    def receive_bytes(self, data: bytes):
        if self.mode == "idle":
            return
        if self.hex_check.isChecked():
            self.write_log("RX  " + data[:128].hex(" ").upper() + (" …" if len(data) > 128 else ""))
        old_crc = self.decoder.crc_errors
        self.ai.record("receive", {"bytes_hex": data.hex(), "source": self.mode})
        for wire_measurement in self.decoder.feed(data):
            self.accept_measurement(wire_measurement)
        while self.decoder.acknowledgements:
            ack=self.decoder.acknowledgements.popleft()
            if not self.profile.accept(ack):self.ai.accept(ack)
        if self.decoder.crc_errors != old_crc:
            self.write_log("CRC校验失败：本次坏帧未更新坐标。")
        self.update_fence_status()

    def receive_csv_sample(self,event):
        if self.mode!='replay' or self.replay.source_kind!='csv':return
        self.ai.record('csv_row',{'source':'replay','file':self.replay.path.name,'row_index':self.replay.index,
                       'recorded_source':event.row['source'],'recorded_profile_state':event.row['profile_state'],
                       'recorded_kind':event.row['kind'],'original_crc_available':False})
        self.accept_measurement(event.measurement)
        self.update_fence_status()

    def accept_measurement(self,wire_measurement):
        measurement=centimeter_measurement(wire_measurement)
        self.ai.record('position',{'tag_id':measurement.tag_id,'sequence':measurement.sequence,
                       'position_mm':measurement.position_mm,'position_cm':[v/10 for v in measurement.position_mm],
                       'status':measurement.status,'source':self.mode,'coordinate_step_mm':COORDINATE_STEP_MM,
                       'rounding':COORDINATE_ROUNDING})
        now = time.monotonic()
        self.tags[measurement.tag_id] = (measurement, now)
        if self.mode!='replay':self.known_points.add(measurement,self.profile.state,self.mode,received_monotonic=now)
        self.pending_measurements[measurement.tag_id] = measurement
        was_alarm = measurement.tag_id in self.map_panel.alarm_tags
        # Record every position; drawing still runs only on the display timer.
        self.map_panel.accept_measurement(measurement, redraw=False)
        self.map_pending_redraw = True
        self.ai.process(measurement)
        is_alarm = measurement.tag_id in self.map_panel.alarm_tags
        if is_alarm and not was_alarm:
            if measurement.fence_flags in (4,36):
                self.write_log(f'保留报警：T{measurement.tag_id}已有已确认越界状态，当前定位待确认。')
            else:
                self.fence_event_count += 1
                self.write_log(f"越界报警：T{measurement.tag_id}超出三角形安全区域。")
        elif was_alarm and not is_alarm:
            self.write_log(f"报警解除：T{measurement.tag_id}有效定位已返回安全区域。")

    def update_fence_status(self):
        if self.map_panel.history_replay:
            if self.replay.source_kind=='csv':
                values=[value for value,_ in self.tags.values()]
                alarms=sorted(self.map_panel.alarm_tags)
                if alarms:summary='历史越界报警：'+','.join(f'T{t}' for t in alarms);color='#b42318';background='#fff0ed'
                elif any(v.position_fault for v in values):summary='历史定位失效：原记录可信定位/围栏确认超时';color='#9a5700';background='#fff5df'
                elif any(not v.has_position for v in values):summary='历史定位质量异常 / 定位无效';color='#9a5700';background='#fff5df'
                elif any(v.pending_count for v in values):summary='历史疑似越界：'+','.join(f'T{v.tag_id} {v.pending_count}/3' for v in values if v.pending_count);color='#9a5700';background='#fff5df'
                else:summary='复现原记录定位及围栏状态';color='#315f9b';background='#e9f1ff'
                self.fence_label.setText(f'CSV回放 · {summary} · 非实时测量，硬件控制关闭')
                self.fence_label.setStyleSheet(f'background:{background};color:{color};padding:8px;border-radius:6px;')
                description='；'.join(f'T{v.tag_id}: {v.description}' for v in values) or '等待CSV首行'
                self.quality_label.setText('CSV原状态：'+description+'。复现原标志，不重跑FPGA质量检测；角度未保存。')
                self.quality_label.setStyleSheet('color:#9a5700;' if any(not v.has_position for v in values) else 'color:#617086;')
                return
            self.fence_label.setText('历史记录回放：旧基站/围栏参数未核对；仅复现原报文，不判断当前3米安全区，不控制蜂鸣器。')
            self.fence_label.setStyleSheet('background:#e9f1ff;color:#315f9b;padding:8px;border-radius:6px;')
            self.quality_label.setText('历史数据，非当前现场测量；未按新版质量算法重新检验，不作为当前安全或精度结论。')
            self.quality_label.setStyleSheet('color:#9a5700;');return
        now = time.monotonic()
        alarms = sorted(self.map_panel.alarm_tags)
        pending=[f"T{tag} {value.pending_count}/3次" for tag,(value,seen) in self.tags.items()
                 if value.pending_count and now-seen<=2]
        faults=[f'T{tag}' for tag,(value,seen) in self.tags.items() if value.position_fault and now-seen<=2]
        suspect=[f'T{tag}' for tag,(value,seen) in self.tags.items() if value.quality_untrusted and not value.position_fault and now-seen<=2]
        expired=[f'T{tag}' for tag,(_,seen) in self.tags.items() if now-seen>2]
        if self.mode=='idle':quality='未连接，质量无法判断；保留最后一次结果供参考。'
        elif expired:
            quality='数据过期，质量无法判断：'+','.join(expired)+'。'
            if faults:quality+=' 另有定位失效故障：'+','.join(faults)+'。'
            elif suspect:quality+=' 另有质量可疑：'+','.join(suspect)+'。'
        elif faults:quality='定位失效故障：'+','.join(faults)+'；可信测距超时或正在恢复，独立于围栏三次确认；不等同于Wi-Fi断线。'
        elif suspect:quality='定位质量可疑：'+','.join(suspect)+'；不作为安全位置或速度采样点。'
        elif self.mode=='idle' or not self.tags:quality='定位质量：等待可信测量。'
        else:quality='当前帧未报告质量异常；不代表能够排除所有遮挡偏差。'
        self.quality_label.setText(quality)
        self.quality_label.setStyleSheet('color:#9a5700;' if expired or faults or suspect else 'color:#617086;')
        if alarms:
            names = "、".join(f"T{tag}" for tag in alarms)
            uncertain = self.mode == "idle" or any(
                tag not in self.tags or not self.tags[tag][0].fence_known or now-self.tags[tag][1]>2
                for tag in alarms)
            text = f"越界报警：{names} 超出三角形安全区域！"
            if uncertain:text = f"越界报警（保留）：{names} 原始/滤波结果待确认，或当前定位无效、过期、连接断开；尚未确认返回安全区。"
            if faults:text+=' 定位失效故障：'+','.join(faults)+'；不是新的越界判定。'
            style = "background:#fff0ed;color:#b42318;border:1px solid #fda29b;"
        elif self.mode == "idle" or not self.tags:
            text = "围栏未就绪：未连接或尚未收到有效围栏数据。"
            style = "background:#fff5df;color:#935b00;"
        elif faults:
            text='定位失效故障：'+','.join(faults)+'；可信测距超时或等待3次新鲜有效测量恢复，安全状态未知；故障只提示，不单独蜂鸣。'
            style='background:#fff0d6;color:#9a5700;border:1px solid #e9b45d;'
        elif pending:
            text="疑似越界："+"、".join(pending)+"；连续3次才报警，返回安全区清零。"
            style="background:#fff5df;color:#935b00;"
        elif any(not value.fence_known or now-seen>2 for value,seen in self.tags.values()):
            text = "围栏无法判断：定位无效/数据过期，或旧版FPGA尚未上报围栏状态。"
            style = "background:#fff5df;color:#935b00;"
        else:
            if not self.profile.verified:
                text = "板端报围栏内，参数未核对，安全区设置待核对；继续接收监测，AI控制未授权。"
                style = "background:#fff5df;color:#935b00;"
            else:
                text = "安全：有效定位已确认在围栏内。越界连续3次报警；原始和滤波位置首次共同确认在区内就解除，无额外内侧距离要求。"
                style = "background:#eaf7ef;color:#1e6d46;"
        if self.fence_event_count:text += f" 本次已记录{self.fence_event_count}次越界。"
        if self.fence_label.text()!=text:self.fence_label.setText(text)
        stylesheet="QLabel {"+style+"padding:8px;border-radius:6px;}"
        if self.fence_label.styleSheet()!=stylesheet:self.fence_label.setStyleSheet(stylesheet)

    def show_measurement(self, measurement: Measurement, stale: bool):
        distances = [format_coordinate_m(v) if measurement.mask & (1 << i) else "—"
                     for i, v in enumerate(measurement.distances_mm)]
        if measurement.has_position:
            x, y, z = measurement.position_mm
            coordinates = [format_coordinate_m(v) for v in (x,y,z)]
        else:
            coordinates = ["—"] * 3
        details=measurement.description
        if stale:message="未连接" if self.mode=="idle" else "数据超时"
        elif measurement.position_fault:message='定位失效'
        elif measurement.quality_untrusted:message='质量可疑'
        else:message=details
        if self.map_panel.history_replay:message='历史 · '+message
        if measurement.tag_id in self.map_panel.alarm_tags and not measurement.outside_fence:
            message += "；保留越界报警"
        columns = [f"T{measurement.tag_id}", f"{measurement.mask:02X}", f"{measurement.sequence:02X}",
                   *distances, *coordinates, message]
        color = QColor("#8792a1" if stale else ALARM_COLOR if measurement.tag_id in self.map_panel.alarm_tags
                       else "#9a6700" if measurement.pending_count else "#235342" if measurement.has_position else "#a45b16")
        row = self.rows[measurement.tag_id]
        for column, value in enumerate(columns):
            item = self.table.item(row, column)
            if item is None:
                item = QTableWidgetItem()
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(row, column, item)
            item.setText(value)
            if column==9:item.setToolTip(details)
            item.setForeground(color)
        angle_columns = [f"T{measurement.tag_id}"] + [
            f"{measurement.azimuth_cdeg[i] / 100:.2f}" if measurement.has_azimuth(i) else "—"
            for i in range(3)]
        for column, value in enumerate(angle_columns):
            item = self.angle_table.item(row, column)
            if item is None:
                item = QTableWidgetItem()
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                item.setToolTip("从基站指向标签，相对统一坐标系+X轴逆时针；不是天线AoA测量。")
                self.angle_table.setItem(row, column, item)
            item.setText(value)
            item.setForeground(color)

    def update_statistics(self):
        if self.map_panel.history_replay and self.replay.source_kind=='csv':
            self.statistics.setText(f'CSV回放 {self.replay.index}/{len(self.replay.events)}行    原始CRC/字节未保存    角度未保存')
            return
        d = self.decoder
        self.statistics.setText(f"有效帧 {d.frames_received}    接收字节 {d.bytes_received}    "
                                f"CRC错误 {d.crc_errors}    格式错误 {d.format_errors}")

    def refresh_health(self):
        if self.profile:self.profile.tick()
        now = time.monotonic()
        map_changed = self.map_pending_redraw
        for tag, measurement in self.pending_measurements.items():
            if tag not in self.rows:
                self.rows[tag] = self.table.rowCount()
                self.table.insertRow(self.table.rowCount())
                self.angle_table.insertRow(self.angle_table.rowCount())
        self.pending_measurements.clear()
        self.pending_positions.clear()
        self.map_pending_redraw = False
        for measurement, last_seen in self.tags.values():
            stale = self.mode == "idle" or now - last_seen > 2
            self.show_measurement(measurement, stale)
            map_changed |= self.map_panel.set_stale(measurement.tag_id, stale,
                                                    measurement.has_position, redraw=False)
        if map_changed:
            self.map_panel.redraw()
        if self.mode=='replay':
            if self.replay.source_kind=='csv':
                ai_note='AI离线重算' if self.replay.metadata.get('geometry_matches_current') else '布局不同或未核对，当前AI不重算'
                self.statusBar().showMessage(f'CSV回放只读 · 原记录坐标/故障/围栏 · {ai_note} · 未保存角度及原始CRC')
            else:self.statusBar().showMessage('历史回放只读 · 原始坐标/测距/水平角 · 不作为实时测量、当前围栏或新模型风险结论')
        elif self.mode != "idle" and not self.tags and now - self.session_started > 2:
            self.statusBar().showMessage("尚未收到完整有效帧：检查数据源、波特率、帧头和CRC")
        elif self.mode != "idle" and self.tags and all(now - seen > 2 for _, seen in self.tags.values()):
            self.statusBar().showMessage("数据已超时：最后一次结果保留为灰色")
        else:
            self.statusBar().showMessage(
                f"显示刷新{self.refresh_box.currentData() / 1000:.1f}秒 · 实时接收FPGA坐标 · 超时阈值2秒")
        self.update_statistics()
        self.update_fence_status()
        refresh_dashboard(self)

    def closeEvent(self, event):
        self.known_points.active=False
        if self.known_point_dialog:self.known_point_dialog.close()
        self.ai.stop()
        if self.ai.recorder:
            self.ai.recorder.export(self.ai.client, self.decoder)
            self.ai.recorder.close()
            self.ai.recorder = None
        self.health_timer.stop()
        self.simulator.stop()
        self.replay.stop()
        self.serial.close_port()
        self.tcp.close()
        event.accept()

    def show_ai(self):
        # Legacy --ai launch option now focuses the embedded panel.
        self.right_scroll.ensureWidgetVisible(self.ai_panel.risk_label,0,0)
        self.ai_panel.setFocus()

    def send_profile_bytes(self,data):
        if self.mode=='serial':self.serial.send_bytes(data)
        elif self.mode=='tcp':self.tcp.send_bytes(data)
        else:raise RuntimeError('参数核对需要真实USB串口或Wi-Fi连接；模拟数据不作为板卡验证')

    def check_profile(self):
        if self.ai.enabled or self.ai.client.pending:
            self.write_log('请先结束AI联动并等待应答，再核对参数。');return
        self.profile.start();self.update_profile_status()

    def update_profile_status(self):
        if not self.profile:return
        self.profile_label.setText(self.profile.message)
        color='#1e6d46' if self.profile.verified else '#935b00'
        self.profile_label.setStyleSheet(f'color:{color};')

    def show_known_points(self):
        if self.known_point_dialog is None:self.known_point_dialog=KnownPointDialog(self)
        self.known_point_dialog.show();self.known_point_dialog.raise_()
