"""Site geometry for the overlay and simulator. Live alarms use FPGA flags."""
SITE_ANCHORS_MM = ((0., 0., 1000.), (3000., 0., 1000.), (1500., 2600., 1000.))
SITE_TAG_Z_MM = 0
FENCE_VERTICES_MM = tuple(point[:2] for point in SITE_ANCHORS_MM)
AI_MARGIN_SCALE_M = 1.5
AI_POSITION_BOUNDS_M = (-.5, 3.5, -.5, 3.)
AI_MAX_VELOCITY_MPS = 2.
AI_HORIZON_S = .7
ALARM_COLOR = "#d92d20"


def simulated_fence_flags(x, y):
    """Only the PC simulator uses this calculation; live receive never calls it."""
    a, b, c = FENCE_VERTICES_MM
    crosses = [(q[0]-p[0])*(y-p[1])-(q[1]-p[1])*(x-p[0])
               for p, q in ((a,b),(b,c),(c,a))]
    inside = all(v >= 0 for v in crosses) or all(v <= 0 for v in crosses)
    return 1 if inside else 3
