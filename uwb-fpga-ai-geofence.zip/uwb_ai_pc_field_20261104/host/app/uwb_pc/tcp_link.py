"""TCP接收端：ESP-01S作客户端，PC监听；每次只接收一个数据源。"""
from PySide6.QtCore import QObject, Signal
from PySide6.QtNetwork import QHostAddress, QTcpServer, QAbstractSocket


class TcpReceiver(QObject):
    bytes_received = Signal(bytes)
    peer_connected = Signal(str)
    connection_lost = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.server = QTcpServer(self)
        self.client = None
        self.server.newConnection.connect(self._accept_pending)

    def listen(self, port: int, address=None):
        if self.server.isListening():
            raise RuntimeError("TCP已经在监听。")
        if not 0 <= port <= 65535:
            raise ValueError("TCP端口应在1～65535之间。")
        # 0用于本机测试分配临时端口；用户界面只允许1～65535。
        address = address if address is not None else QHostAddress(QHostAddress.SpecialAddress.AnyIPv4)
        if not self.server.listen(address, port):
            raise RuntimeError(self.server.errorString())

    def close(self):
        self.server.close()
        client, self.client = self.client, None
        if client is not None:
            client.abort()
            client.deleteLater()

    def send_bytes(self, data: bytes):
        client = self.client
        if client is None or client.state() != QAbstractSocket.SocketState.ConnectedState:
            raise RuntimeError("Wi-Fi数据源尚未连接，不能发送控制指令")
        if client.bytesToWrite() > 65536 or client.write(data) != len(data):
            raise RuntimeError("TCP发送缓冲未接受完整控制指令")

    def _accept_pending(self):
        while self.server.hasPendingConnections():
            client = self.server.nextPendingConnection()
            if self.client is not None:
                client.abort()
                client.deleteLater()
                continue
            self.client = client
            client.setSocketOption(QAbstractSocket.SocketOption.LowDelayOption, 1)
            client.readyRead.connect(lambda sock=client: self._read(sock))
            client.disconnected.connect(lambda sock=client: self._disconnected(sock))
            self.peer_connected.emit(f"{client.peerAddress().toString()}:{client.peerPort()}")
            self._read(client)

    def _read(self, client):
        if client is not self.client:
            return
        data = bytes(client.readAll())
        if data:
            self.bytes_received.emit(data)

    def _disconnected(self, client):
        if client is not self.client:
            return
        # 对端可能发送完最后一段后立即关闭，先取完接收缓存。
        self._read(client)
        self.client = None
        client.deleteLater()
        self.connection_lost.emit("数据源已断开；继续监听，等待重新连接")
