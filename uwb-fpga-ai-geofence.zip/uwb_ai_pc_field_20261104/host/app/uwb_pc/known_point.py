"""Known-point field statistics from raw ranges and FPGA output, without correction writes."""
import csv
import json
import math
from pathlib import Path
import statistics
import time
from .geofence import SITE_ANCHORS_MM
from .coordinate_precision import centimeter_measurement,round_coordinates_mm

FIELDS=('schema','tag_id','sequence','status','mask','fence_flags','received_unix_s','received_monotonic_s',
        'truth_x_mm','truth_y_mm','truth_z_mm','d0_mm','d1_mm','d2_mm','x_mm','y_mm','z_mm',
        'profile_state','source','anchors_json','kind','exclude_reason')


def percentile(values,fraction):
    values=sorted(values);index=(len(values)-1)*fraction
    low=int(index);high=min(len(values)-1,low+1)
    return values[low]+(values[high]-values[low])*(index-low)


def is_fault_heartbeat(status,mask,flags,distances):
    # Firmware heartbeat shape, not a guess based on sequence continuity.
    # A real missing-range MC retains status bit0 (at least 0x11 in fault mode).
    return flags in (32,36) and mask&7==0 and status&0x7f==0x10 and all(d==0 for d in distances)


class KnownPointSession:
    def __init__(self):
        self.rows=[];self.active=False;self.truth=(0.,0.,0.);self.tag=2;self.last_sequence=None
        self._summary_cache=None

    def start(self,truth,tag=2):
        if len(truth)!=3 or any(not math.isfinite(v) or abs(v)>100000 for v in truth):raise ValueError('Known XYZ must be finite millimeters within +/-100m')
        if not 0<=tag<=8:raise ValueError('Tag must be 0..8')
        self.truth=tuple(float(v) for v in truth);self.tag=tag;self.active=True;self.last_sequence=None

    def add(self,value,profile_state,source,received_unix=None,received_monotonic=None):
        if not self.active or value.tag_id!=self.tag:return False
        value=centimeter_measurement(value)
        heartbeat=is_fault_heartbeat(value.status,value.mask,value.fence_flags,value.distances_mm)
        kind='fault_heartbeat' if heartbeat else 'duplicate' if value.sequence==self.last_sequence else 'measurement'
        reason='定位故障心跳，不增加测量分母' if kind=='fault_heartbeat' else '重复序号，不重复计次' if kind=='duplicate' else ''
        if kind=='measurement':self.last_sequence=value.sequence
        if not value.has_position and not reason:reason=value.description
        row=dict(zip(FIELDS,(2,value.tag_id,value.sequence,value.status,value.mask,-1 if value.fence_flags is None else value.fence_flags,
                 time.time() if received_unix is None else received_unix,
                 time.monotonic() if received_monotonic is None else received_monotonic,
                 *self.truth,*value.distances_mm,*value.position_mm,str(profile_state),str(source),
                 json.dumps(SITE_ANCHORS_MM,separators=(',',':')),kind,reason)))
        self.rows.append(row)
        self._summary_cache=None
        if len(self.rows)>=100000:self.active=False
        return kind=='measurement' and value.has_position

    def summary(self):
        if not self.rows:return {'count':0}
        if self._summary_cache is not None:return self._summary_cache
        errors=[];dxs=[];dys=[];biases=[[],[],[]]
        measurements=[r for r in self.rows if r['kind']=='measurement']
        for row in measurements:
            truth=tuple(float(row[k]) for k in ('truth_x_mm','truth_y_mm','truth_z_mm'))
            if int(row['status'])&0x7f==0 and int(row['mask'])&7==7 and int(row['fence_flags']) not in (32,36):
                dx=float(row['x_mm'])-truth[0];dy=float(row['y_mm'])-truth[1]
                dxs.append(dx);dys.append(dy);errors.append(math.hypot(dx,dy))
            for i,a in enumerate(json.loads(row['anchors_json'])):
                if int(row['mask'])&(1<<i) and 0<float(row[f'd{i}_mm'])<=60000:
                    biases[i].append(float(row[f'd{i}_mm'])-math.dist(truth,a))
        self._summary_cache=dict(count=len(errors),received_count=len(self.rows),measurement_count=len(measurements),
                    invalid_count=len(measurements)-len(errors),fault_count=sum(r['kind']=='fault_heartbeat' for r in self.rows),
                    duplicate_count=sum(r['kind']=='duplicate' for r in self.rows),
                    valid_ratio=len(errors)/len(measurements) if measurements else None,
                    xy_rmse_mm=math.sqrt(statistics.mean(v*v for v in errors)) if errors else None,
                    xy_p95_mm=percentile(errors,.95) if errors else None,
                    x_bias_mm=statistics.mean(dxs) if dxs else None,y_bias_mm=statistics.mean(dys) if dys else None,
                    range_count=[len(v) for v in biases],
                    range_bias_mm=[statistics.mean(v) if v else None for v in biases],
                    range_std_mm=[statistics.pstdev(v) if v else None for v in biases],
                    unverified_count=sum(r['profile_state']!='verified' for r in self.rows),
                    simulated_count=sum(r['source'] not in ('serial','tcp') for r in self.rows))
        return self._summary_cache

    def export_csv(self,path):
        with Path(path).open('w',encoding='utf-8-sig',newline='') as file:
            writer=csv.DictWriter(file,fieldnames=FIELDS);writer.writeheader();writer.writerows(self.rows)

    def load_csv(self,path):
        rows=[]
        with Path(path).open(encoding='utf-8-sig',newline='') as file:
            reader=csv.DictReader(file)
            if tuple(reader.fieldnames or ())!=FIELDS:raise ValueError('CSV字段与本版已知点统计格式不符')
            for raw in reader:
                row={}
                for key in FIELDS:
                    v=raw[key]
                    if key in ('profile_state','source','anchors_json','kind','exclude_reason'):row[key]=v
                    else:
                        number=float(v)
                        if not math.isfinite(number):raise ValueError('CSV含非有限数值')
                        row[key]=number
                if row['schema']!=2 or not 0<=row['tag_id']<=8 or not 0<=row['sequence']<=255 or not 0<=row['status']<=255 or not 0<=row['mask']<=255:
                    raise ValueError('CSV帧字段超范围')
                if any(not row[k].is_integer() for k in ('schema','tag_id','sequence','status','mask','fence_flags')):raise ValueError('CSV整数字段无效')
                if any(abs(row[k])>100000 for k in ('truth_x_mm','truth_y_mm','truth_z_mm')):raise ValueError('CSV已知点坐标超范围')
                for key in ('x_mm','y_mm','z_mm'):
                    value=row[key]
                    # int32 endpoints may round outward to +/-2147483650 mm.
                    if not value.is_integer() or not (-0x80000000<=value<=0x7fffffff or value in (-2147483650,2147483650)):
                        raise ValueError('CSV解算坐标必须为int32或其厘米取整端点')
                if row['kind'] not in ('measurement','duplicate','fault_heartbeat'):raise ValueError('CSV行类型无效')
                anchors=json.loads(row['anchors_json'])
                if len(anchors)!=3 or any(len(a)!=3 or any(not isinstance(v,(int,float)) or not math.isfinite(v) or abs(v)>100000 for v in a) for a in anchors):raise ValueError('CSV基站坐标无效')
                if any(not row[f'd{i}_mm'].is_integer() or not 0<=row[f'd{i}_mm']<=0xffffffff for i in range(3)):raise ValueError('CSV原始距离必须为uint32')
                if row['fence_flags'] not in (-1,0,1,3,4,8,16,32,36):raise ValueError('CSV状态字段无效')
                heartbeat=is_fault_heartbeat(int(row['status']),int(row['mask']),int(row['fence_flags']),tuple(row[f'd{i}_mm'] for i in range(3)))
                if (row['kind']=='fault_heartbeat')!=heartbeat:raise ValueError('CSV故障心跳结构或类型不一致')
                for key,v in zip(('x_mm','y_mm','z_mm'),round_coordinates_mm(tuple(int(row[k]) for k in ('x_mm','y_mm','z_mm')))):row[key]=v
                rows.append(row)
                if len(rows)>100000:raise ValueError('CSV超过100000行采样上限')
        self.rows=rows;self.active=False;self.last_sequence=None;self._summary_cache=None
