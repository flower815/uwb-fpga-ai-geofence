"""Preserve millimeter coordinates; round only the displayed metre labels."""
from dataclasses import replace
from decimal import Decimal,ROUND_HALF_UP

COORDINATE_STEP_MM=1
TELEMETRY_COORDINATE_STEP_MM=1
COORDINATE_ROUNDING='half_away_from_zero'


def round_coordinate_mm(value):
    """Keep every protocol millimeter, including signed integer endpoints.

    Integer receive values are rounded without float conversion or ties-to-even.
    Decimal conversion is only needed for display-filter intermediate results.
    """
    if isinstance(value,int):
        return value
    number=Decimal(str(value))
    if not number.is_finite():raise ValueError('Coordinate must be finite')
    return int(number.quantize(Decimal('1'),rounding=ROUND_HALF_UP))


def round_coordinates_mm(point):return tuple(round_coordinate_mm(v) for v in point)


def format_coordinate_m(value):
    """One displayed decimal, independently of the stored millimeter value."""
    shown=(Decimal(str(value))/1000).quantize(Decimal('0.1'),rounding=ROUND_HALF_UP)
    if shown==0:shown=abs(shown)
    return format(shown,'.1f')


def centimeter_measurement(value):
    # Legacy public helper name retained for callers; current resolution is 1mm.
    position=round_coordinates_mm(value.position_mm)
    return value if position==value.position_mm else replace(value,position_mm=position)


def telemetry_measurement(value):
    """Match FPGA v5.6 wire resolution without dropping integer millimeters."""
    def quantize(v):
        q=int((Decimal(str(v))/TELEMETRY_COORDINATE_STEP_MM).quantize(Decimal('1'),rounding=ROUND_HALF_UP))*TELEMETRY_COORDINATE_STEP_MM
        return q
    return replace(value,position_mm=tuple(quantize(v) for v in value.position_mm))
