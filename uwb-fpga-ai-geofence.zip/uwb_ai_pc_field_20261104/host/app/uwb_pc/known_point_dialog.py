"""Field capture/replay UI. The ground-truth point is supplied by the operator."""
from PySide6.QtCore import QTimer,Qt
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QDoubleSpinBox,QSpinBox,
                              QPushButton,QFileDialog,QMessageBox)


class KnownPointDialog(QDialog):
    def __init__(self,window):
        super().__init__(window);self.window=window;self.session=window.known_points
        self.setWindowTitle('已知点误差统计 / CSV回放');self.resize(850,520)
        layout=QVBoxLayout(self)
        note=QLabel('人工测量标签天线中心的已知XYZ。XYZ使用与基站相同的参考平面；Z是配置高度，不是三基站实测高度。\n'
                    '距离误差使用三维斜距真值。\n'
                    '未核对固件也允许采集，但逐行标记未核对；模拟数据会标记demo。仅统计CRC通过、可识别目标ID的帧，坏CRC由主窗口单列。统计不会自动写入距离补偿。')
        note.setWordWrap(True);layout.addWidget(note)
        line=QHBoxLayout();self.tag=QSpinBox();self.tag.setRange(0,8);self.tag.setValue(2)
        line.addWidget(QLabel('标签ID'));line.addWidget(self.tag);self.coordinates=[]
        for label in ('X/mm','Y/mm','Z/mm'):
            line.addWidget(QLabel(label));box=QDoubleSpinBox();box.setRange(-100000,100000);box.setDecimals(1)
            self.coordinates.append(box);line.addWidget(box)
        layout.addLayout(line)
        actions=QHBoxLayout();self.start=QPushButton('开始采样');self.start.clicked.connect(self.toggle)
        actions.addWidget(self.start)
        for label,callback in [('导出CSV',self.export),('回放CSV',self.replay),('清空统计',self.clear)]:
            button=QPushButton(label);button.clicked.connect(callback);actions.addWidget(button)
        layout.addLayout(actions)
        self.result=QLabel();self.result.setWordWrap(True)
        self.result.setAlignment(Qt.AlignmentFlag.AlignTop|Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(self.result,1)
        self.message=QLabel('仅在标签静止于已知点时采集；移动到新点后先停止并重新填写XYZ。')
        self.message.setWordWrap(True);layout.addWidget(self.message)
        self.timer=QTimer(self);self.timer.setInterval(500);self.timer.timeout.connect(self.refresh);self.timer.start();self.refresh()

    def toggle(self):
        if self.session.active:self.session.active=False
        elif self.window.map_panel.history_replay:
            self.message.setText('历史回放缺少已核对基站参数与已知点真值，不能当作当前现场采样。仍可使用回放CSV查看已有统计。');return
        else:self.session.start(tuple(b.value() for b in self.coordinates),self.tag.value())
        self.refresh()

    def refresh(self):
        self.start.setText('停止采样' if self.session.active else '开始采样')
        for widget in [self.tag,*self.coordinates]:widget.setEnabled(not self.session.active)
        s=self.session.summary()
        if not s.get('received_count'):self.result.setText('尚无接收样本。统计保留无效样本及原因，故障心跳/重复序号单列。');return
        fmt=lambda v:'—' if v is None else f'{v:.1f}'
        distances='\n'.join(f'd{i}：有效距离数 {s["range_count"][i]}，平均偏差 {fmt(b)}mm，标准差 {fmt(d)}mm' for i,(b,d) in enumerate(zip(s['range_bias_mm'],s['range_std_mm'])))
        ratio='—' if s['valid_ratio'] is None else f'{s["valid_ratio"]*100:.1f}%'
        self.result.setText(f"测量分母：{s['measurement_count']}；有效XY：{s['count']}；无效XY：{s['invalid_count']}；有效率：{ratio}\n"
                            f"故障心跳：{s['fault_count']}；重复序号：{s['duplicate_count']}（单列，不增加测量分母）\n"
                            f"参数未核对接收行：{s['unverified_count']}；非实物来源行：{s['simulated_count']}\n"
                            f"XY RMSE：{fmt(s['xy_rmse_mm'])}mm；XY误差P95：{fmt(s['xy_p95_mm'])}mm（仅有效XY子集）\n"
                            f"X平均偏差：{fmt(s['x_bias_mm'])}mm；Y平均偏差：{fmt(s['y_bias_mm'])}mm\n\n{distances}\n\n"
                            '误差包含人工真值误差，统计结果不是自动认证的定位精度。未核对配置的数据不能标为已验证。')

    def export(self):
        path,_=QFileDialog.getSaveFileName(self,'导出已知点原始样本','known_point.csv','CSV (*.csv)')
        if path:
            try:self.session.export_csv(path);self.message.setText('已导出逐样本CSV：'+path)
            except OSError as exc:QMessageBox.warning(self,'导出失败',str(exc))

    def replay(self):
        if self.session.active:self.message.setText('请先停止采样，再回放CSV。');return
        path,_=QFileDialog.getOpenFileName(self,'回放已知点CSV','','CSV (*.csv)')
        if path:
            try:self.session.load_csv(path);self.message.setText('已载入历史CSV，按历史记录规则重新统计，当前不是实时测试：'+path);self.refresh()
            except (OSError,ValueError,KeyError,TypeError) as exc:QMessageBox.warning(self,'回放失败',str(exc))

    def clear(self):
        self.session.active=False;self.session.rows.clear();self.session.last_sequence=None;self.session._summary_cache=None;self.refresh()

    def closeEvent(self,event):
        self.session.active=False;self.timer.stop();event.accept()

    def showEvent(self,event):
        self.timer.start();self.refresh();super().showEvent(event)
