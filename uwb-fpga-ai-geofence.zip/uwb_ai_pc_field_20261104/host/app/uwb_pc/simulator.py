"""第4课：构造测试字节，通过真实解析器验证界面，而不是直接填表。"""
import math
import time
from PySide6.QtCore import QObject, QTimer, Signal
from .protocol import Measurement, encode_measurement
from .coordinate_precision import telemetry_measurement
from .geofence import SITE_ANCHORS_MM, SITE_TAG_Z_MM, simulated_fence_flags


class Simulator(QObject):
    bytes_received = Signal(bytes)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.timer = QTimer(self)
        self.timer.setInterval(500)
        self.timer.timeout.connect(self.tick)
        self.sequence = 0
        self.scenario = "normal"
        self.outside_hits=0
        self.fence_latched=False
        self.last_tick=None

    def start(self):
        self.sequence = 0
        self.outside_hits=0;self.fence_latched=False;self.last_tick=None
        self.timer.start()
        self.tick()

    def stop(self):
        self.timer.stop()

    def _update_fence(self,position,valid=True):
        if not valid:
            self.outside_hits=0
            return 4 if self.fence_latched else 0
        if simulated_fence_flags(*position[:2])==1:
            self.outside_hits=0
            self.fence_latched=False
            return 1
        self.outside_hits=min(3,self.outside_hits+1)
        if self.outside_hits==3:self.fence_latched=True
        return 3 if self.fence_latched else 8 if self.outside_hits==1 else 16

    def tick(self):
        if self.scenario == "paused":
            return
        now=time.monotonic()
        if self.last_tick is not None and now-self.last_tick>=1:self.outside_hits=0
        self.last_tick=now
        angle = self.sequence / 20
        position = (round(1500 + 500 * math.cos(angle)),
                    round(1000 + 450 * math.sin(angle)), SITE_TAG_Z_MM)
        if self.scenario == "fence":
            path = [(1500,850),(2250,1250),(2500,1500),(3250,900),(3100,1400),
                    (1500,100),(1500,850),(1600,850),(1400,850)]
            position = (*path[self.sequence % len(path)],SITE_TAG_Z_MM)
        anchors = SITE_ANCHORS_MM
        distances = tuple(round(math.dist(position, anchor)) for anchor in anchors)
        azimuths = tuple(round(math.degrees(math.atan2(position[1]-a[1], position[0]-a[0]))*100)%36000
                         if position[:2] != a[:2] else 0xFFFF for a in anchors)
        angle_mask = sum(1 << i for i, value in enumerate(azimuths) if value != 0xFFFF)
        flags=self._update_fence(position,self.scenario!='missing')
        record = Measurement(0, 7, self.sequence & 0xFF, 2, distances, position, azimuths, angle_mask,flags)
        if self.scenario == "missing":
            record = Measurement(1, 1, self.sequence & 0xFF, 2, (328, 0, 0), (0, 0, 0), (0xFFFF,)*3, 0, flags)
        packet = bytearray(encode_measurement(telemetry_measurement(record)))
        if self.scenario == "crc_error":
            packet[12] ^= 1
        self.sequence += 1
        # 故意拆成两段，保证接收方真的使用了缓存逻辑。
        self.bytes_received.emit(bytes(packet[:9]))
        self.bytes_received.emit(bytes(packet[9:]))
