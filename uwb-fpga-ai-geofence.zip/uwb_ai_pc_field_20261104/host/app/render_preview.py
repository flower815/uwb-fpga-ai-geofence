"""开发用：不连接硬件，生成示例地图及模拟界面截图。"""
import os
os.environ["QT_QPA_PLATFORM"] = "offscreen"
from pathlib import Path
from PySide6.QtWidgets import QApplication
from uwb_pc.map_widget import demo_image,demo_transform
from uwb_pc.ui_fonts import configure_font
from uwb_pc.window import MainWindow


def main():
    root = Path(__file__).resolve().parent
    app = QApplication([])
    configure_font(app)
    window = MainWindow()
    window.resize(1480, 880)
    window.hex_check.setChecked(False)
    window.scenario_box.setCurrentIndex(window.scenario_box.findData('normal'))
    window.toggle_demo()
    window.simulator.stop()
    for _ in range(110):
        window.simulator.tick()
        window.refresh_health()
    window.show()
    app.processEvents()
    window.map_panel.canvas.fit_map()
    app.processEvents()
    if not window.grab().save(str(root / "preview.png")):
        raise RuntimeError("截图保存失败")
    examples = root / "examples"
    examples.mkdir(exist_ok=True)
    if not demo_image().save(str(examples / "demo_map.png")):
        raise RuntimeError("示例地图保存失败")
    window.map_panel.load_image(examples / "demo_map.png")
    window.map_panel.calibration = demo_transform()
    window.map_panel.save_config(examples / "demo_map_config.json")
    window.close()
    app.shutdown()


if __name__ == "__main__":
    main()
