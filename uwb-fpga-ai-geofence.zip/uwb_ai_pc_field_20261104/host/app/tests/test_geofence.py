import binascii
from dataclasses import replace
import os
import struct
import time
import unittest

os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QCoreApplication,QEvent
from uwb_pc.protocol import Measurement,FrameDecoder,encode_measurement
from uwb_pc.window import MainWindow
from uwb_pc.geofence import ALARM_COLOR,FENCE_VERTICES_MM

APP=QApplication.instance() or QApplication([])


def record(position=(3000,1700,1000),flags=1,tag=2,seq=1):
    return Measurement(0,7,seq,tag,(5000,)*3,position,(65535,)*3,0,flags)


class FenceProtocolTests(unittest.TestCase):
    def test_confirmation_pending_flags_are_not_alarm(self):
        for flags,count in [(8,1),(16,2)]:
            value=record(flags=flags)
            self.assertEqual(FrameDecoder().feed(encode_measurement(value)),[value])
            self.assertEqual(value.pending_count,count)
            self.assertFalse(value.fence_known)
            self.assertFalse(value.fence_alarm)
            self.assertIn(f"{count}/3",value.description)
            with self.assertRaises(ValueError):encode_measurement(replace(value,status=1))
    def test_independent_v3_frame(self):
        value=record((6500,1000,1000),3)
        packet=bytearray(42)
        packet[:8]=bytes.fromhex("55 aa 03 00 07 01 02 00")
        struct.pack_into("<IIIiiiBBHHH",packet,8,5000,5000,5000,6500,1000,1000,0,3,65535,65535,65535)
        packet[40:]=binascii.crc_hqx(packet[:40],0xffff).to_bytes(2,"little")
        self.assertEqual(encode_measurement(value),packet)
        self.assertEqual(FrameDecoder().feed(packet),[value])
        self.assertTrue(value.outside_fence)

    def test_all_splits_and_mixed_v1_v2_v3(self):
        value=record();packet=encode_measurement(value)
        for i in range(43):
            decoder=FrameDecoder()
            self.assertEqual(decoder.feed(packet[:i])+decoder.feed(packet[i:]),[value])
        v1=replace(value,fence_flags=None,azimuth_cdeg=None)
        v2=replace(value,fence_flags=None)
        decoder=FrameDecoder()
        self.assertEqual(decoder.feed(encode_measurement(v1)+encode_measurement(v2)+packet),[v1,v2,value])

    def test_invalid_flags_and_invalid_positions_rejected(self):
        packet=encode_measurement(record())
        for flags in (2,5,0x80,0xff):
            bad=bytearray(packet);bad[33]=flags
            bad[40:]=binascii.crc_hqx(bad[:40],0xffff).to_bytes(2,"little")
            decoder=FrameDecoder()
            self.assertEqual(decoder.feed(bad+packet),[record()])
            self.assertEqual(decoder.format_errors,1)
        with self.assertRaises(ValueError):encode_measurement(replace(record(),status=1))
        unknown=replace(record(),status=1,mask=1,fence_flags=0)
        self.assertEqual(FrameDecoder().feed(encode_measurement(unknown)),[unknown])
        self.assertFalse(unknown.fence_known)

    def test_crc_damage_cannot_raise_alarm(self):
        decoder=FrameDecoder();bad=bytearray(encode_measurement(record(flags=3)));bad[33]^=1
        self.assertEqual(decoder.feed(bad),[])
        self.assertEqual(decoder.crc_errors,1)


class FenceWindowTests(unittest.TestCase):
    def setUp(self):
        self.window=MainWindow();self.window.mode="serial";self.window.hex_check.setChecked(False)

    def tearDown(self):
        self.window.close();self.window.deleteLater()
        QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);APP.processEvents()

    def deliver(self,value):
        self.window.serial.bytes_received.emit(encode_measurement(value))

    def test_first_two_pending_frames_are_yellow_without_red_alarm(self):
        for seq,flags in [(1,8),(2,16)]:
            self.deliver(record(flags=flags,seq=seq))
            self.assertFalse(self.window.map_panel.alarm_tags)
            self.assertEqual(self.window.fence_event_count,0)
            self.assertIn(f"{seq}/3",self.window.fence_label.text())
            self.assertIn("疑似越界",self.window.fence_label.text())
        self.deliver(record(flags=3,seq=3))
        self.assertEqual(self.window.map_panel.alarm_tags,{2})
        self.assertEqual(self.window.fence_event_count,1)
        self.deliver(record(flags=1,seq=4))
        self.assertFalse(self.window.map_panel.alarm_tags)

    def test_pending_reset_does_not_accumulate_across_inside_frames(self):
        for seq,flags in enumerate([8,16,1,8,1,8,16],1):self.deliver(record(flags=flags,seq=seq))
        self.assertFalse(self.window.map_panel.alarm_tags)
        self.assertEqual(self.window.fence_event_count,0)

    def test_immediate_alarm_and_wire_authority(self):
        self.deliver(record((3000,1700,1000),3)) # Deliberately inconsistent XY: flags are authoritative.
        self.assertIn("越界报警",self.window.fence_label.text())
        self.assertEqual(self.window.table.rowCount(),0) # No forced redraw on every frame.
        self.assertIn(2,self.window.map_panel.alarm_tags)
        self.window.refresh_health()
        self.assertEqual(self.window.table.item(0,9).foreground().color().name(),ALARM_COLOR)
        self.deliver(record((9000,9000,1000),1))
        self.assertNotIn(2,self.window.map_panel.alarm_tags) # PC must not recalculate a different fence result.

    def test_crossing_between_refreshes_keeps_red_history(self):
        points=[record(seq=1),record((3400,1700,1000),3,seq=2),record((3000,1800,1000),1,seq=3)]
        self.window.receive_bytes(b"".join(encode_measurement(p) for p in points))
        self.assertEqual(self.window.fence_event_count,1)
        self.assertEqual(list(self.window.map_panel.trail_alarms[2]),[False,True,False])
        self.assertEqual(len(self.window.map_panel.trails[2]),3)
        self.assertIn("安全",self.window.fence_label.text())
        self.window.refresh_health()
        red=[item for item in self.window.map_panel.canvas.scene().items() if item.data(0)=="trail_alarm"]
        self.assertEqual(len(red),1)
        self.assertEqual(red[0].pen().color().name(),ALARM_COLOR)
        self.assertIn("报警解除",self.window.log.toPlainText())

    def test_invalid_stale_disconnect_do_not_clear_alarm(self):
        self.deliver(record((6500,1000,1000),3))
        invalid=replace(record(),status=1,mask=1,fence_flags=0)
        self.deliver(invalid);self.window.refresh_health()
        self.assertIn(2,self.window.map_panel.alarm_tags)
        self.assertIn("保留",self.window.fence_label.text())
        self.window.tags[2]=(invalid,time.monotonic()-3);self.window.refresh_health()
        self.assertIn("越界报警",self.window.fence_label.text())
        self.window.mode="idle";self.window.refresh_health()
        self.assertIn("连接断开",self.window.fence_label.text())
        self.window.mode="serial";self.deliver(record())
        self.assertNotIn(2,self.window.map_panel.alarm_tags)

    def test_old_firmware_unknown_and_bad_crc(self):
        legacy=replace(record(),fence_flags=None)
        self.deliver(legacy)
        self.assertIn("无法判断",self.window.fence_label.text())
        bad=bytearray(encode_measurement(record(flags=3)));bad[12]^=1
        self.window.receive_bytes(bad)
        self.assertFalse(self.window.map_panel.alarm_tags)
        self.window.reset_session()
        self.assertIn("未就绪",self.window.fence_label.text())

    def test_retained_alarm_on_fresh_connection(self):
        held=replace(record(),status=1,mask=1,fence_flags=4)
        self.deliver(held)
        self.assertIn(2,self.window.map_panel.alarm_tags)
        self.assertIn("保留",self.window.fence_label.text())
        self.assertFalse(self.window.map_panel.positions) # No made-up (0,0) marker.
        self.deliver(record())
        self.assertFalse(self.window.map_panel.alarm_tags)

    def test_per_tag_latches_and_bounded_history(self):
        self.deliver(record((6500,1000,1000),3,tag=2))
        self.deliver(record(tag=3))
        self.assertEqual(self.window.map_panel.alarm_tags,{2})
        for i in range(510):self.deliver(record((3000+i*10,1500,1000),1,tag=3,seq=i&255))
        self.assertEqual(len(self.window.map_panel.trails[3]),500)
        self.assertEqual(len(self.window.map_panel.trail_alarms[3]),500)
        self.window.map_panel.clear_trails()
        self.assertIn(2,self.window.map_panel.alarm_tags) # Clearing history is not an alarm acknowledgement.

    def test_overlay_matches_exact_requested_triangle(self):
        self.window.map_panel.redraw()
        polygon=[i for i in self.window.map_panel.canvas.scene().items() if i.data(0)=="geofence"][0].polygon()
        expected=[self.window.map_panel.calibration.world_to_pixel(*p) for p in FENCE_VERTICES_MM]
        self.assertEqual([(p.x(),p.y()) for p in polygon],expected)
