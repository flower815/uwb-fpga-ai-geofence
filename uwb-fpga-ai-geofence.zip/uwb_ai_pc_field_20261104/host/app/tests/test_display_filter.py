import math
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import unittest
from dataclasses import replace
from unittest.mock import patch
from PySide6.QtWidgets import QApplication
from uwb_pc.display_filter import DisplayTracker
from uwb_pc.map_widget import MapPanel
from uwb_pc.protocol import Measurement
from uwb_pc.geofence import SITE_ANCHORS_MM

APP=QApplication.instance() or QApplication([])


class DisplayFilterTests(unittest.TestCase):
    def test_static_jitter_reduced_without_changing_raw_input(self):
        tracker=DisplayTracker();raw=[];filtered=[]
        for i in range(200):
            x=1500+(80 if i%2 else -80)
            point=(x,850);result,_=tracker.update(2,point,i*.1+1)
            self.assertEqual(point,(x,850))
            if i>30:raw.append(x-1500);filtered.append(result[0]-1500)
        self.assertLess(sum(v*v for v in filtered),.4*sum(v*v for v in raw))

    def test_gap_jump_and_multitag_reset_without_clamping(self):
        tracker=DisplayTracker()
        tracker.update(2,(0,0),1);tracker.update(3,(8000,0),1)
        self.assertFalse(tracker.update(2,(100,0),1.1)[1])
        self.assertEqual(tracker.update(2,(5000,0),1.2),((5000.,0.),True))
        self.assertEqual(tracker.update(3,(8100,0),3),((8100.,0.),True))
        tracker.reset(2)
        self.assertTrue(tracker.update(2,(-5000,0),3)[1])

    def test_constant_speed_tracking_and_change_of_direction(self):
        tracker=DisplayTracker();errors=[]
        for i in range(100):
            p=(500+i*10,850)
            result,_=tracker.update(2,p,1+i*.1)
            self.assertFalse(tracker.is_stationary(2))
            if i>40:errors.append(math.dist(p,result))
        self.assertLess(max(errors),5)
        for i in range(1,40):result,_=tracker.update(2,(1490-i*10,850),10.9+i*.1)
        self.assertLess(abs(result[0]-1100),10)

    def test_repeated_target_clears_velocity_without_overshoot(self):
        tracker=DisplayTracker();tracker.update(2,(1000,1000),1)
        tracker.update(2,(1100,1000),1.1)
        for i in range(2,12):
            result,_=tracker.update(2,(1100,1000),1+i*.1)
            self.assertEqual(result,(1100.,1000.))
            self.assertEqual(tracker.states[2][3],(0.,0.))

    def test_stationary_cluster_holds_but_outlier_and_real_movement_are_distinct(self):
        tracker=DisplayTracker();pattern=[(0,0),(30,20),(-30,-20),(10,30),(-20,-10),(40,0),(-20,20),(0,-20)]
        for i in range(25):
            dx,dy=pattern[i%len(pattern)]
            result,_=tracker.update(2,(1500+dx,850+dy),1+i*.1)
        self.assertTrue(tracker.is_stationary(2));held=result
        for i in range(25,50):
            dx,dy=pattern[i%len(pattern)]
            self.assertEqual(tracker.update(2,(1500+dx,850+dy),1+i*.1)[0],held)
        # One distant sample and opposite spikes do not unlock the display.
        tracker.update(2,(held[0]+180,held[1]),6)
        self.assertEqual(tracker.update(2,held,6.1)[0],held)
        tracker.update(2,(held[0]+180,held[1]),6.2)
        tracker.update(2,(held[0]-180,held[1]),6.4)
        self.assertTrue(tracker.is_stationary(2))
        tracker.update(2,held,6.5)
        tracker.update(2,(held[0]+150,held[1]),6.6)
        self.assertTrue(tracker.is_stationary(2))
        tracker.update(2,(held[0]+170,held[1]),6.8)
        self.assertFalse(tracker.is_stationary(2))
        # A burst of outside points under 0.15 seconds is not confirmed travel.
        for i in range(4):tracker.update(3,(0,0),8+i*.2)
        self.assertTrue(tracker.is_stationary(3))
        tracker.update(3,(150,0),8.7);tracker.update(3,(160,0),8.75)
        self.assertTrue(tracker.is_stationary(3))
        tracker.update(3,(170,0),8.9)
        self.assertFalse(tracker.is_stationary(3))
        tracker.reset(2)
        self.assertFalse(tracker.is_stationary(2));self.assertNotIn(2,tracker.windows)

    def test_lock_is_per_tag_and_gap_or_jump_starts_new_segment(self):
        tracker=DisplayTracker()
        for i in range(5):tracker.update(2,(1500,850),1+i*.2)
        self.assertTrue(tracker.is_stationary(2))
        for i in range(12):tracker.update(3,(500+i*30,850),1+i*.1)
        self.assertTrue(tracker.is_stationary(2));self.assertFalse(tracker.is_stationary(3))
        self.assertEqual(tracker.update(2,(1510,850),3),((1510.,850.),True))
        self.assertFalse(tracker.is_stationary(2))
        for i in range(1,6):tracker.update(2,(1510,850),3+i*.2)
        self.assertTrue(tracker.is_stationary(2))
        self.assertEqual(tracker.update(2,(5000,850),4.1),((5000.,850.),True))
        self.assertFalse(tracker.is_stationary(2))
        tracker.reset();self.assertFalse(tracker.states);self.assertFalse(tracker.stationary)


    def test_map_lock_does_not_replace_received_ai_or_known_point_coordinates(self):
        from uwb_pc.window import MainWindow
        from uwb_pc.protocol import encode_measurement
        window=MainWindow();window.mode='demo';window.known_points.start((1500,850,0),2)
        pattern=[(0,0),(30,20),(-30,-20),(10,30),(-20,-10),(40,0),(-20,20),(0,-20)]
        displayed=[]
        try:
            for i in range(16):
                dx,dy=pattern[i%len(pattern)];position=(1500+dx,850+dy,0)
                value=Measurement(0,7,i,2,(2000,)*3,position,(65535,)*3,0,1)
                with patch('uwb_pc.display_filter.time.monotonic',return_value=1+i*.2):
                    window.receive_bytes(encode_measurement(value))
                displayed.append(window.map_panel.display_positions[2])
                self.assertEqual(window.tags[2][0].position_mm,position)
                self.assertEqual(window.ai.engine.history[2][-1][1:],tuple(v/1000 for v in position[:2]))
                self.assertEqual(tuple(window.known_points.rows[-1][k] for k in ('x_mm','y_mm','z_mm')),position)
            self.assertTrue(window.map_panel.tracker.is_stationary(2))
            self.assertEqual(len(set(displayed[8:])),1)
            self.assertNotEqual(window.map_panel.display_positions[2],window.map_panel.positions[2])
            window.map_panel.smooth_check.setChecked(False)
            self.assertEqual(window.map_panel.positions[2],position[:2])
            self.assertEqual(len(window.known_points.rows),16)
        finally:window.close();window.deleteLater();APP.processEvents()

    def test_map_raw_toggle_and_gap_preserve_alarm_and_measurements(self):
        panel=MapPanel()
        try:
            a=Measurement(0,7,1,2,(2000,)*3,(1500,850,0),(65535,)*3,0,1)
            b=Measurement(0,7,2,2,(2000,)*3,(1600,850,0),(65535,)*3,0,1)
            with patch('uwb_pc.display_filter.time.monotonic',side_effect=[1,1.1,1.2,3]):
                panel.accept_measurement(a);panel.accept_measurement(b)
                self.assertEqual(panel.positions[2],(1600,850))
                self.assertNotEqual(panel.display_positions[2],panel.positions[2])
                panel.accept_measurement(replace(b,fence_flags=3))
                self.assertEqual(panel.display_positions[2],panel.positions[2])
                self.assertEqual(panel.alarm_tags,{2})
                panel.smooth_check.setChecked(False)
                self.assertEqual(list(panel.raw_trails[2]),[(1500,850),(1600,850),(1600,850)])
                panel.accept_measurement(replace(b,fence_flags=3))
                self.assertTrue(panel.trail_breaks[2][-1])
            panel.anchors=((0,0,2000),(6000,0,2000),(3000,5196,2000))
            panel.restore_site()
            self.assertEqual(panel.anchors,SITE_ANCHORS_MM)
            self.assertEqual(panel.calibration.pixels_per_metre,50)
            self.assertEqual(panel.alarm_tags,{2})
        finally:panel.close();panel.deleteLater()
