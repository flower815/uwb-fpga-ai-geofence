import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import time
import unittest
from unittest.mock import patch
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QCoreApplication, QEvent
from PySide6.QtTest import QSignalSpy
from uwb_pc.window import MainWindow
from uwb_pc.protocol import FrameDecoder, Measurement, encode_measurement
from uwb_pc.simulator import Simulator
from uwb_pc.ui_fonts import configure_font
from uwb_pc.map_geometry import MapTransform

APP = QApplication.instance() or QApplication([])
configure_font(APP)


class WindowTests(unittest.TestCase):
    def setUp(self):
        self.window = MainWindow()
        self.window.scenario_box.setCurrentIndex(self.window.scenario_box.findData('normal'))

    def tearDown(self):
        self.window.close()
        self.window.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        APP.processEvents()

    def cell(self, column):
        return self.window.table.item(0,column).text()

    def test_demo_goes_through_decoder(self):
        self.window.toggle_demo()
        self.window.refresh_health()
        self.assertGreater(self.window.decoder.frames_received, 0)
        self.assertEqual(self.cell(0), "T2")
        self.assertEqual(self.cell(1), "07")
        self.assertEqual(self.cell(9), "围栏内")
        self.assertFalse(self.window.connect_button.isEnabled())
        self.assertEqual(len(self.window.decoder.buffer), 0)

    def test_partial_range_shows_dashes(self):
        self.window.toggle_demo()
        self.window.refresh_health()
        # Fault injectors remain available to regression tests, outside the user menu.
        self.window.scenario_box.addItem('test fault', 'missing')
        self.window.scenario_box.setCurrentIndex(self.window.scenario_box.findData('missing'))
        self.window.simulator.tick()
        self.window.refresh_health()
        self.assertEqual(self.cell(1), "01")
        self.assertEqual(self.cell(3), "0.3")
        self.assertEqual(self.cell(4), "—")
        self.assertEqual(self.cell(6), "—")
        self.assertEqual(self.cell(9), "测距不完整")
        self.assertNotEqual(self.window.map_panel.positions[2], (0, 0))
        self.assertEqual(self.window.map_panel.states[2], "invalid")

    def test_crc_error_does_not_update_position(self):
        self.window.toggle_demo()
        self.window.refresh_health()
        before = self.window.decoder.frames_received
        x = self.cell(6)
        map_x = self.window.map_panel.positions[2]
        # Fault injectors remain available to regression tests, outside the user menu.
        self.window.scenario_box.addItem('test fault', 'crc_error')
        self.window.scenario_box.setCurrentIndex(self.window.scenario_box.findData('crc_error'))
        self.window.simulator.tick()
        self.assertEqual(self.window.decoder.frames_received, before)
        self.assertGreater(self.window.decoder.crc_errors, 0)
        self.assertEqual(self.cell(6), x)
        self.assertEqual(self.window.map_panel.positions[2], map_x)

    def test_timeout_and_recovery(self):
        self.window.toggle_demo()
        self.window.refresh_health()
        measurement, _ = self.window.tags[2]
        self.window.tags[2] = (measurement, time.monotonic()-3)
        self.window.refresh_health()
        self.assertEqual(self.cell(9), "数据超时")
        self.assertEqual(self.window.map_panel.states[2], "stale")
        self.assertIn('数据过期，质量无法判断',self.window.quality_label.text())
        self.window.simulator.tick()
        self.window.refresh_health()
        self.assertEqual(self.cell(9), "围栏内")
        self.assertEqual(self.window.map_panel.states[2], "valid")
        self.assertNotIn('数据过期',self.window.quality_label.text())

    def test_negative_coordinate_and_disconnect(self):
        self.window.toggle_demo()
        self.window.receive_bytes(encode_measurement(Measurement(0,7,2,2,(5000,9849,5000),(-3000,4000,0))))
        self.window.refresh_health()
        self.assertEqual(self.cell(6), "-3.0")
        self.window.toggle_demo()
        self.assertEqual(self.cell(9), "未连接")

    def test_multiple_tags_timeout_independently(self):
        self.window.toggle_demo()
        p = Measurement(0,7,2,3,(5000,5000,5000),(3000,4000,0))
        self.window.receive_bytes(encode_measurement(p))
        old, _ = self.window.tags[2]
        self.window.tags[2] = (old, time.monotonic()-3)
        self.window.refresh_health()
        self.assertEqual(self.cell(9), "数据超时")
        self.assertEqual(self.window.table.item(1,9).text(), "定位有效")

    def test_millimeters_are_preserved_in_actual_measurement_and_map(self):
        self.window.mode = "demo"
        self.window.map_panel.calibration = MapTransform(.05, 0, 180, 240)
        value = Measurement(0, 7, 1, 2, (5328, 9861, 5270), (-3128, 4261, 1234))
        self.window.receive_bytes(encode_measurement(value))
        self.window.refresh_health()
        self.assertEqual([self.cell(i) for i in range(3, 9)],
                         ["5.3", "9.9", "5.3", "-3.1", "4.3", "1.2"])
        self.assertEqual(self.window.tags[2][0].position_mm, (-3128,4261,1234))
        self.assertEqual(self.window.tags[2][0].distances_mm,value.distances_mm)
        self.assertEqual(self.window.map_panel.positions[2], (-3128, 4261))
        tooltips = [item.toolTip() for item in self.window.map_panel.canvas.scene().items()]
        self.assertTrue(any("接收坐标：X=-3.1m，Y=4.3m" in text for text in tooltips))

    def test_display_timer_coalesces_frames_without_losing_received_data(self):
        self.assertEqual(self.window.refresh_box.currentData(), 500)
        self.window.mode = "demo"
        self.window.hex_check.setChecked(False)
        with patch.object(self.window.map_panel, "redraw", wraps=self.window.map_panel.redraw) as redraw:
            for sequence in range(1, 21):
                value = Measurement(0, 7, sequence, 2, (5000, 5000, 5000),
                                    (sequence * 100, 4000, 0))
                self.window.receive_bytes(encode_measurement(value))
            self.assertEqual(self.window.decoder.frames_received, 20)
            self.assertEqual(self.window.table.rowCount(), 0)
            self.assertEqual(redraw.call_count, 0)
            timeout = QSignalSpy(self.window.health_timer.timeout)
            self.assertTrue(timeout.wait(1500))
            self.assertEqual(redraw.call_count, 1)
        self.assertEqual(self.cell(2), "14")
        self.assertEqual(self.cell(6), "2.0")
        self.assertEqual(self.window.map_panel.positions[2], (2000, 4000))
        self.assertEqual(len(self.window.map_panel.trails[2]), 20)

    def test_latest_invalid_frame_keeps_valid_position_from_same_display_interval(self):
        self.window.mode = "demo"
        good = Measurement(0, 7, 1, 2, (5000, 5000, 5000), (3000, 4000, 0))
        missing = Measurement(1, 1, 2, 2, (328, 0, 0), (0, 0, 0))
        self.window.receive_bytes(encode_measurement(good) + encode_measurement(missing))
        self.window.refresh_health()
        self.assertEqual(self.cell(6), "—")
        self.assertEqual(self.cell(9), "测距不完整")
        self.assertEqual(self.window.map_panel.positions[2], (3000, 4000))
        self.assertEqual(self.window.map_panel.states[2], "invalid")

    def test_refresh_interval_updates_live_and_simulated_display(self):
        self.window.refresh_box.setCurrentIndex(self.window.refresh_box.findData(1000))
        self.assertEqual(self.window.health_timer.interval(), 1000)
        self.assertEqual(self.window.simulator.timer.interval(), 1000)
        self.window.toggle_demo()
        self.assertEqual(self.window.simulator.timer.interval(), 1000)

    def test_new_session_cannot_replay_old_pending_positions(self):
        self.window.mode = "demo"
        self.window.receive_bytes(encode_measurement(
            Measurement(0, 7, 1, 2, (5000, 5000, 5000), (3000, 4000, 0))))
        self.window.reset_session()
        self.window.refresh_health()
        self.assertEqual(self.window.table.rowCount(), 0)
        self.assertEqual(self.window.map_panel.positions, {})

    def test_serial_open_failure_is_visible(self):
        self.window.port_box.clear()
        self.window.port_box.addItem("无效测试串口", "")
        self.window.toggle_serial()
        self.assertEqual(self.window.mode, "idle")
        self.assertIn("连接失败", self.window.source_label.text())
        self.assertTrue(self.window.demo_button.isEnabled())

    def test_restart_clears_previous_session(self):
        self.window.toggle_demo()
        self.window.toggle_demo()
        # Fault injectors remain available to regression tests, outside the user menu.
        self.window.scenario_box.addItem('test fault', 'paused')
        self.window.scenario_box.setCurrentIndex(self.window.scenario_box.findData('paused'))
        self.window.toggle_demo()
        self.assertEqual(self.window.decoder.frames_received, 0)
        self.assertEqual(self.window.table.rowCount(), 0)


class SimulatorTests(unittest.TestCase):
    def test_simulated_alarm_clears_on_first_shallow_inside_return(self):
        simulator=Simulator();simulator.scenario='fence';decoder=FrameDecoder();frames=[]
        simulator.bytes_received.connect(lambda b:frames.extend(decoder.feed(b)))
        with patch('uwb_pc.simulator.time.monotonic',side_effect=[1+i*.1 for i in range(9)]):
            for _ in range(6):simulator.tick()
            self.assertEqual([v.fence_flags for v in frames],[1,1,8,16,3,1])
            self.assertFalse(simulator.fence_latched)
            simulator.tick();simulator.tick();simulator.tick()
            self.assertFalse(simulator.fence_latched);self.assertEqual(frames[-1].fence_flags,1)
        simulator.fence_latched=True
        self.assertEqual(simulator._update_fence((1500,850),valid=False),4)
        self.assertTrue(simulator.fence_latched)
        self.assertEqual(simulator._update_fence((1500,1)),1)
        self.assertFalse(simulator.fence_latched)

    def test_scenarios(self):
        simulator = Simulator()
        decoder = FrameDecoder()
        frames = []
        simulator.bytes_received.connect(lambda b: frames.extend(decoder.feed(b)))
        simulator.tick()
        self.assertTrue(frames[-1].has_position)
        simulator.scenario = "missing"
        simulator.tick()
        self.assertEqual(frames[-1].distances_mm, (328,0,0))
        count = len(frames)
        simulator.scenario = "crc_error"
        simulator.tick()
        self.assertEqual(len(frames), count)
        self.assertGreater(decoder.crc_errors, 0)
        simulator.scenario = "paused"
        simulator.tick()
        self.assertEqual(len(frames), count)


if __name__ == "__main__":
    unittest.main()
