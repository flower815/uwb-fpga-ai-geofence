import json
import math
import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from PySide6.QtCore import QCoreApplication, QEvent, QPointF, Qt
from PySide6.QtGui import QColor, QImage
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from uwb_pc.map_geometry import MapTransform
from uwb_pc.map_widget import MapPanel
from uwb_pc.protocol import Measurement
from uwb_pc.ui_fonts import configure_font

APP = QApplication.instance() or QApplication([])
configure_font(APP)


class GeometryTests(unittest.TestCase):
    def assertPoint(self, actual, expected):
        for a, b in zip(actual, expected):
            self.assertAlmostEqual(a, b, places=7)

    def test_translation_scale_and_y_up(self):
        t = MapTransform.from_points((200, 700), (600, 700), (1000, 2000), (5000, 2000))
        self.assertPoint(t.world_to_pixel(1000, 6000), (200, 300))
        self.assertAlmostEqual(t.pixels_per_metre, 100)

    def test_rotated_map(self):
        t = MapTransform.from_points((400, 400), (400, 100), (0, 0), (6000, 0))
        self.assertPoint(t.world_to_pixel(0, 6000), (100, 400))
        self.assertPoint(t.pixel_to_world(100, 400), (0, 6000))

    def test_arbitrary_references_and_negative_roundtrip(self):
        # 独立生成已知旋转/比例的参考点，再从参考点恢复标定。
        reference = MapTransform(.03, .04, 123, 789)
        p0, p1 = (-1000, 2500), (2345, -4500)
        t = MapTransform.from_points(reference.world_to_pixel(*p0),
                                     reference.world_to_pixel(*p1), p0, p1)
        for point in [(-3000, -4000), (1000, 2000), (0, 0)]:
            self.assertPoint(t.world_to_pixel(*point), reference.world_to_pixel(*point))
            self.assertPoint(t.pixel_to_world(*t.world_to_pixel(*point)), point)

    def test_rejects_degenerate_and_nonfinite_inputs(self):
        for pixels, world in [(((0, 0), (0, 0)), ((0, 0), (1000, 0))),
                              (((0, 0), (100, 0)), ((0, 0), (0, 0))),
                              (((0, 0), (math.nan, 0)), ((0, 0), (1000, 0)))]:
            with self.assertRaises(ValueError):
                MapTransform.from_points(*pixels, *world)
        with self.assertRaises(ValueError):
            MapTransform(0, 0, 0, 0)


class MapTests(unittest.TestCase):
    def setUp(self):
        self.panel = MapPanel()
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.image_path = self.directory / "自定义地图.png"
        image = QImage(800, 600, QImage.Format.Format_RGB32)
        image.fill(QColor("white"))
        self.assertTrue(image.save(str(self.image_path)))

    def tearDown(self):
        self.panel.close()
        self.panel.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        APP.processEvents()
        self.temp.cleanup()

    def record(self, pos=(3000, 4000, 0), status=0, mask=7):
        return Measurement(status, mask, 1, 2, (5000, 5000, 5000), pos)

    def test_import_requires_new_calibration_and_invalid_image_is_transactional(self):
        self.panel.accept_measurement(self.record())
        self.panel.load_image(self.image_path)
        self.assertIsNone(self.panel.calibration)
        self.assertEqual(self.panel.positions[2], (3000, 4000))
        self.assertEqual(len(self.panel.canvas.overlay.childItems()), 0)
        with self.assertRaises(ValueError):
            self.panel.load_image(self.directory / "不存在.png")
        self.assertEqual(self.panel.map_path, str(self.image_path.resolve()))

    def test_configuration_roundtrip_and_relative_map_path(self):
        self.panel.load_image(self.image_path)
        transform = MapTransform.from_points((100, 500), (700, 500), (0, 0), (6000, 0))
        self.panel.calibration = transform
        path = self.directory / "map.json"
        self.panel.save_config(path)
        self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["image"], self.image_path.name)
        self.panel.calibration = None
        self.panel.load_config(path)
        self.assertEqual(self.panel.calibration, transform)
        self.assertEqual(self.panel.map_size, (800, 600))
        self.assertEqual(self.panel.anchors[2], (1500., 2600., 1000.))

    def test_changed_image_rejects_old_calibration_without_changing_display(self):
        self.panel.load_image(self.image_path)
        self.panel.calibration = MapTransform(.1, 0, 100, 500)
        path = self.directory / "map.json"
        self.panel.save_config(path)
        old_transform = self.panel.calibration
        image = QImage(800, 600, QImage.Format.Format_RGB32)
        image.fill(QColor("red"))
        image.save(str(self.image_path))
        with self.assertRaisesRegex(ValueError, "变动"):
            self.panel.load_config(path)
        self.assertEqual(self.panel.calibration, old_transform)

    def test_invalid_configuration_does_not_replace_current_state(self):
        path = self.directory / "map.json"
        self.panel.save_config(path)
        original = self.panel.calibration
        config = json.loads(path.read_text(encoding="utf-8"))
        config["transform"]["a"] = float("nan")
        path.write_text(json.dumps(config), encoding="utf-8")
        with self.assertRaises(ValueError):
            self.panel.load_config(path)
        self.assertEqual(self.panel.calibration, original)
        self.assertIsNone(self.panel.map_path)

    def test_invalid_range_retains_last_valid_point_without_extending_trail(self):
        self.panel.accept_measurement(self.record())
        self.panel.accept_measurement(self.record((0, 0, 0), status=1, mask=1))
        self.assertEqual(self.panel.positions[2], (3000, 4000))
        self.assertEqual(len(self.panel.trails[2]), 1)
        self.assertEqual(self.panel.states[2], "invalid")
        self.panel.set_stale(2, True, False)
        self.assertEqual(self.panel.states[2], "stale")

    def test_trail_bounded_and_outside_position_not_clamped(self):
        for i in range(510):
            self.panel.accept_measurement(self.record((i*10, i*10, 0)))
        self.assertEqual(len(self.panel.trails[2]), 500)
        self.panel.accept_measurement(self.record((-30000, 4000, 0)))
        self.assertEqual(self.panel.positions[2][0], -30000)
        self.assertIn(2, self.panel.outside_tags)
        self.assertIn("图外标签", self.panel.info.text())
        self.panel.clear_trails()
        self.assertEqual(len(self.panel.trails), 0)
        self.assertIn(2, self.panel.positions)

    def test_qt_mouse_two_point_calibration(self):
        self.panel.resize(650, 750)
        self.panel.show()
        APP.processEvents()
        self.panel.begin_calibration()
        canvas = self.panel.canvas
        first = canvas.mapFromScene(QPointF(*self.panel.calibration.world_to_pixel(0,0)))
        second = canvas.mapFromScene(QPointF(*self.panel.calibration.world_to_pixel(3000,0)))
        pixel0 = canvas.mapToScene(first)
        pixel1 = canvas.mapToScene(second)
        with patch("uwb_pc.map_widget.coordinate_dialog", return_value=((0, 0), (6000, 0))):
            QTest.mouseClick(canvas.viewport(), Qt.MouseButton.LeftButton, pos=first)
            QTest.mouseClick(canvas.viewport(), Qt.MouseButton.LeftButton, pos=second)
        self.assertFalse(canvas.picking)
        actual0 = self.panel.calibration.world_to_pixel(0, 0)
        actual1 = self.panel.calibration.world_to_pixel(6000, 0)
        self.assertAlmostEqual(actual0[0], pixel0.x())
        self.assertAlmostEqual(actual0[1], pixel0.y())
        self.assertAlmostEqual(actual1[0], pixel1.x())
        self.assertAlmostEqual(actual1[1], pixel1.y())

    def test_overlay_item_count_does_not_grow_per_frame(self):
        self.panel.accept_measurement(self.record())
        before = len(self.panel.canvas.scene().items())
        for _ in range(100):
            self.panel.accept_measurement(self.record())
        self.assertEqual(len(self.panel.canvas.scene().items()), before)
