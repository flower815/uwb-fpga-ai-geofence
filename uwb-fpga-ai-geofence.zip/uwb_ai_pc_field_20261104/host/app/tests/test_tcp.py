import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import time
import struct
import unittest
from PySide6.QtCore import QCoreApplication, QEvent
from PySide6.QtNetwork import QAbstractSocket, QHostAddress, QTcpSocket
from PySide6.QtWidgets import QApplication
from uwb_pc.tcp_link import TcpReceiver
from uwb_pc.protocol import Measurement, encode_measurement, crc16_ccitt
from uwb_pc.window import MainWindow
from uwb_pc.profile import EXPECTED_PROFILE

APP = QApplication.instance() or QApplication([])
LOCAL = QHostAddress(QHostAddress.SpecialAddress.LocalHost)


def pump_until(predicate, timeout=2):
    end = time.monotonic()+timeout
    while time.monotonic() < end:
        APP.processEvents()
        if predicate():
            return
        time.sleep(.001)
    raise AssertionError("TCP loopback event timeout")


class TcpTests(unittest.TestCase):
    def setUp(self):
        self.window = MainWindow()
        self.window.mode = "tcp"
        self.window.tcp.listen(0, LOCAL)
        self.window.set_controls()
        self.peers = []

    def tearDown(self):
        self.window.close()
        for peer in self.peers:
            peer.abort()
        self.window.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        APP.processEvents()

    def connect_peer(self):
        peer = QTcpSocket()
        self.peers.append(peer)
        peer.connectToHost(LOCAL, self.window.tcp.server.serverPort())
        pump_until(lambda: self.window.tcp.client is not None and peer.state() == QAbstractSocket.SocketState.ConnectedState)
        return peer

    def send(self, peer, data):
        before = self.window.decoder.bytes_received
        self.assertEqual(peer.write(data), len(data))
        peer.flush()
        pump_until(lambda: self.window.decoder.bytes_received >= before+len(data))

    def test_real_socket_fragmented_frames_crc_and_coordinates(self):
        peer = self.connect_peer()
        missing = Measurement(1,1,1,2,(328,0,0),(0,0,0))
        good = Measurement(0,7,2,2,(5000,9849,5000),(-3000,4000,1000))
        packet = encode_measurement(missing)
        self.send(peer, packet[:5])
        self.assertEqual(self.window.decoder.frames_received, 0)
        self.send(peer, packet[5:]+encode_measurement(good))
        self.window.refresh_health()
        self.assertEqual(self.window.decoder.frames_received, 2)
        self.assertEqual(self.window.table.item(0,6).text(), "-3.0")
        self.assertEqual(self.window.map_panel.positions[2], (-3000,4000))
        bad = bytearray(encode_measurement(good)); bad[20] ^= 1
        self.send(peer, bytes(bad)+encode_measurement(missing))
        self.window.refresh_health()
        self.assertGreater(self.window.decoder.crc_errors, 0)
        self.assertEqual(self.window.table.item(0,6).text(), "—")
        self.assertEqual(self.window.decoder.frames_received, 3)

    def test_reconnect_does_not_join_old_partial_frame(self):
        peer = self.connect_peer()
        value = Measurement(0,7,2,2,(5000,5000,5000),(3000,4000,0))
        packet = encode_measurement(value)
        self.send(peer, packet+packet[:12])
        peer.disconnectFromHost()
        pump_until(lambda: self.window.tcp.client is None)
        self.assertEqual(self.window.table.item(0,9).text(), "数据超时")
        self.assertEqual(len(self.window.decoder.buffer), 0)
        other = self.connect_peer()
        self.send(other, packet[12:]+packet)
        self.window.refresh_health()
        self.assertEqual(self.window.decoder.frames_received, 2)
        self.assertEqual(self.window.table.item(0,9).text(), "定位有效")

    def test_second_source_is_rejected(self):
        first = self.connect_peer()
        second = QTcpSocket(); self.peers.append(second)
        second.connectToHost(LOCAL, self.window.tcp.server.serverPort())
        pump_until(lambda: second.state() == QAbstractSocket.SocketState.UnconnectedState)
        self.assertEqual(first.state(), QAbstractSocket.SocketState.ConnectedState)
        self.assertFalse(self.window.connect_button.isEnabled())
        self.assertFalse(self.window.demo_button.isEnabled())
        self.window.toggle_tcp()
        self.assertEqual(self.window.mode, "idle")
        self.assertFalse(self.window.tcp.server.isListening())
        self.assertTrue(self.window.connect_button.isEnabled())

    def test_listen_port_conflict_reports_error(self):
        other = TcpReceiver()
        try:
            with self.assertRaises(RuntimeError):
                other.listen(self.window.tcp.server.serverPort(), LOCAL)
        finally:
            other.close()

    def take_command(self, peer):
        pump_until(lambda: peer.bytesAvailable()>=18)
        packet=bytes(peer.read(18))
        self.assertEqual(crc16_ccitt(packet[:16]),int.from_bytes(packet[16:],'little'))
        return struct.unpack('<2sBBHBBII',packet[:16])

    def verify_peer_profile(self,peer):
        self.window.check_profile()
        for index,value in enumerate(EXPECTED_PROFILE):
            command=self.take_command(peer)
            self.assertEqual((command[2],command[4]),(3,index))
            body=struct.pack('<2sBBHBBII',b'\x55\xaa',0x11,3,command[3],0,0,command[6],value&0xffffffff)
            self.send(peer,body+crc16_ccitt(body).to_bytes(2,'little'))
            self.window.profile.tick()
        self.assertTrue(self.window.profile.verified)

    @staticmethod
    def acknowledgement(command, state=0, result=0):
        header,version,opcode,sequence,alarm,reserved,token,zero=command
        body=struct.pack('<2sBBHBBII',header,0x11,opcode,sequence,state,result,token,12345)
        return body+crc16_ccitt(body).to_bytes(2,'little')

    def test_duplex_socket_ping_ai_warning_release_and_crc(self):
        peer=self.connect_peer();self.window.ai.timer.stop()
        self.verify_peer_profile(peer)
        self.window.ai.client.request(0);command=self.take_command(peer)
        self.assertEqual(command[1:3],(0x10,0))
        self.send(peer,self.acknowledgement(command))
        self.assertIsNone(self.window.ai.client.pending)
        self.window.ai.set_enabled(True);command=self.take_command(peer)
        self.assertEqual(command[2],1);self.assertEqual(command[4],1)
        acknowledgement=self.acknowledgement(command,17);bad=bytearray(acknowledgement);bad[-1]^=1
        self.send(peer,bytes(bad));self.assertIsNotNone(self.window.ai.client.pending)
        value=Measurement(0,7,1,2,(3590,3590,3636),(3000,1699,1000),(65535,)*3,0,1)
        self.send(peer,encode_measurement(value)+acknowledgement)
        self.assertEqual(self.window.ai.client.acks,2)
        self.assertEqual(self.window.map_panel.alarm_tags,set())
        self.window.ai.set_enabled(False);command=self.take_command(peer)
        self.assertEqual(command[2],2)
        self.send(peer,self.acknowledgement(command))
        self.assertEqual(self.window.ai.client.last_state,0)

    def test_tcp_reconnect_requires_fresh_probe_and_clears_pending_ai(self):
        peer=self.connect_peer();self.window.ai.timer.stop()
        self.verify_peer_profile(peer)
        self.window.ai.client.request(0);probe=self.take_command(peer);self.send(peer,self.acknowledgement(probe))
        self.window.ai.set_enabled(True);old=self.take_command(peer)
        peer.disconnectFromHost();pump_until(lambda:self.window.tcp.client is None)
        self.assertFalse(self.window.ai.enabled);self.assertIsNone(self.window.ai.client.pending)
        self.assertIsNone(self.window.ai.client.last_state)
        other=self.connect_peer()
        self.assertFalse(self.window.profile.verified)
        self.send(other,self.acknowledgement(old,17))
        self.assertIsNone(self.window.ai.client.last_state)
        with self.assertRaises(RuntimeError):self.window.ai.set_enabled(True)

    def test_sending_without_connected_peer_is_rejected(self):
        with self.assertRaises(RuntimeError):self.window.tcp.send_bytes(b'hello')

    def test_rejected_probe_cannot_enable_wifi_ai(self):
        peer=self.connect_peer();self.window.ai.timer.stop()
        self.verify_peer_profile(peer)
        self.window.ai.client.request(0);probe=self.take_command(peer)
        self.send(peer,self.acknowledgement(probe,result=1))
        self.assertEqual(self.window.ai.client.rejected,1)
        with self.assertRaises(RuntimeError):self.window.ai.set_enabled(True)


if __name__ == "__main__":
    unittest.main()
