import csv
from dataclasses import replace
import math
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
import struct
import tempfile
import unittest
from PySide6.QtWidgets import QApplication
from uwb_pc.protocol import ControlAck,FrameDecoder,Measurement,encode_measurement,crc16_ccitt
from uwb_pc.profile import ProfileVerifier,EXPECTED_PROFILE
from uwb_pc.known_point import KnownPointSession
from uwb_pc.geofence import SITE_ANCHORS_MM
from uwb_pc.window import MainWindow

APP=QApplication.instance() or QApplication([])


def value(seq=1,status=0,mask=7,flags=1):
    return Measurement(status,mask,seq,2,(2000,2000,2000),(1503,870,0),(65535,)*3,0,flags)


class ProfileTests(unittest.TestCase):
    def test_old_audible_fault_firmware_and_old_clear_policy_are_rejected(self):
        p=ProfileVerifier(lambda data:None)
        self.assertEqual(EXPECTED_PROFILE[1],0x00050006)
        self.assertEqual(EXPECTED_PROFILE[13:16],(3,1,0))
        for index,old in ((1,0x00050001),(1,0x00050002),(1,0x00050003),(1,0x00050004),(1,0x00050005),(14,3),(15,150)):
            p.values=dict(enumerate(EXPECTED_PROFILE));p.values[index]=old;p.validate()
            self.assertFalse(p.verified)
            self.assertIn(('firmware' if index==1 else 'CLEAR_HITS' if index==14 else 'CLEAR_MARGIN_MM'),p.message)

    def test_all_registers_and_signed_geometry_are_verified(self):
        sent=[];p=ProfileVerifier(sent.append);p.start()
        for i,data in enumerate(EXPECTED_PROFILE):
            command=struct.unpack('<2sBBHBBII',sent[-1][:16])
            self.assertEqual(command[2:3],(3,));self.assertEqual(command[4],i)
            pending=p.pending.copy();p.accept(ControlAck(3,pending['sequence'],0,0,pending['token'],data&0xffffffff));p.tick()
        self.assertTrue(p.verified);self.assertFalse(p.active)
        p.values[2]=0xffffffff;p.validate();self.assertFalse(p.verified)
        self.assertIn('X0',p.message)
        p.start()
        for index,data in enumerate(EXPECTED_PROFILE[:3]):
            q=p.pending.copy();p.accept(ControlAck(3,q['sequence'],0,0,q['token'],0xffffffff if index==2 else data));p.tick()
        self.assertEqual(p.values[2],-1)

    def test_stale_reply_reconnect_timeout_and_unsupported(self):
        now=[0.];sent=[];p=ProfileVerifier(sent.append,clock=lambda:now[0]);p.start();old=p.pending.copy()
        p.reset();p.start();new=p.pending.copy()
        self.assertNotEqual(old['token'],new['token'])
        p.accept(ControlAck(3,old['sequence'],0,0,old['token'],EXPECTED_PROFILE[0]))
        self.assertFalse(p.values)
        now[0]=.81;p.tick();self.assertEqual(sent[-1],sent[-2])
        now[0]=1.62;p.tick();self.assertFalse(p.active);self.assertFalse(p.verified)
        p.start();pending=p.pending.copy();p.accept(ControlAck(3,pending['sequence'],0,3,pending['token'],0))
        self.assertIn('拒绝',p.message)

    def test_query_result3_crc_and_all_splits(self):
        body=struct.pack('<2sBBHBBII',b'\x55\xaa',0x11,3,42,0,3,99,0)
        packet=body+crc16_ccitt(body).to_bytes(2,'little')
        for split in range(19):
            d=FrameDecoder();self.assertEqual(d.feed(packet[:split])+d.feed(packet[split:]),[])
            self.assertEqual(len(d.acknowledgements),1)
        bad=bytearray(packet);bad[-1]^=1;d=FrameDecoder();d.feed(bytes(bad)+packet)
        self.assertEqual(len(d.acknowledgements),1);self.assertGreater(d.crc_errors,0)
        body=bytearray(body);body[3]=0
        d=FrameDecoder();d.feed(bytes(body)+crc16_ccitt(body).to_bytes(2,'little'))
        self.assertEqual(d.format_errors,1)


class QualityAndFieldTests(unittest.TestCase):
    def test_fault_flags_preserve_alarm_without_new_position_or_event(self):
        w=MainWindow();w.mode='serial';w.hex_check.setChecked(False)
        try:
            for flag in (32,36):
                fault=replace(value(status=16,mask=0,flags=flag),position_mm=(0,0,0))
                packet=encode_measurement(fault);d=FrameDecoder()
                self.assertEqual(d.feed(packet),[fault]);self.assertFalse(fault.has_position)
                w.receive_bytes(packet)
                self.assertIn('定位失效',w.quality_label.text())
                self.assertFalse(w.map_panel.positions)
                self.assertEqual(w.fence_event_count,0)
            self.assertEqual(w.map_panel.alarm_tags,{2})
            self.assertNotIn(2,w.ai.engine.history)
            with self.assertRaisesRegex(RuntimeError,'核对'):w.ai.set_enabled(True)
        finally:w.close();w.deleteLater();APP.processEvents()

    def test_known_point_3d_ranges_valid_fraction_and_csv_replay(self):
        session=KnownPointSession();truth=(1500,866,0);session.start(truth,2)
        session.add(value(),'unverified','serial',received_unix=10,received_monotonic=1)
        bad=replace(value(seq=2,status=16,flags=0),distances_mm=(2100,2200,2300))
        session.add(bad,'verified','serial',received_unix=11,received_monotonic=2)
        session.add(replace(bad,sequence=3,status=1,mask=1,distances_mm=(0,0,0)),'verified','serial',12,3)
        session.add(replace(bad,sequence=3,mask=0,fence_flags=32,distances_mm=(0,0,0)),'verified','serial',13,4)
        session.add(replace(value(),sequence=3),'verified','serial',14,5)
        s=session.summary()
        self.assertEqual((s['count'],s['measurement_count'],s['invalid_count'],s['fault_count'],s['duplicate_count']),(1,3,2,1,1))
        self.assertAlmostEqual(s['xy_rmse_mm'],5)
        self.assertEqual(s['range_count'],[2,2,2])
        self.assertAlmostEqual(s['range_bias_mm'][0],2050-math.dist(truth,SITE_ANCHORS_MM[0]))
        self.assertAlmostEqual(s['valid_ratio'],1/3)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'known.csv';session.export_csv(path)
            replay=KnownPointSession();replay.load_csv(path)
            self.assertEqual(replay.summary(),s)
            self.assertEqual(len(replay.rows),5)
            lines=list(csv.DictReader(path.open(encoding='utf-8-sig')))
            self.assertTrue(lines[1]['exclude_reason']);self.assertEqual(lines[3]['kind'],'fault_heartbeat')

    def test_bad_csv_replay_does_not_replace_existing_data(self):
        session=KnownPointSession();session.start((0,0,0));session.add(value(),'verified','demo')
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'bad.csv';session.export_csv(path)
            rows=list(csv.DictReader(path.open(encoding='utf-8-sig')));rows[0]['x_mm']='nan'
            with path.open('w',encoding='utf-8-sig',newline='') as out:
                writer=csv.DictWriter(out,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
            with self.assertRaises(ValueError):session.load_csv(path)
            self.assertEqual(len(session.rows),1)

    def test_empty_and_no_valid_xy_do_not_hide_bad_range_measurements(self):
        session=KnownPointSession();self.assertEqual(session.summary()['count'],0)
        session.start((1500,866,0));session.add(value(status=16,flags=0),'unverified','demo')
        s=session.summary();self.assertEqual(s['count'],0);self.assertEqual(s['invalid_count'],1)
        self.assertIsNone(s['xy_rmse_mm']);self.assertEqual(s['range_count'],[1,1,1])
        session.add(value(seq=2,status=16,flags=32),'unverified','demo')
        s=session.summary();self.assertEqual(s['measurement_count'],2)
        self.assertEqual(s['invalid_count'],2);self.assertEqual(s['range_count'],[2,2,2])

    def test_fault_heartbeat_shape_not_sequence_guess_and_real_missing_frames(self):
        session=KnownPointSession();session.start((1500,866,0))
        heartbeat=replace(value(seq=99,status=16,mask=0,flags=32),distances_mm=(0,0,0),position_mm=(0,0,0))
        session.add(heartbeat,'verified','serial')
        session.add(replace(heartbeat,sequence=105,status=0x90,fence_flags=36),'verified','serial')
        s=session.summary();self.assertEqual(s['measurement_count'],0);self.assertEqual(s['fault_count'],2)
        session.add(replace(heartbeat,sequence=106,status=0x11),'verified','serial')
        s=session.summary();self.assertEqual(s['measurement_count'],1);self.assertEqual(s['invalid_count'],1)
        self.assertEqual(s['fault_count'],2)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'heartbeats.csv';session.export_csv(path)
            replay=KnownPointSession();replay.load_csv(path)
            self.assertEqual(replay.summary(),s)
            rows=list(csv.DictReader(path.open(encoding='utf-8-sig')))
            rows[0]['status']='17'
            with path.open('w',encoding='utf-8-sig',newline='') as out:
                writer=csv.DictWriter(out,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
            with self.assertRaisesRegex(ValueError,'心跳'):replay.load_csv(path)

    def test_csv_finite_extremes_and_fractional_raw_fields_are_rejected(self):
        session=KnownPointSession();session.start((0,0,0));session.add(value(),'verified','serial')
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'bounds.csv'
            for key,bad in [('truth_x_mm','1e300'),('truth_z_mm','100000.1'),('x_mm','2147483648'),
                            ('y_mm','-2147483649'),('z_mm','.5'),('d0_mm','1.5'),('d1_mm','4294967296')]:
                session.export_csv(path)
                rows=list(csv.DictReader(path.open(encoding='utf-8-sig')));rows[0][key]=bad
                with path.open('w',encoding='utf-8-sig',newline='') as out:
                    writer=csv.DictWriter(out,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
                with self.subTest(key=key,bad=bad):
                    with self.assertRaises(ValueError):KnownPointSession().load_csv(path)

    def test_unverified_or_mismatched_inside_report_does_not_claim_green_safety(self):
        w=MainWindow();w.mode='serial';w.hex_check.setChecked(False)
        try:
            w.receive_bytes(encode_measurement(value()))
            self.assertIn('板端报围栏内',w.fence_label.text())
            self.assertNotIn('#eaf7ef',w.fence_label.styleSheet())
            w.profile.values=dict(enumerate(EXPECTED_PROFILE));w.profile.validate();w.update_fence_status()
            self.assertIn('#eaf7ef',w.fence_label.styleSheet())
            w.profile.values[5]=6000;w.profile.validate();w.update_fence_status()
            self.assertIn('安全区设置待核对',w.fence_label.text())
            w.receive_bytes(encode_measurement(value(seq=2,flags=3)))
            self.assertEqual(w.map_panel.alarm_tags,{2});self.assertIn('#fff0ed',w.fence_label.styleSheet())
        finally:w.close();w.deleteLater();APP.processEvents()
