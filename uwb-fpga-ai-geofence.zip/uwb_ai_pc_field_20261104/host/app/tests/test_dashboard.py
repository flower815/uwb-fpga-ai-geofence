"""Integration checks for read-only dashboard cards and embedded AI controls."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import time
import unittest
from unittest.mock import patch
from PySide6.QtWidgets import QApplication,QDialog,QDoubleSpinBox
from uwb_pc.window import MainWindow
from uwb_pc.protocol import Measurement,encode_measurement
from uwb_pc.ai_model import RiskResult

APP=QApplication.instance() or QApplication([])


class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.w=MainWindow();self.w.mode='demo';self.w.hex_check.setChecked(False)

    def tearDown(self):
        self.w.close();self.w.deleteLater();APP.processEvents()

    def push(self,tag=2,seq=1,flags=1,status=0,mask=7):
        value=Measurement(status,mask,seq,tag,(2011,2189,2397),(1234,876,0),(1000,2000,3000),7,flags)
        self.w.receive_bytes(encode_measurement(value));self.w.refresh_health()

    def test_anchor_input_and_sidebar_use_one_decimal_metre(self):
        self.w.refresh_health()
        self.assertEqual(self.w.anchor_labels[2].text(),'▲ A2     1.5   2.6   1.0')
        def accept(dialog):
            fields=dialog.findChildren(QDoubleSpinBox)
            self.assertEqual(len(fields),9)
            self.assertTrue(all(f.decimals()==1 for f in fields))
            fields[7].setValue(2.64)
            return QDialog.DialogCode.Accepted
        with patch.object(QDialog,'exec',accept):self.w.map_panel.edit_anchors()
        self.assertEqual(self.w.map_panel.anchors[2],(1500,2600,1000))

    def test_selected_tag_card_matches_mm_values_and_invalid_never_shows_zero(self):
        self.push()
        self.assertEqual([l.text() for l in self.w.coordinate_labels],['1.2','0.9','0.0'])
        self.assertEqual([l.text() for l in self.w.distance_labels],['2.0 m','2.2 m','2.4 m'])
        self.assertEqual(self.w.angle_labels[1].text(),'20.00 °')
        self.push(tag=3,seq=2);self.w.tag_selector.setCurrentIndex(self.w.tag_selector.findData(3))
        self.assertEqual(self.w.tag_selector.currentData(),3)
        fault=Measurement(16,0,2,3,(0,0,0),(0,0,0),(65535,)*3,0,32)
        self.w.receive_bytes(encode_measurement(fault));self.w.refresh_health()
        self.assertEqual([l.text() for l in self.w.coordinate_labels],['—']*3)
        self.assertIn('定位失效',self.w.position_badge.text())
        self.w.ai_panel.refresh();self.assertIn('风险未知',self.w.ai_panel.risk_label.text())

    def test_disconnect_and_timeout_remove_current_values_and_ai_confidence(self):
        self.push()
        self.w.ai.results[2]=(RiskResult(2,.01,'test fixture'),time.monotonic())
        self.w.ai_panel.refresh();self.assertIn('风险较低',self.w.ai_panel.risk_label.text())
        self.w.tags[2]=(self.w.tags[2][0],time.monotonic()-3)
        self.w.ai.results[2]=(RiskResult(2,.01,'test fixture'),time.monotonic()-3)
        self.w.refresh_health();self.w.ai_panel.refresh()
        self.assertIn('风险未知',self.w.ai_panel.risk_label.text())
        self.assertEqual(self.w.coordinate_labels[0].text(),'—')
        self.assertEqual(self.w.distance_labels[0].text(),'— m')
        self.push(seq=2)
        self.w.ai.results[2]=(RiskResult(2,.01,'test fixture'),time.monotonic())
        self.w.mode='idle';self.w.refresh_health();self.w.ai_panel.refresh()
        self.assertIn('未连接',self.w.position_badge.text())
        self.assertIn('风险未知',self.w.ai_panel.risk_label.text())

    def test_ai_focus_and_advanced_settings_never_open_dialog_or_send_commands(self):
        self.w.show();APP.processEvents()
        self.w.show_ai();self.w.ai_panel.advanced_button.setChecked(True);APP.processEvents()
        self.assertIs(self.w.ai_panel.window(),self.w)
        self.assertTrue(self.w.ai_panel.advanced.isVisible())
        self.assertFalse(self.w.findChildren(QDialog))
        self.assertEqual(self.w.ai.client.sent,0)
        # A refresh must not overwrite the user's unapplied backend choice.
        self.w.ai_panel.backend.setCurrentIndex(1);self.w.ai_panel.refresh()
        self.assertEqual(self.w.ai_panel.backend.currentData(),'torch_cpu')
        self.w.ai_panel.advanced_button.setChecked(False)
        self.assertFalse(self.w.ai_panel.advanced.isVisible())

    def test_inline_controls_preserve_profile_authorization_and_query_isolation(self):
        self.w.mode='serial'
        with patch.object(self.w.serial,'send_bytes') as send:
            self.w.ai_panel.control_changed(True)
            self.assertFalse(self.w.ai.enabled);send.assert_not_called()
            self.assertIn('核对',self.w.ai_panel.message.text())
            self.w.profile.active=True
            self.w.ai_panel.attempt(self.w.ai_panel.ping);send.assert_not_called()
            self.assertIn('核对完成',self.w.ai_panel.message.text())
            self.w.profile.active=False
            self.w.ai_panel.attempt(self.w.ai_panel.ping)
            send.assert_called_once();self.assertEqual(self.w.ai.client.pending['opcode'],0)


if __name__=='__main__':unittest.main()
