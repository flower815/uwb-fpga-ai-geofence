import unittest,csv
from pathlib import Path
from PySide6.QtWidgets import QApplication
from uwb_pc.history_replay import FIELD_DATASETS,read_csv_history
from uwb_pc.window import MainWindow
APP=QApplication.instance() or QApplication([])
class CurrentFieldFiles(unittest.TestCase):
    def test_only_five_new_csv_are_selected(self):
        self.assertEqual(len(FIELD_DATASETS),5)
        for i,p in enumerate(FIELD_DATASETS.values(),1):self.assertEqual(p.name,f'p1_los_run{i}.csv')
    def test_all_rows_and_original_mm_survive_replay(self):
        total=0
        for p in FIELD_DATASETS.values():
            rows=list(csv.DictReader(p.open(encoding='utf-8-sig')))
            events,count,meta=read_csv_history(p);self.assertEqual(count,len(rows));total+=count
            for e,r in zip(events,rows):
                self.assertEqual(e.measurement.position_mm,tuple(int(r[k]) for k in ('x_mm','y_mm','z_mm')))
        self.assertEqual(total,822)
    def test_packaged_menu_maps_to_new_known_points(self):
        w=MainWindow()
        try:
            self.assertEqual(w.scenario_box.count(),6)
            w.toggle_demo();self.assertEqual(w.replay.path,FIELD_DATASETS['field0'])
            self.assertEqual(w.mode,'replay');self.assertFalse(w.profile.verified)
        finally:w.close();w.deleteLater();APP.processEvents()
