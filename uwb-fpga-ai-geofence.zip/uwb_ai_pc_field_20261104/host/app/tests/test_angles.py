import binascii
from dataclasses import replace
import os
import struct
import time
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QCoreApplication, QEvent
from uwb_pc.protocol import Measurement, FrameDecoder, encode_measurement
from uwb_pc.window import MainWindow

APP = QApplication.instance() or QApplication([])


class AngleProtocolTests(unittest.TestCase):
    def setUp(self):
        self.record = Measurement(0, 7, 2, 2, (5000,)*3, (3000,4000,0), (5313,12687,30687), 7)

    def test_independent_offsets_and_crc(self):
        packet = bytearray(42)
        packet[:8] = bytes.fromhex("55 aa 02 00 07 02 02 00")
        struct.pack_into("<IIIiiiBBHHH", packet, 8, 5000,5000,5000,3000,4000,0,7,0,5313,12687,30687)
        packet[40:] = binascii.crc_hqx(packet[:40], 0xFFFF).to_bytes(2,"little")
        self.assertEqual(encode_measurement(self.record), packet)
        self.assertEqual(FrameDecoder().feed(packet), [self.record])

    def test_every_split_and_mixed_versions(self):
        packet = encode_measurement(self.record)
        legacy = replace(self.record, azimuth_cdeg=None, angle_valid_mask=0)
        for split in range(43):
            decoder = FrameDecoder()
            actual = decoder.feed(packet[:split])+decoder.feed(packet[split:])
            self.assertEqual(actual, [self.record])
        decoder = FrameDecoder()
        data = b"noise\x55" + encode_measurement(legacy)+packet+encode_measurement(legacy)
        actual=[]
        for i in range(0,len(data),5):actual.extend(decoder.feed(data[i:i+5]))
        self.assertEqual(actual, [legacy,self.record,legacy])

    def test_corrupt_extended_payload_recovers(self):
        packet = encode_measurement(self.record)
        for index in range(32,42):
            damaged=bytearray(packet); damaged[index]^=1
            decoder=FrameDecoder()
            self.assertEqual(decoder.feed(damaged+packet), [self.record])
            self.assertGreaterEqual(decoder.crc_errors,1)

    def test_invalid_angle_format_rejected(self):
        packet=encode_measurement(self.record)
        for changes in [[(32,0x80)],[(33,1)],[(34,0xFF),(35,0xFF)],
                        [(34,0xA0),(35,0x8C)],[(32,6)]]:
            bad=bytearray(packet)
            for offset,value in changes:bad[offset]=value
            bad[40:]=binascii.crc_hqx(bad[:40],0xFFFF).to_bytes(2,"little")
            decoder=FrameDecoder()
            self.assertEqual(decoder.feed(bad+packet),[self.record])
            self.assertEqual(decoder.format_errors,1)

    def test_undefined_and_invalid_position(self):
        coincident=replace(self.record,position_mm=(0,0,1000),azimuth_cdeg=(65535,18000,27000),angle_valid_mask=6)
        self.assertFalse(coincident.has_azimuth(0))
        self.assertTrue(coincident.has_azimuth(1))
        self.assertEqual(FrameDecoder().feed(encode_measurement(coincident)),[coincident])
        invalid=replace(self.record,status=1,mask=1,azimuth_cdeg=(65535,)*3,angle_valid_mask=0)
        self.assertEqual(FrameDecoder().feed(encode_measurement(invalid)),[invalid])
        with self.assertRaises(ValueError):encode_measurement(replace(self.record,status=1))
        with self.assertRaises(ValueError):encode_measurement(replace(self.record,azimuth_cdeg=(36000,0,0)))


class AngleWindowTests(unittest.TestCase):
    def setUp(self):
        self.window=MainWindow()
        self.record=Measurement(0,7,2,2,(5000,)*3,(3000,4000,0),(5313,12687,30687),7)

    def tearDown(self):
        self.window.close(); self.window.deleteLater()
        QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete); APP.processEvents()

    def angles(self):
        return [self.window.angle_table.item(0,i).text() for i in range(4)]

    def test_serial_tcp_display_without_pc_angle_recalculation(self):
        # Deliberately use angles different from XY's geometry: display wire values.
        record=replace(self.record,azimuth_cdeg=(100,200,300))
        for mode in ("serial","tcp"):
            self.window.reset_session(); self.window.mode=mode
            signal=self.window.serial.bytes_received if mode=="serial" else self.window.tcp.bytes_received
            signal.emit(encode_measurement(record)); self.window.refresh_health()
            self.assertEqual(self.angles(),["T2","1.00","2.00","3.00"])
            self.assertEqual(self.window.map_panel.positions[2],(3000,4000))

    def test_legacy_invalid_and_stale(self):
        self.window.mode="serial"
        self.window.receive_bytes(encode_measurement(self.record)); self.window.refresh_health()
        self.assertEqual(self.angles(),["T2","53.13","126.87","306.87"])
        self.window.tags[2]=(self.record,time.monotonic()-3); self.window.refresh_health()
        self.assertEqual(self.window.angle_table.item(0,1).foreground().color().name(),"#8792a1")
        legacy=replace(self.record,azimuth_cdeg=None,angle_valid_mask=0)
        self.window.receive_bytes(encode_measurement(legacy)); self.window.refresh_health()
        self.assertEqual(self.angles(),["T2","—","—","—"])
        invalid=replace(self.record,status=1,mask=1,azimuth_cdeg=(65535,)*3,angle_valid_mask=0)
        self.window.receive_bytes(encode_measurement(invalid)); self.window.refresh_health()
        self.assertEqual(self.angles(),["T2","—","—","—"])
        self.window.reset_session(); self.assertEqual(self.window.angle_table.rowCount(),0)
