import csv
import json
from pathlib import Path
import struct
import tempfile
import unittest

from uwb_pc.ai_model import RiskModel,RiskEngine,risk_features
from uwb_pc.ai_control import ControlClient,command_packet
from uwb_pc.ai_metrics import SessionRecorder,percentile
from uwb_pc.protocol import ControlAck,FrameDecoder,Measurement,crc16_ccitt,encode_measurement


def ack_packet(sequence=1,token=99,opcode=1,state=17,result=0):
    data=struct.pack("<2sBBHBBII",b'\x55\xaa',0x11,opcode,sequence,state,result,token,123456)
    return data+crc16_ccitt(data).to_bytes(2,'little')


class AiTests(unittest.TestCase):
    def test_learned_model_risk_and_metadata(self):
        model=RiskModel()
        self.assertEqual(model.metadata['training_source'],'synthetic_constant_velocity')
        self.assertLess(model.predict(risk_features(1.5,1,0,0)),.1)
        self.assertGreater(model.predict(risk_features(1.5,.15,0,-.5)),.9)
        self.assertFalse(model.environment()['physical_validation'])
        self.assertIsNone(model.environment()['rocm'])

    def test_features_no_safe_region_clamping(self):
        features=risk_features(3,-1,0,0)
        self.assertLess(features[0],0)

    def test_engine_startup_invalid_gap_and_buffered_timing(self):
        engine=RiskEngine()
        value=Measurement(0,7,1,2,(1,2,3),(1500,1000,1000))
        self.assertIsNone(engine.process(value,10).probability)
        self.assertIsNone(engine.process(value,10.5).probability)
        self.assertLess(engine.process(value,11).probability,.1)
        self.assertIsNone(engine.process(value,11.001).probability)
        self.assertIsNone(engine.process(value,14).probability)
        self.assertIsNone(engine.process(Measurement(1,1,2,2,(1,0,0),(0,0,1000)),14.5).probability)
        self.assertNotIn(2,engine.history)

    def test_unknown_backend_and_invalid_features_fail(self):
        with self.assertRaises(ValueError):RiskModel('made_up')
        with self.assertRaises(ValueError):RiskModel().predict([float('nan')]*6)

    def test_ack_splits_mixed_with_legacy_and_v3(self):
        value=Measurement(0,7,1,2,(1,2,3),(3000,2000,1000),(100,200,300),7,1)
        telemetry=encode_measurement(value);ack=ack_packet()
        for split in range(len(telemetry+ack)+1):
            decoder=FrameDecoder();wire=telemetry+ack
            values=decoder.feed(wire[:split])+decoder.feed(wire[split:])
            self.assertEqual(values,[value]);self.assertEqual(decoder.ack_count,1)
            self.assertEqual(decoder.acknowledgements[0],ControlAck(1,1,17,0,99,123456))
        self.assertEqual(len(command_packet(1,1,True,99)),18)

    def test_bad_ack_crc_and_state_cannot_control(self):
        bad=bytearray(ack_packet());bad[-1]^=1
        decoder=FrameDecoder();decoder.feed(bytes(bad)+ack_packet(state=128))
        self.assertEqual(decoder.ack_count,0)
        self.assertGreater(decoder.crc_errors,0);self.assertGreater(decoder.format_errors,0)

    def test_command_matching_rtt_and_timeout(self):
        now=[1000000000];sent=[]
        client=ControlClient(sent.append,clock=lambda:now[0]);client.request(1,True)
        item=client.pending.copy()
        self.assertFalse(client.accept(ControlAck(1,item['sequence'],17,0,item['token']+1,0)))
        self.assertFalse(client.request(0))
        now[0]+=2500000
        self.assertTrue(client.accept(ControlAck(1,item['sequence'],17,0,item['token'],0)))
        self.assertEqual(client.rtt_ms,[2.5]);client.request(0);now[0]+=500000000
        self.assertTrue(client.expire());self.assertEqual(client.timeouts,1)

    def test_command_write_error_does_not_leave_pending(self):
        def fail(_):raise RuntimeError('closed')
        client=ControlClient(fail)
        with self.assertRaises(RuntimeError):client.request()
        self.assertIsNone(client.pending);self.assertEqual(client.sent,0)

    def test_metrics_never_fabricate_physical_latency_or_field_accuracy(self):
        client=ControlClient(lambda _:None);decoder=FrameDecoder();decoder.frames_received=100
        with tempfile.TemporaryDirectory() as folder:
            record=SessionRecorder(Path(folder)/'run',RiskModel().environment(),'demo',client,decoder)
            record.record('inference',{'probability':.8,'preprocess_ms':1,'inference_ms':2,'postprocess_ms':3,'total_ms':6})
            record.trial('intervention','simulated evidence only')
            path=record.export(client,decoder);record.close()
            with path.open(encoding='utf-8-sig') as f:rows={r['metric']:r for r in csv.DictReader(f)}
            self.assertEqual(rows['sensor_to_physical_action_p99']['value'],'')
            self.assertEqual(rows['real_ai_accuracy']['value'],'')
            self.assertEqual(float(rows['telemetry_payload_goodput']['value']),0)
            self.assertEqual(float(rows['task_closed_loop_success']['value']),0)
            self.assertFalse(json.loads((path.parent/'environment.json').read_text(encoding='utf-8'))['end_to_end_physical_latency_measured'])
        self.assertEqual(percentile([1,2,3,4],.5),2.5)


class AiWindowTests(unittest.TestCase):
    def test_cancel_while_command_pending_queues_release_and_stops_heartbeat(self):
        import os
        os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
        from PySide6.QtWidgets import QApplication
        from uwb_pc.window import MainWindow
        app=QApplication.instance() or QApplication([]);window=MainWindow();sent=[]
        try:
            window.mode='serial';window.serial.send_bytes=sent.append
            from uwb_pc.profile import EXPECTED_PROFILE
            window.profile.values=dict(enumerate(EXPECTED_PROFILE));window.profile.validate()
            window.ai.set_enabled(True);pending=window.ai.client.pending.copy()
            window.ai.set_enabled(False)
            self.assertFalse(window.ai.enabled);self.assertTrue(window.ai.release_requested)
            window.ai.accept(ControlAck(1,pending['sequence'],17,0,pending['token'],0));window.ai.tick()
            self.assertEqual(window.ai.client.pending['opcode'],2)
            self.assertFalse(window.ai.release_requested);self.assertEqual(len(sent),2)
        finally:window.close();window.deleteLater();app.processEvents()

    def test_embedded_monitoring_keeps_original_alarm_independent(self):
        import os
        os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
        from PySide6.QtWidgets import QApplication
        from uwb_pc.window import MainWindow
        app=QApplication.instance() or QApplication([]);window=MainWindow()
        try:
            window.show_ai();self.assertFalse(window.ai.enabled)
            from PySide6.QtWidgets import QDialog
            self.assertIs(window.ai_panel.window(),window)
            self.assertFalse(window.findChildren(QDialog))
            window.ai_panel.advanced_button.setChecked(True)
            self.assertTrue(window.ai_panel.advanced_button.isChecked())
            self.assertEqual(window.ai_panel.summary.text(),'预测未来0.7秒越界风险')
            self.assertIn('合成训练原型',window.ai_panel.summary.toolTip())
            window.mode='tcp'
            with self.assertRaises(RuntimeError):window.ai.set_enabled(True)
            value=Measurement(0,7,1,2,(1,2,3),(6500,1000,1000),(100,200,300),7,3)
            window.receive_bytes(encode_measurement(value))
            self.assertEqual(window.map_panel.alarm_tags,{2});self.assertEqual(window.ai.client.sent,0)
        finally:window.close();window.deleteLater();app.processEvents()
