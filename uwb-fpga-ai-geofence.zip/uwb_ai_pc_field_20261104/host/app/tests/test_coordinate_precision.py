"""Millimeter values must reach storage, tracking, AI and exports, not only labels."""
import csv
import json
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
import tempfile
import unittest
from PySide6.QtWidgets import QApplication
from uwb_pc.coordinate_precision import round_coordinate_mm,centimeter_measurement,format_coordinate_m,telemetry_measurement
from uwb_pc.protocol import Measurement,FrameDecoder,encode_measurement
from uwb_pc.window import MainWindow
from uwb_pc.ai_metrics import SessionRecorder
from uwb_pc.known_point import KnownPointSession

APP=QApplication.instance() or QApplication([])


class CoordinatePrecisionTests(unittest.TestCase):
    def test_current_wire_mm_values_reach_host_storage_and_ai_with_raw_ranges(self):
        internal=Measurement(0,7,1,2,(2011,2189,2397),(1250,-1249,12),(1000,2000,3000),7,3)
        sent=telemetry_measurement(internal)
        self.assertEqual(sent.position_mm,(1250,-1249,12))
        self.assertEqual(internal.position_mm,(1250,-1249,12))
        self.assertEqual(sent.distances_mm,internal.distances_mm)
        w=MainWindow();w.mode='tcp';w.known_points.start((0,0,0),2)
        try:
            packet=encode_measurement(sent);w.receive_bytes(packet[:11]);w.receive_bytes(packet[11:]);w.refresh_health()
            self.assertEqual(w.tags[2][0].position_mm,(1250,-1249,12))
            self.assertEqual(w.map_panel.positions[2],(1250,-1249))
            self.assertEqual(w.ai.engine.history[2][0][1:],(1.25,-1.249))
            row=w.known_points.rows[-1]
            self.assertEqual([row[k] for k in ('x_mm','y_mm','z_mm')],[1250,-1249,12])
            self.assertEqual([row[f'd{i}_mm'] for i in range(3)],[2011,2189,2397])
        finally:w.close();w.deleteLater();APP.processEvents()

    def test_rounding_ties_negative_values_and_signed_endpoints(self):
        for incoming in (0,4,5,14,15,1234,1235,1245,-4,-5,-1234,-1235,-1245,2147483647,-2147483648):
            with self.subTest(incoming=incoming):self.assertEqual(round_coordinate_mm(incoming),incoming)
        self.assertEqual(round_coordinate_mm(1245.5),1246)
        self.assertEqual(round_coordinate_mm(-1245.5),-1246)
        self.assertEqual(format_coordinate_m(1250),'1.3')
        self.assertEqual(format_coordinate_m(-1250),'-1.3')
        self.assertEqual(format_coordinate_m(-10),'0.0')

    def test_split_uart_and_tcp_preserve_mm_for_all_consumers_and_exports(self):
        wire=Measurement(0,7,1,2,(2011,2189,2397),(1235,-1245,5),(1000,2000,3000),7,3)
        packet=encode_measurement(wire)
        self.assertEqual(FrameDecoder().feed(packet),[wire]) # Original wire decoder stays lossless.
        for mode in ('serial','tcp','demo','replay'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as folder:
                w=MainWindow();w.mode=mode
                w.ai.recorder=SessionRecorder(Path(folder)/'record',{'backend':'native_cpu'},mode,client=w.ai.client,decoder=w.decoder)
                w.known_points.start((0,0,0),2)
                try:
                    w.receive_bytes(packet[:17]);self.assertFalse(w.tags)
                    w.receive_bytes(packet[17:]);w.refresh_health()
                    self.assertEqual(w.tags[2][0].position_mm,(1235,-1245,5))
                    self.assertEqual(w.tags[2][0].distances_mm,wire.distances_mm)
                    self.assertEqual(w.tags[2][0].azimuth_cdeg,wire.azimuth_cdeg)
                    self.assertEqual(w.map_panel.positions[2],(1235,-1245))
                    self.assertEqual(w.coordinate_labels[0].text(),'1.2')
                    self.assertEqual(w.table.item(0,7).text(),'-1.2')
                    self.assertEqual(w.map_panel.alarm_tags,{2})
                    if mode!='replay':
                        self.assertEqual(w.ai.engine.history[2][0][1:],(1.235,-1.245))
                        path=Path(folder)/'points.csv';w.known_points.export_csv(path)
                        row=list(csv.DictReader(path.open(encoding='utf-8-sig')))[0]
                        self.assertEqual([int(row[k]) for k in ('x_mm','y_mm','z_mm')],[1235,-1245,5])
                    events=[json.loads(s) for s in (Path(folder)/'record/events.jsonl').read_text(encoding='utf-8').splitlines()]
                    actual=[e for e in events if e['event'] in ('position','inference')]
                    self.assertEqual(len(actual),2)
                    self.assertTrue(all(e['position_mm']==[1235,-1245,5] for e in actual))
                    self.assertEqual(next(e for e in actual if e['event']=='position')['position_cm'],[123.5,-124.5,.5])
                    receive=[e for e in events if e['event']=='receive']
                    self.assertEqual(bytes.fromhex(''.join(e['bytes_hex'] for e in receive)),packet)
                finally:w.close();w.deleteLater();APP.processEvents()

    def test_smoothed_points_use_mm_grid_and_csv_preserves_recorded_mm(self):
        w=MainWindow();w.mode='demo'
        try:
            for i in range(20):
                value=Measurement(0,7,i,2,(2000,)*3,(1500+i*13,866+i*7,0))
                w.receive_bytes(encode_measurement(value))
            for points in (w.map_panel.trails[2],w.map_panel.raw_trails[2],w.map_panel.display_positions.values()):
                self.assertTrue(all(isinstance(v,int) for point in points for v in point))
        finally:w.close();w.deleteLater();APP.processEvents()
        with tempfile.TemporaryDirectory() as folder:
            s=KnownPointSession();s.start((0,0,0));s.add(Measurement(0,7,1,2,(2000,)*3,(15,-15,1234)),'unverified','serial')
            path=Path(folder)/'points.csv';s.export_csv(path)
            rows=list(csv.DictReader(path.open(encoding='utf-8-sig')))
            rows[0].update(x_mm='1235',y_mm='-1245',z_mm='5')
            with path.open('w',encoding='utf-8-sig',newline='') as out:
                writer=csv.DictWriter(out,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
            loaded=KnownPointSession();loaded.load_csv(path)
            self.assertEqual([loaded.rows[0][k] for k in ('x_mm','y_mm','z_mm')],[1235,-1245,5])
            self.assertEqual(centimeter_measurement(Measurement(0,7,1,2,(1,2,3),(15,-15,1234))).position_mm,(15,-15,1234))


if __name__=='__main__':unittest.main()
