import json
import math
from pathlib import Path
import re
import tempfile
import unittest

from uwb_pc.geofence import SITE_ANCHORS_MM,simulated_fence_flags
from uwb_pc.ai_model import RiskModel,MODEL_PATH


class SiteGeometryTests(unittest.TestCase):
    def test_decimetre_installation_grid_and_closed_fence(self):
        self.assertEqual(SITE_ANCHORS_MM,((0,0,1000),(3000,0,1000),(1500,2600,1000)))
        self.assertTrue(all(v%100==0 for p in SITE_ANCHORS_MM for v in p))
        self.assertEqual(math.dist(SITE_ANCHORS_MM[0],SITE_ANCHORS_MM[1]),3000)
        self.assertAlmostEqual(math.dist(SITE_ANCHORS_MM[0],SITE_ANCHORS_MM[2]),3001.666203960727)
        self.assertEqual([p[2] for p in SITE_ANCHORS_MM],[1000]*3)
        for point in [(0,0),(3000,0),(1500,2600),(750,1300),(2250,1300),(1500,850)]:
            self.assertEqual(simulated_fence_flags(*point),1)
        for point in [(1500,-1),(1500,2601),(750,1301),(2250,1301),(3250,500)]:
            self.assertEqual(simulated_fence_flags(*point),3)

    def test_board_host_and_model_geometry_agree(self):
        model=RiskModel()
        self.assertEqual(model.metadata['anchors_mm'],[list(p) for p in SITE_ANCHORS_MM])
        self.assertEqual(model.metadata['tag_z_mm'],0)
        board=Path(__file__).resolve().parents[3]/'config/board.tcl'
        if board.exists():
            line=next(s for s in board.read_text().splitlines() if s.startswith('set ANCHORS_MM'))
            coordinates=list(map(int,re.findall(r'-?\d+',line)))
            self.assertEqual(coordinates,[int(v) for p in SITE_ANCHORS_MM for v in p])

    def test_six_meter_model_cannot_be_used_for_three_meter_fence(self):
        metadata=json.loads(MODEL_PATH.read_text())
        metadata['anchors_mm']=[[0,0,2000],[6000,0,2000],[3000,5196,2000]]
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'old_model.json';path.write_text(json.dumps(metadata))
            with self.assertRaisesRegex(ValueError,'geometry'):RiskModel(path=path)

    def test_previous_2598mm_model_is_rejected_for_current_installation(self):
        path=MODEL_PATH.parent.parent/'examples/historical_models/risk_mlp_y2598.json'
        with self.assertRaisesRegex(ValueError,'geometry'):RiskModel(path=path)

    def test_ui_prediction_horizon_rejects_previous_075_second_model(self):
        metadata=json.loads(MODEL_PATH.read_text())
        self.assertEqual(metadata['horizon_s'],.7)
        metadata['horizon_s']=.75
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'previous_horizon.json';path.write_text(json.dumps(metadata))
            with self.assertRaisesRegex(ValueError,'horizon'):RiskModel(path=path)
