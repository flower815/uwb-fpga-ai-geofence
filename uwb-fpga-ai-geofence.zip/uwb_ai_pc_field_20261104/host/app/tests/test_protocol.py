import binascii
import struct
import unittest
from uwb_pc.protocol import Measurement, FrameDecoder, encode_measurement, crc16_ccitt


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.record = Measurement(0, 7, 255, 2, (5000, 9849, 5000), (-3000, 4000, -900))

    def test_standard_crc(self):
        self.assertEqual(crc16_ccitt(b"123456789"), 0x29B1)
        for data in [b"", bytes(range(256)), b"\x55\xaa"*30]:
            self.assertEqual(crc16_ccitt(data), binascii.crc_hqx(data, 0xFFFF))

    def test_offsets_and_independent_frame(self):
        packet = bytearray(34)
        packet[:8] = bytes.fromhex("55 aa 01 00 07 ff 02 00")
        struct.pack_into("<IIIiii", packet, 8, 5000, 9849, 5000, -3000, 4000, -900)
        struct.pack_into("<H", packet, 32, binascii.crc_hqx(packet[:32], 0xFFFF))
        self.assertEqual(encode_measurement(self.record), packet)
        self.assertEqual(FrameDecoder().feed(packet), [self.record])

    def test_every_split(self):
        packet = encode_measurement(self.record)
        for index in range(35):
            decoder = FrameDecoder()
            self.assertEqual(decoder.feed(packet[:index])+decoder.feed(packet[index:]), [self.record])

    def test_multiple_frames_and_noise(self):
        packet = encode_measurement(self.record)
        decoder = FrameDecoder()
        self.assertEqual(decoder.feed(b"junk\x55"+packet*3), [self.record]*3)
        self.assertEqual(decoder.frames_received, 3)

    def test_corruption_recovers_at_following_frame(self):
        packet = encode_measurement(self.record)
        for index in range(2, 34):
            damaged = bytearray(packet)
            damaged[index] ^= 1
            decoder = FrameDecoder()
            self.assertEqual(decoder.feed(damaged+packet), [self.record])
            self.assertGreaterEqual(decoder.crc_errors, 1)

    def test_header_in_payload(self):
        record = Measurement(0, 7, 1, 2, (0xAA55, 5000, 5000), (3000, 4000, 0))
        decoder = FrameDecoder()
        packet = encode_measurement(record)
        self.assertEqual(decoder.feed(packet*2), [record]*2)

    def test_unsupported_version_or_reserved(self):
        packet = encode_measurement(self.record)
        for index in [2, 7]:
            unsupported = bytearray(packet)
            unsupported[index] = 4
            unsupported[32:] = binascii.crc_hqx(unsupported[:32], 0xFFFF).to_bytes(2,"little")
            decoder = FrameDecoder()
            self.assertEqual(decoder.feed(unsupported+packet), [self.record])
            self.assertEqual(decoder.format_errors, 1)

    def test_actual_missing_range(self):
        missing = Measurement(1, 1, 1, 2, (328, 0, 0), (0, 0, 0))
        self.assertFalse(missing.has_position)
        self.assertEqual(missing.description, "测距不完整")
        self.assertEqual(FrameDecoder().feed(encode_measurement(missing)), [missing])

    def test_loss_flag_and_invalid_status(self):
        self.assertTrue(Measurement(0x80, 7, 1, 2, (1, 1, 1), (1, 1, 0)).has_position)
        for status in [1, 2, 4, 8, 0x10, 0x81]:
            self.assertFalse(Measurement(status, 7, 1, 2, (1, 1, 1), (1, 1, 0)).has_position)
        self.assertFalse(Measurement(0, 1, 1, 2, (1, 0, 0), (1, 1, 0)).has_position)


if __name__ == "__main__":
    unittest.main()
