当前工程包采用2026-11-04提供的五份已知点CSV。启动入口main.py；部署见../deploy/README.md。回放数据位于examples/field_tests；未修改原始文件。工作目录中的旧CSV没有纳入。
