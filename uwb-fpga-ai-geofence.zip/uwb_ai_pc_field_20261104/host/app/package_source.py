"""生成完整代码阅读文档与可迁移源码包，不打包虚拟环境。"""
from pathlib import Path
import zipfile


def main():
    root = Path(__file__).resolve().parent
    python_files = [root / "main.py"]
    for directory in ("uwb_pc", "lessons", "tests"):
        python_files.extend(sorted((root / directory).glob("*.py")))
    python_files.extend(root / name for name in ("check.py", "render_preview.py", "package_source.py"))
    text = ["# 完整Python代码\n\n",
            "这是可运行项目的逐文件源码。保留文件名和目录结构，依赖及操作见README.md。\n",
            "解算在FPGA；电脑实时模式只接收结果。地图模块只做显示坐标变换。\n\n"]
    for path in python_files:
        text.append(f"## {path.relative_to(root).as_posix()}\n\n```python\n")
        text.append(path.read_text(encoding="utf-8").rstrip() + "\n```\n\n")
    (root / "SOURCE_CODE.md").write_text("".join(text), encoding="utf-8")
    files = python_files + [root / name for name in (
        "requirements.txt", "requirements_train.txt", "run.cmd", "README.md", "LEARNING_STEPS.md", "SOURCE_CODE.md", "preview.png", "preview_angles.png", "preview_geofence.png", "preview_ai_pc.png", "preview_pending.png", "preview_quality.png", "preview_calibration.png", "preview_replay.png", "preview_csv_fault.png", "preview_csv_fence.png")]
    files.extend(sorted(p for p in (root / "examples").rglob("*") if p.is_file()))
    for folder in ("model", "deploy", "assets"):
        files.extend(p for p in (root/folder).rglob("*") if p.is_file() and p.name!="platform.local.json")
    destination = root.parent / "pc_upper_map.zip"
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, "pc_upper/" + path.relative_to(root).as_posix())
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("源码包校验失败")
    print(f"完整源码 {len(python_files)} 个Python文件；压缩包 {len(files)} 个文件")
    print(destination)


if __name__ == "__main__":
    main()
