"""运行：.venv/Scripts/python.exe check.py（无需连接硬件）。"""
import os
from pathlib import Path
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
root = Path(__file__).resolve().parent
suite = unittest.defaultTestLoader.discover(str(root / "tests"))
result = unittest.TextTestRunner(verbosity=2).run(suite)
from PySide6.QtWidgets import QApplication
application = QApplication.instance()
if application:
    application.shutdown()
raise SystemExit(0 if result.wasSuccessful() else 1)
