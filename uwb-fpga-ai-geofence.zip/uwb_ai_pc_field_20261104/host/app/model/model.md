# MODEL
版本：risk_mlp_20261101_site_dm_horizon07_v5
SHA256：b07d6acee34c4b1e82132bfcdbc3c0a1f475dfe77765cf1d8a21a29f06ac5d66
来源：本工程train_risk_model.py训练，无第三方预训练权重、云API或运行时下载。
架构6→24(tanh)→12(tanh)→1(sigmoid)；输入是三个有向三角边的归一化距离与法向速度，共六维。几何为(0,0),(3,0),(1.5,2.6)m，高度1m/0m。标签为当前位置或恒速预测+0.7秒在围栏外。
native_cpu使用Python float64；可选torch_cpu/torch_rocm使用float32，batch1，无量化。默认Intel CPU；未验证AMD GPU/NPU，CPU合成耗时不证明AMD加速。
训练16000例、独立测试4000例，随机种子/epoch/报告在JSON元数据；本包仅纳入新现场数据及现场推理耗时，不纳入旧合成CSV。不把合成准确率当现场准确率，sigmoid输出未经概率校准。
模型预测风险，不修正UWB遮挡偏差。速度用PC接收时间估算，启动/失效/域外时风险未知。现场部署需独立标签与真实轨迹验证。
权重主副本host/model/risk_mlp.json与运行副本host/app/model/risk_mlp.json完全一致，便于现有加载代码直接复现。训练/基准入口见metrics/scripts/reproduce.py --check train或benchmark；训练需要requirements_train.txt，输出留在本地复现区，不覆盖提交权重。
