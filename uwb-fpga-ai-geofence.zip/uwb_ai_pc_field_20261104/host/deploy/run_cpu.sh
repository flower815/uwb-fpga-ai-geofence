#!/bin/sh
set -eu
cd "$(dirname "$0")/../app"
exec .venv/bin/python main.py --ai --ai-backend native_cpu
