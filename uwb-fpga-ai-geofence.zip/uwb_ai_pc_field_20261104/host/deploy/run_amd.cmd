@echo off
setlocal
cd /d "%~dp0..\app"
set PYTHONUTF8=1
.venv\Scripts\python.exe main.py --ai --ai-backend native_cpu
if errorlevel 1 pause
