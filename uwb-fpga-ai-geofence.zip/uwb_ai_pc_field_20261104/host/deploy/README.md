# 部署与运行
Windows PowerShell在工程根目录：
```powershell
py -3.12 -m venv host/app/.venv
& host/app/.venv/Scripts/python.exe -m pip install -r host/deploy/requirements.txt
& host/app/.venv/Scripts/python.exe host/app/check.py
```
双击run_intel.cmd，或运行host/app/main.py。run_amd.cmd同样是native_cpu回退入口；没有宣称AMD NPU/GPU已验证。Linux可在host/app建.venv、安装相同依赖，再sh host/deploy/run_cpu.sh。训练另装requirements_train.txt。
USB115200；Wi-Fi在上位机启动TCP监听9000，ESP连接电脑LAN地址而非网关。仅同一2.4GHz网络不等于端口可达，现场需核对IP、路由隔离与防火墙。网络模板在fpga/src/config/wifi.example.tcl，复制为wifi.local.tcl并在本地填入SSID/密码/IP后重新构建，勿公开该文件或含凭据的Wi-Fi bit。
运行记录默认在本包metrics/logs/session_*产生；回放只读，不授权实板控制。测试名a沿用模拟生成器，1～5回放本次五份已知点CSV，主界面来源标记保持。
Python依赖已锁定于requirements.txt；Vivado2020.2、Icarus12+需自行安装。硬件/驱动快照在本次logs/sessions/*/environment.json内；嵌套旧快照保留原日期，不充当新驱动采集。功耗模式与AMD驱动未提供，待采集。
