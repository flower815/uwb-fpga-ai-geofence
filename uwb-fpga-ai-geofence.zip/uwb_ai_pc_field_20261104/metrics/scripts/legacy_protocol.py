"""FPGA output protocol. Standard library only; no position solving occurs here."""
from dataclasses import dataclass
import struct

MAGIC = b"\x55\xaa"
SIZE = 34
LAYOUT = struct.Struct("<2s6B3I3iH")


def crc16(data: bytes) -> int:
    crc = 0xFFFF
    for value in data:
        crc ^= value << 8
        for _ in range(8):
            crc = ((crc << 1) ^ (0x1021 if crc & 0x8000 else 0)) & 0xFFFF
    return crc


@dataclass(frozen=True)
class Position:
    status: int
    mask: int
    seq: int
    tag: int
    distances: tuple[int, int, int]
    xyz: tuple[int, int, int]

    @property
    def located(self) -> bool:
        return self.status & 0x7F == 0 and self.mask & 7 == 7

    @property
    def message(self) -> str:
        reasons = []
        for bit, description in [(1, "测距不完整"), (2, "距离为零或超过60m"),
                                 (4, "基站几何或参数无效"), (8, "坐标超过±30m范围"),
                                 (128, "先前发生数据丢帧")]:
            if self.status & bit:
                reasons.append(description)
        return "；".join(reasons) if reasons else "定位正常"


def encode(p: Position) -> bytes:
    payload = struct.pack("<2s6B3I3i", MAGIC, 1, p.status, p.mask, p.seq, p.tag, 0,
                          *p.distances, *p.xyz)
    return payload + struct.pack("<H", crc16(payload))


class Decoder:
    def __init__(self):
        self.buffer = bytearray()
        self.crc_errors = 0

    def feed(self, data: bytes) -> list[Position]:
        self.buffer.extend(data)
        result = []
        while True:
            offset = self.buffer.find(MAGIC)
            if offset < 0:
                # Preserve a possible partial two-byte header.
                self.buffer[:] = self.buffer[-1:] if self.buffer[-1:] == MAGIC[:1] else b""
                break
            if offset:
                del self.buffer[:offset]
            if len(self.buffer) < SIZE:
                break
            packet = bytes(self.buffer[:SIZE])
            if crc16(packet[:32]) != int.from_bytes(packet[32:], "little"):
                self.crc_errors += 1
                del self.buffer[0]
                continue
            values = LAYOUT.unpack(packet)
            if values[1] == 1 and values[6] == 0:
                result.append(Position(values[2], values[3], values[4], values[5],
                                       tuple(values[7:10]), tuple(values[10:13])))
            del self.buffer[:SIZE]
        return result
