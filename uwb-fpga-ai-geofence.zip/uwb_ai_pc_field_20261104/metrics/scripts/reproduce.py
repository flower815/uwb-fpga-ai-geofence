"""Stage the original relative-path layout, then run actual supplied tests."""
from pathlib import Path
import argparse, shutil, subprocess, sys
ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser()
parser.add_argument('--check',choices=['all','reliability','wifi','profile','ai','quality','filter','benchmark','train'],default='reliability')
args=parser.parse_args()
stage=ROOT/'metrics'/'.reproduce'
stage.mkdir(parents=True,exist_ok=True)
for folder in ('rtl','config','constraints','sim','tests','scripts'):
    shutil.copytree(ROOT/'fpga/src'/folder,stage/folder,dirs_exist_ok=True)
shutil.copytree(ROOT/'host/app',stage/'shangweiji/pc_upper',dirs_exist_ok=True,
                ignore=shutil.ignore_patterns('.venv','__pycache__'))
(stage/'host').mkdir(exist_ok=True)
shutil.copy2(ROOT/'metrics/scripts/legacy_protocol.py',stage/'host/protocol.py')
(stage/'build/reliability').mkdir(parents=True,exist_ok=True)
names={'reliability':'verify_reliability_system.py','wifi':'verify_ai_wifi.py','profile':'verify_profile.py',
       'ai':'verify_ai.py','quality':'verify_quality.py','filter':'verify_filter.py',
       'benchmark':'benchmark_ai.py','train':'train_risk_model.py'}
selected=list(names)[:6] if args.check=='all' else [args.check]
for key in selected:
    subprocess.run([sys.executable,str(stage/'scripts'/names[key])],cwd=stage,check=True)
print('PASS; generated evidence remains in:',stage)
