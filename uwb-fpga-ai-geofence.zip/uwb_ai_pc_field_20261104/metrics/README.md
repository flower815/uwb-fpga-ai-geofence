# 指标口径和证据
metrics.csv只列可读取或计算的值，不填无依据的零，也不把旧合成CSV拿来充本批现场指标。
logs/known_points：用户video目录五份原始文件。真值来源是CSV中人工填写字段；全部TCP、profile_state=unverified，不擅自改成verified。P4/P5相同真值；记录跨度是末行PC单调接收时刻减首行，不是传感器采样时长。
XY有效条件与当前KnownPointSession一致：kind=measurement，status低7位为0，前三位MASK有效，且非故障心跳标志。有效率分母包括无效measurement；心跳/重复单列。RMSE=sqrt(mean(dx²+dy²))；P95/P99为排序线性插值；偏差为解算减真值。三距偏差按每行anchors_json计算三维斜距，标准差为总体标准差。五次合并按有效帧权重，不是测点均衡成绩。
logs/sessions：本次两份会话原始environment/events/metrics/trials文件。原始导出metrics.csv保留但最终总表重新从events复算；推理耗时只统计probability非空调用，未知风险次数另报。PC monotonic_ns是到达/处理时间，无传感器到执行器同步。CRC/格式统计对receive原始字节重新解码；没有观察到CRC错误不等于没有无线丢包；不能用跳号直接认定丢包。
会话记录事件跨度仅证明所提供日志覆盖区间，不命名为已通过持续稳定运行。原始中文reason若编码损坏保持原样，计算使用数值字段，不修补证据。
FPGA资源/时序来自2026-11-01正式构建报告，未声称这次现场重新综合。50MHz、固件5.6为代码/构建配置，未核对的现场板端参数不能由PC环境字段证明。
用户已确认两份动态测试均成功，operator_confirmations.json记录原话、会话名与日期，按会话级计算100%（2/2），不改原始trials.csv。没有逐次任务与时限标注、独立AI真值标签、控制命令/ACK样本、同步物理响应或板内计时；相应指标不列数值。设计报告已收入../report/FPGA设计报告.pdf；没有波形、XSA/HWH，不建空目录。可复用Skill位于../skill/uwb-field-delivery。
