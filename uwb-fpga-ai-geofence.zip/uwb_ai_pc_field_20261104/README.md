# UWB工程包：2026-11-04现场数据版
目录依次为README.md、docs/、fpga/src build report、host/model app deploy、metrics/metrics.csv logs scripts、skill/、report/。不建立空的evidence目录。

仅使用此次video目录五份已知点CSV和metrics/logs两份TCP会话；原始文件逐字节复制。旧known_point*.csv、合成samples.csv及旧轨迹JSON未纳入。本包回放菜单的1～5使用新文件，a保留程序模拟来源；未改动工作工程。

结果见docs/field_results.md；metrics/metrics.csv每项都列条件、样本数和证据。已知点全部未核对固件，结果以人工填写真值为条件。CPU现场推理耗时不含传感器、无线传输和蜂鸣器动作；没有物理端到端指标或现场AI准确率。

从零部署见host/deploy/README.md，Python3.12及依赖requirements.txt；Vivado2020.2，Icarus12+用于RTL命令行回归。FPGA50MHz，固件5.6，已有USB bit和USB/Wi-Fi构建脚本、资源/时序报告。Wi-Fi本地配置及含密码的Wi-Fi bit不公开，需现场重建。

复算本批指标：在工程根用host/app/.venv/Scripts/python.exe metrics/scripts/analyze_field_submission.py。
应用检查：同一解释器运行host/app/check.py；RTL：metrics/scripts/reproduce.py --check reliability。
模型权重主副本host/model与运行副本host/app/model一致；Intel native_cpu/float64默认，AMD入口只为CPU回退，未提供AMD加速实测。

可复用Skill见skill/uwb-field-delivery/SKILL.md，包含指标口径、证据整理与只读校验脚本。使用示例见skill/README.md；当前仅随工程包提供，未安装到电脑全局Skill目录。

GitHub发布步骤见docs/publish_github.md。已附.gitignore；当前未指定开源许可证，需项目权利人选定LICENSE。公开候选包不含本地Wi-Fi配置与含网络凭据的Wi-Fi bit。

设计报告见[FPGA设计报告.pdf](report/FPGA设计报告.pdf)，为用户提供的原始PDF，未修改正文。
